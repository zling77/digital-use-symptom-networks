Generated analysis outputs are written here. No pre-generated outputs are
distributed in this release. Running the full pipeline with authorised data
creates individual-level cleaned and matched records in this directory; do not
upload or redistribute the complete output directory. Share only separately
reviewed, non-identifying aggregate results.
