Generated analysis outputs are written here. This directory contains no distributed dataset.
