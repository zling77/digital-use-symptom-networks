# Data access

Individual-level SEARCH records are restricted by ethics approval 2022-KY095-02
and are not distributed with this code. Set `PSUNET_SEARCH_DATA_DIR` as described
in `README.md`. Global Mind Project and Millennium Cohort Study analyses are
packaged separately because their source data have third-party access terms.
