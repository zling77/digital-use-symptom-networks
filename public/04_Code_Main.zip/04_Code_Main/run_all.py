"""Single entry point for the portable SEARCH analysis pipeline."""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

from project_paths import OUTPUT_DIR, PROJECT_ROOT, ensure_output_dir


def run(script: Path, *arguments: str) -> None:
    command = [sys.executable, str(script), *arguments]
    print("\n$", " ".join(command), flush=True)
    subprocess.run(command, cwd=OUTPUT_DIR, check=True, env=os.environ.copy())


def main() -> None:
    parser = argparse.ArgumentParser(description="Reproduce SEARCH analyses without machine-specific paths.")
    parser.add_argument("--stage", choices=["pipeline", "analyses", "figures", "all"], default="all")
    parser.add_argument("--quick", action="store_true", help="Use small resample counts for a smoke test.")
    args = parser.parse_args()
    ensure_output_dir()

    base = PROJECT_ROOT / "scripts" / "2.revision"
    if args.stage in {"pipeline", "all"}:
        run(base / "pipeline" / "00_build_baseline_network.py")
        run(base / "pipeline" / "01_clean_wave1.py")
        run(base / "pipeline" / "02_clean_wave3.py")
        run(base / "pipeline" / "03_match_longitudinal.py")
        run(base / "pipeline" / "04_clpn_longitudinal.py", "--bootstrap", "20" if args.quick else "1000")

    if args.stage in {"analyses", "all"}:
        run(
            base / "analyses" / "00_core_directional_and_community.py",
            "--dag-bootstrap", "5" if args.quick else "200",
            "--community-bootstrap", "5" if args.quick else "100",
        )
        run(
            base / "analyses" / "01_network_and_null_stability.py",
            "--null-bootstrap", "5" if args.quick else "500",
            "--mds-solutions", "5" if args.quick else "60",
        )

    if args.stage in {"figures", "all"}:
        run(base / "figures" / "00_rebuild_collection_main_figures.py")
        run(base / "figures" / "01_rebuild_collection_supplementary_figures.py")


if __name__ == "__main__":
    main()
