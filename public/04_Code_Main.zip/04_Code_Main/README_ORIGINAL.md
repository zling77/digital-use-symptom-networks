# Analysis code — Emotional Distress Drives Adolescent Digital Use Symptom Networks

This folder contains the analysis code for the manuscript. It reconstructs the
symptom network, computes the structural-control (minimum-dominating-set / control-
frequency) profile, estimates the cross-lagged panel network (CLPN) and the Bayesian
directed graph, runs the community-detection, controllability, null-model and
robustness analyses, and generates the figures.

## Structure

```
Code/
├── src/
│   ├── config.py                 # global plotting parameters and random seed (42)
│   ├── ModuleControlNetwork.py   # core class: network reconstruction + module control network
│   └── utils/
│       ├── logger.py
│       ├── data_utils.py         # data loading / crosswalk helpers
│       ├── statistics.py         # group comparisons, bootstrap, statistical tests
│       ├── mds_finder.py         # minimum-dominating-set enumeration and control frequency
│       └── network_metrics.py    # centrality, controllability, community, null models
└── scripts/
    ├── 0.preprocess/             # scale merging and record cleaning
    │   ├── merge_scales.ipynb
    │   └── info_preprocess.ipynb
    └── 1.experiments/            # main analysis pipeline (run in order)
        ├── 1.preprocess.ipynb
        ├── 2.statistical_test.ipynb
        ├── 3.network_analysis.ipynb            # GGM, MDS/CF, module control network
        ├── 4.network_analysis_visualization.ipynb
        ├── 5.bootstrap.ipynb                   # subsampling bootstraps, driver stability
        ├── 6.regression_analysis.ipynb
        ├── minimal_network_robustness.ipynb    # estimator / null-model robustness
        ├── compute_reliability.py
        └── improve_experiment.py               # CLPN, Bayesian DAG, convergence, MCS replication
```

## Requirements

Python 3.10+ with the packages in `requirements.txt`. Install with:

```
pip install -r requirements.txt
```

Key dependencies: numpy, pandas, scipy, scikit-learn, networkx, python-igraph,
leidenalg, python-louvain, statsmodels, pgmpy, matplotlib, seaborn.

## Reproducibility

- The random seed is fixed to 42 throughout (`src/config.py`).
- Run scripts from the `Code/` directory so that `from src...` imports resolve.
- Notebook outputs have been cleared; re-running reproduces the derived tables in
  the `Data/` folder (e.g., `clpn_coefficients.csv`, `nulldist_mds.csv`,
  `network_estimation_robustness.csv`, `mcs_clpn_directionality.csv`).

## Data

Individual-level cohort data are restricted by ethics approval (2022-KY095-02) and
are not included. The `Data/` folder next to this `Code/` folder contains the
de-identified, derived group-level tables that the Supplementary Information refers
to; the Global Mind Project and Millennium Cohort Study data are obtained from Sapien
Labs and the UK Data Service, respectively.
