# Reproducibility code

This directory supports the analyses and final figures for **Emotional distress
predicts change in adolescent problematic digital use and related symptoms**.

This release contains analysis code, non-identifying aggregate reference results
and source panels required by the figure-assembly scripts. It does not contain
raw participant data, individual-level cleaned or linked records, participant
identifiers or third-party individual-level datasets.

## Directory map

```text
src/                         original reusable network code
scripts/0.preprocess/        original raw-data preparation notebooks
scripts/1.experiments/       baseline preprocessing notebook and reliability script
scripts/2.revision/pipeline/ longitudinal and baseline reproducibility pipeline
scripts/2.revision/analyses/ consolidated revision analyses
scripts/2.revision/figures/  final Collection-specific figure rebuild scripts
reference_results/           small non-identifying aggregate result tables
reference_figures_source/    two non-identifying source panels from the pipeline
tests/                       package and manuscript-value validation tools
outputs/                     locally generated outputs
```

Three original preprocessing notebooks are retained to document preparation of
the secure baseline input. Their saved outputs and execution counts are cleared.
They require authorised source data and are not part of `run_all.py`.
The reliability script is `scripts/1.experiments/compute_reliability.py`.
Other legacy experiment notebooks, the superseded experiment script and figure
assembler, historical documentation, and pre-generated output figures are
omitted from this release. Core numerical analysis scripts are unchanged.

## Environment

Create the supplied analysis environment:

```bash
conda env create -f environment.yml
conda activate psunet-repro
```

Alternatively, install `requirements.txt` in Python 3.10 or 3.11.

## Data configuration

The full analysis pipeline requires separately authorised data. The public
reference tables are aggregate results, not substitutes for individual-level
input data. Figure assembly and the static package test can be run without
participant data; full numerical re-analysis cannot.

Set `PSUNET_SEARCH_DATA_DIR` to a secure directory with the same internal layout
as the original `Code/data` directory:

```text
<SEARCH_DATA_DIR>/
  raw/1/.../common_info.csv
  raw/3/.../common_info.csv
  raw/3/.../scale_detailed_data/*_detailed_data.csv
  preprocessed/cleaned_scale_info.csv
```

Optionally set `PSUNET_OUTPUT_DIR` to choose the output directory. No personal
absolute path is embedded in executable source files.

## Rebuild the final Collection figures without individual-level data

The five main figure layouts can be assembled from aggregate reference tables
and the two supplied non-identifying source panels:

```bash
python scripts/2.revision/figures/00_rebuild_collection_main_figures.py
```

Outputs are written to `outputs/collection_main_figures/`. The two
Supplementary Figures whose terminology changed in the final narrative can be
rebuilt with:

```bash
python scripts/2.revision/figures/01_rebuild_collection_supplementary_figures.py
```

Outputs are written to `outputs/collection_supplementary_figures/`.

Figure 3 panel c reads its six Average Module Control Strength values from
`reference_results/module_average_amcs.csv`. The file records the module-average
outgoing AMCS values (self-loops excluded), structural roles and display order;
the final figure script contains no embedded AMCS values. Source-panel assembly
is not a re-estimation of those panels from participant data. Final submission
images may include manual label-position adjustments and need not be
byte-identical to the assembled outputs.

## Reproduce the SEARCH analyses with authorized data

With authorised participant data configured, use reduced resampling for a
pipeline smoke test:

```bash
python run_all.py --quick
```

For the manuscript resample counts (SEARCH CLPN 1,000; DAG 200; community 100;
degree-preserving null models 500):

```bash
python run_all.py
python tests/01_validate_manuscript_values.py
```

The manuscript-value test requires locally generated analysis outputs and is
therefore not expected to run from the public package alone. The static package
integrity test can be run without restricted data:

```bash
python tests/00_validate_package.py
```

The static test checks Python syntax without creating bytecode caches, the
release manifest, retained original-source hashes and the AMCS reference schema.
It does not execute the individual-level analyses.

The baseline command uses the manuscript's recorded cross-validated value
`lambda = 0.05810199433648097`. To audit the selection step under the locally
installed scikit-learn version, run
`scripts/2.revision/pipeline/00_build_baseline_network.py --reselect-alpha`.
The selected grid point can change across scikit-learn versions; the recorded
value is the manuscript reproducibility target.

The estimator-sensitivity script similarly uses the three EBIC grid points
recorded for Supplementary Table S17. Add `--reselect-ebic` to audit EBIC
selection in another scikit-learn version. `run_all.py --quick` uses five MDS
draws for installation testing; the default uses the reported 60 draws.

`run_all.py --stage pipeline`, `--stage analyses`, and `--stage figures` can be
used independently. The `figures` stage calls the final Collection-specific
main- and supplementary-figure scripts. GMP and MCS raw-data analyses remain in the separately
packaged external-validation archive because those third-party datasets have
their own access conditions.

## Public-release boundary

Do not upload a working data directory or repack all locally generated outputs.
In particular, `w1_tmp.pkl`, `w3_items_tmp.pkl`, `matched_domain_scores.csv`,
`matched_W1_items.pkl`, `matched_W3_items.pkl` and `longitudinal_data.pkl`
contain or can contain participant-level records and must remain private.
The supplied `.env.example` has placeholder paths only; do not publish a real
`.env` containing credentials or private configuration.

`FILE_MANIFEST.tsv` lists the distributed files except the manifest itself.
Supplementary Data 1 is provided separately and retains the 23 machine-readable
aggregate result files described in the Supplementary Information.
