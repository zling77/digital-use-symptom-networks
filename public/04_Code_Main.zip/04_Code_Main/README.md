# Reproducibility code

This directory supports the analyses and final figures for **Emotional distress
drives change in adolescent problematic digital use and related symptoms**.

The original code layout is retained in `src/`, `scripts/0.preprocess/`, and
`scripts/1.experiments/`. Files added during manuscript revision are grouped in
`scripts/2.revision/`. No individual-level dataset is included.

## Directory map

```text
src/                         original reusable network code
scripts/0.preprocess/        legacy preprocessing notebooks (audit trail only)
scripts/1.experiments/       legacy experiment notebooks/scripts (audit trail only)
scripts/2.revision/pipeline/ longitudinal and baseline reproducibility pipeline
scripts/2.revision/analyses/ consolidated revision analyses
scripts/2.revision/figures/  final Collection-specific figure rebuild scripts
reference_results/           small non-identifying aggregate result tables
reference_figures_source/    two non-identifying source panels from the pipeline
tests/                       package and manuscript-value validation tools
outputs/                     locally generated outputs
```

`README_ORIGINAL.md` preserves the documentation that accompanied the initial
code package. The Collection-specific manuscript uses the newer figure scripts
documented below.

The notebooks under `scripts/0.preprocess/` and `scripts/1.experiments/` are
retained only as a legacy audit trail. Their saved outputs and execution counts
have been cleared. Use the executable scripts under `scripts/2.revision/` for
the submission analyses and figures.

## Environment

Create the tested environment:

```bash
conda env create -f environment.yml
conda activate psunet-repro
```

Alternatively, install `requirements.txt` in Python 3.10 or 3.11.

## Data configuration

Set `PSUNET_SEARCH_DATA_DIR` to a secure directory with the same internal layout
as the original `Code/data` directory:

```text
<SEARCH_DATA_DIR>/
  raw/1/.../common_info.csv
  raw/3/.../common_info.csv
  raw/3/.../scale_detailed_data/*_detailed_data.csv
  preprocessed/cleaned_scale_info.csv
```

Optionally set `PSUNET_OUTPUT_DIR` to choose the output directory. No personal
absolute path is embedded in executable source files.

## Rebuild the final Collection figures without individual-level data

The five main figures can be rebuilt from aggregate reference tables and the
two supplied non-identifying source panels:

```bash
python scripts/2.revision/figures/00_rebuild_collection_main_figures.py
```

Outputs are written to `outputs/collection_main_figures/`. The two
Supplementary Figures whose terminology changed in the final narrative can be
rebuilt with:

```bash
python scripts/2.revision/figures/01_rebuild_collection_supplementary_figures.py
```

Outputs are written to `outputs/collection_supplementary_figures/`.

Figure 3 panel c reads its six Average Module Control Strength values from
`reference_results/module_average_amcs.csv`. The file records the module-average
outgoing AMCS values (self-loops excluded), structural roles and display order;
the final figure script contains no embedded AMCS values.

The older `00_rebuild_main_figures.py` is retained only to preserve the audit
trail for the pre-reframing figure set; it is not the source of the final five
main figures.

## Reproduce the SEARCH analyses with authorized data

For a fast installation and path smoke test:

```bash
python run_all.py --quick
```

For the manuscript resample counts (SEARCH CLPN 1,000; DAG 200; community 100;
degree-preserving null models 500):

```bash
python run_all.py
python tests/01_validate_manuscript_values.py
```

The manuscript-value test requires locally generated analysis outputs and is
therefore not expected to run from the public package alone. The static package
integrity test can be run without restricted data:

```bash
python tests/00_validate_package.py
```

The baseline command uses the manuscript's recorded cross-validated value
`lambda = 0.05810199433648097`. To audit the selection step under the locally
installed scikit-learn version, run
`scripts/2.revision/pipeline/00_build_baseline_network.py --reselect-alpha`.
The selected grid point can change across scikit-learn versions; the recorded
value is the manuscript reproducibility target.

The estimator-sensitivity script similarly uses the three EBIC grid points
recorded for Supplementary Table S17. Add `--reselect-ebic` to audit EBIC
selection in another scikit-learn version. `run_all.py --quick` uses five MDS
draws for installation testing; the default uses the reported 60 draws.

`run_all.py --stage pipeline`, `--stage analyses`, and `--stage figures` can be
used independently. The `figures` stage calls the final Collection-specific
main- and supplementary-figure scripts. GMP and MCS raw-data analyses remain in the separately
packaged external-validation archive because those third-party datasets have
their own access conditions.
