"""Portable paths shared by every executable script in this package."""
from __future__ import annotations

import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
SEARCH_DATA_DIR = Path(os.environ.get("PSUNET_SEARCH_DATA_DIR", PROJECT_ROOT / "data")).expanduser().resolve()
OUTPUT_DIR = Path(os.environ.get("PSUNET_OUTPUT_DIR", PROJECT_ROOT / "outputs")).expanduser().resolve()
REFERENCE_DIR = PROJECT_ROOT / "reference_results"
BASELINE_DIR = OUTPUT_DIR / "baseline_network"


def ensure_output_dir() -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    BASELINE_DIR.mkdir(parents=True, exist_ok=True)
    return OUTPUT_DIR


def resolve_input(name: str) -> Path:
    """Resolve an input by stable filename, never by a personal absolute path."""
    clean = Path(name).name
    clean = __import__("re").sub(r"^v[0-9a-f]{8}_", "", clean, flags=__import__("re").I)
    direct = [
        OUTPUT_DIR / clean,
        BASELINE_DIR / clean,
        REFERENCE_DIR / clean,
        SEARCH_DATA_DIR / "preprocessed" / clean,
        SEARCH_DATA_DIR / clean,
    ]
    for candidate in direct:
        if candidate.exists():
            return candidate
    for root in (OUTPUT_DIR, REFERENCE_DIR, SEARCH_DATA_DIR):
        if root.exists():
            matches = list(root.rglob(clean))
            if matches:
                return matches[0]
    raise FileNotFoundError(
        f"Required input {clean!r} was not found. Set PSUNET_SEARCH_DATA_DIR "
        "to the secure SEARCH data directory or run the preceding stage."
    )
