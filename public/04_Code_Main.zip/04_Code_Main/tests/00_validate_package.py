"""Static package checks: source integrity, syntax, and path portability."""
from __future__ import annotations

import ast
import csv
import hashlib
import json
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    for source in ROOT.rglob("*.py"):
        ast.parse(source.read_text(encoding="utf-8-sig"), filename=str(source))
    with (ROOT / "FILE_MANIFEST.tsv").open(encoding="utf-8", newline="") as handle:
        entries = list(csv.DictReader(handle, delimiter="\t"))
    for entry in entries:
        relative = entry["relative_path"]
        source = (ROOT / relative).resolve()
        if ROOT not in source.parents:
            raise AssertionError(f"Unsafe manifest path: {relative}")
        data = source.read_bytes()
        if len(data) != int(entry["bytes"]) or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise AssertionError(f"Release file changed: {relative}")
    expected = json.loads((ROOT / "tests" / "original_code_sha256.json").read_text(encoding="utf-8"))
    for relative, digest in expected.items():
        source = ROOT / relative
        actual = hashlib.sha256(source.read_bytes()).hexdigest()
        if actual != digest:
            raise AssertionError(f"Original source changed: {relative}")
    forbidden_terms = ["/" + "Users/", "D:" + "\\\\ALLpostgraduate", "C:" + "\\\\Users", "host." + "artifact_path"]
    forbidden = re.compile("|".join(re.escape(term) for term in forbidden_terms))
    for source in ROOT.rglob("*"):
        if source.resolve() == Path(__file__).resolve():
            continue
        if source.is_file() and source.suffix.lower() in {".py", ".md", ".yml", ".txt"}:
            text = source.read_text(encoding="utf-8", errors="ignore")
            if forbidden.search(text):
                raise AssertionError(f"Machine-specific path remains in {source.relative_to(ROOT)}")
    with (ROOT / "reference_results" / "module_average_amcs.csv").open(
        encoding="utf-8", newline=""
    ) as handle:
        amcs_rows = list(csv.DictReader(handle))
    expected_domains = ["DIET", "SDQ", "DASS", "CIAS", "ACT", "ISI"]
    if [row["domain"] for row in amcs_rows] != expected_domains:
        raise AssertionError("module_average_amcs.csv has an unexpected domain order")
    if [int(row["display_order"]) for row in amcs_rows] != list(range(1, 7)):
        raise AssertionError("module_average_amcs.csv display_order must be 1 through 6")
    if any(
        not math.isfinite(float(row["average_amcs"])) or float(row["average_amcs"]) < 0
        for row in amcs_rows
    ):
        raise AssertionError("module_average_amcs.csv contains an invalid AMCS value")
    print(f"PASS: {len(entries)} release files match the manifest")
    print(f"PASS: {len(expected)} retained original files match their SHA-256 hashes")
    print("PASS: Python syntax is valid and no machine-specific path remains")
    print("PASS: Figure 3 AMCS data are machine-readable and schema-valid")


if __name__ == "__main__":
    main()
