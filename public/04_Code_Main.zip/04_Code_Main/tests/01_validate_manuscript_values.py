"""Validate central reproduced values against the manuscript reference outputs."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))
from project_paths import OUTPUT_DIR, REFERENCE_DIR


def close(actual: float, expected: float, tolerance: float, label: str) -> None:
    if not np.isfinite(actual) or abs(actual - expected) > tolerance:
        raise AssertionError(f"{label}: actual={actual}, expected={expected}, tolerance={tolerance}")
    print(f"PASS {label}: {actual:.6g}")


def main() -> None:
    expected = json.loads((REFERENCE_DIR / "expected_results.json").read_text(encoding="utf-8"))
    meta = json.loads((OUTPUT_DIR / "real_meta.json").read_text(encoding="utf-8"))
    close(len(meta["node_order"]), expected["nodes"], 0, "node count")
    adjacency = np.load(OUTPUT_DIR / "real_adj.npy")
    close(adjacency.sum() / 2, expected["edges"], 0, "edge count")
    close(adjacency.sum() / (len(adjacency) * (len(adjacency) - 1)), expected["density"], 5e-4, "density")
    close(float(meta["alpha"]), expected["alpha"], 1e-12, "recorded CV alpha")
    with (OUTPUT_DIR / "network_objects.pkl").open("rb") as handle:
        import pickle
        network = pickle.load(handle)
    close(int(network["mds_size"]), expected["mds_size"], 0, "MDS size")
    close(len(network["mds_solutions"]), expected["mds_solutions"], 0, "MDS solution count")
    for node, value in expected["control_frequency"].items():
        close(float(network["mds_cf"][node]), value, 1e-12, f"control frequency {node}")
    with (OUTPUT_DIR / "longitudinal_data.pkl").open("rb") as handle:
        longitudinal = pickle.load(handle)
    close(int(longitudinal["n_matched"]), expected["matched_n"], 0, "matched longitudinal N")

    clpn = pd.read_csv(OUTPUT_DIR / "clpn_directionality.csv").set_index("domain")
    for domain, value in expected["clpn_net"].items():
        close(float(clpn.loc[domain, "net"]), value, 5e-4, f"CLPN net {domain}")

    coefficients = pd.read_csv(OUTPUT_DIR / "clpn_coefficients.csv", index_col=0)
    coefficients.index = [str(value).removesuffix("_w1") for value in coefficients.index]
    coefficients.columns = [str(value).removesuffix("_w3") for value in coefficients.columns]
    for path, value in expected["clpn_paths"].items():
        predictor, outcome = path.split("->")
        close(float(coefficients.loc[predictor, outcome]), value, 5e-4, f"CLPN {path}")

    if (OUTPUT_DIR / "dag_robustness.csv").exists():
        dag = pd.read_csv(OUTPUT_DIR / "dag_robustness.csv").set_index("domain")
        for domain, value in expected["dag_tertile_net"].items():
            close(float(dag.loc[domain, "net_outdeg_tertile"]), value, 0, f"DAG net {domain}")
        agreement = pd.read_csv(OUTPUT_DIR / "dag_agreement_robustness.csv").iloc[0]
        close(float(agreement["pearson_r"]), expected["dag_clpn_r"], 5e-4, "DAG-CLPN Pearson r")

    if (OUTPUT_DIR / "community_evolution_summary.csv").exists():
        community = pd.read_csv(OUTPUT_DIR / "community_evolution_summary.csv").iloc[0]
        close(float(community["ARI"]), expected["cross_wave_ari"], 5e-4, "cross-wave community ARI")
        close(float(community["changed_nodes"]), expected["changed_nodes"], 0, "changed community nodes")

    if (OUTPUT_DIR / "network_estimation_robustness.csv").exists():
        robustness = pd.read_csv(OUTPUT_DIR / "network_estimation_robustness.csv").set_index("network")
        for network_name, target in expected["estimator_sensitivity"].items():
            close(float(robustness.loc[network_name, "density"]), target["density"], 5e-4, f"density {network_name}")
            close(float(robustness.loc[network_name, "mds_size"]), target["mds_size"], 0, f"MDS size {network_name}")


if __name__ == "__main__":
    main()
