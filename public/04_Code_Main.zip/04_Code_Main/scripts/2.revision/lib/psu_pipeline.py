import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
PSU symptom-network control pipeline (Route-1 analyses).

Reproduces the manuscript's core workflow and adds the reviewer-facing upgrades:
  - non-paranormal (rank) transform -> GraphicalLassoCV GGM
  - partial-correlation network + binarized adjacency
  - topological + linear controllability metrics
  - exhaustive Minimum Dominating Set (MDS) enumeration + Control Frequency (CF)
  - Modular Control Network (MCN) with Average Module Control Strength (AMCS)

USAGE
-----
    from psu_pipeline import load_items, build_network, enumerate_mds, mcn_from_mds
    df, nodes, mod_of, modules = load_items("synthetic_psu_items.csv.gz",
                                            "psu_meta.json")
    net = build_network(df[nodes])          # dict: pcor, adj, G, ...
    mds = enumerate_mds(net["adj"], nodes)  # dict: solutions, cf, size, ...
    mcn = mcn_from_mds(mds, net, nodes, mod_of, modules)

To run on the REAL data, point load_items at the real 104-column item matrix
(same column names) — everything downstream is data-agnostic.
"""
import numpy as np, pandas as pd, json, itertools, networkx as nx
from scipy.stats import norm, rankdata
from sklearn.covariance import GraphicalLassoCV, GraphicalLasso


# --------------------------------------------------------------------------- #
# 0. IO
# --------------------------------------------------------------------------- #
def load_items(data_path, meta_path):
    df = pd.read_csv(data_path) if data_path.endswith((".csv", ".gz")) \
        else pd.read_parquet(data_path)
    meta = json.load(open(meta_path))
    nodes = meta["node_names"]
    mod_of = dict(zip(meta["node_names"], meta["node_mod"]))
    modules = meta["modules"]
    return df, nodes, mod_of, modules


# --------------------------------------------------------------------------- #
# 1. Non-paranormal transform
# --------------------------------------------------------------------------- #
def nonparanormal(X):
    """Rank-based transform of each column to standard normal (Liu et al. 2009)."""
    X = np.asarray(X, float)
    n, p = X.shape
    out = np.empty_like(X)
    for j in range(p):
        r = rankdata(X[:, j], method="average") / (n + 1)
        out[:, j] = norm.ppf(r)
    return out


# --------------------------------------------------------------------------- #
# 2. GGM estimation -> partial correlations -> binarized adjacency
# --------------------------------------------------------------------------- #
def build_network(X_df, cv=5, alpha=None, seed=0):
    """Estimate a sparse GGM. If alpha is None, use CV; else fixed lambda."""
    nodes = list(X_df.columns)
    Xn = nonparanormal(X_df.values)
    Xn = (Xn - Xn.mean(0)) / Xn.std(0)
    if alpha is None:
        model = GraphicalLassoCV(cv=cv, max_iter=200)
    else:
        model = GraphicalLasso(alpha=alpha, max_iter=200)
    model.fit(Xn)
    prec = model.precision_.copy()
    d = np.sqrt(np.diag(prec))
    pcor = -prec / np.outer(d, d)
    np.fill_diagonal(pcor, 0.0)
    A_abs = np.abs(pcor)
    adj = (A_abs > 1e-8).astype(int)          # binarized (sparsity from Lasso)
    np.fill_diagonal(adj, 0)
    G = nx.from_numpy_array(A_abs)
    G = nx.relabel_nodes(G, {i: nodes[i] for i in range(len(nodes))})
    return dict(pcor=pcor, A_abs=A_abs, adj=adj, G=G, nodes=nodes,
                alpha=(model.alpha_ if alpha is None else alpha))


# --------------------------------------------------------------------------- #
# 3. Global / nodal topology
# --------------------------------------------------------------------------- #
def global_metrics(net):
    G = net["G"]; adj = net["adj"]
    Gb = nx.from_numpy_array(adj)
    n = G.number_of_nodes(); m = int(adj.sum() // 2)
    density = 2 * m / (n * (n - 1))
    metrics = dict(
        n_nodes=n, n_edges=m, density=density,
        avg_clustering=nx.average_clustering(Gb),
        transitivity=nx.transitivity(Gb),
        global_efficiency=nx.global_efficiency(Gb),
        global_strength=float(net["A_abs"].sum() / 2),
    )
    if nx.is_connected(Gb):
        metrics["diameter"] = nx.diameter(Gb)
        metrics["avg_path_len"] = nx.average_shortest_path_length(Gb)
    return metrics


def nodal_strength_z(net):
    s = net["A_abs"].sum(1)
    return pd.Series((s - s.mean()) / s.std(), index=net["nodes"])


# --------------------------------------------------------------------------- #
# 4. MDS enumeration + Control Frequency
# --------------------------------------------------------------------------- #
def _is_dominating(adj, subset, n):
    covered = set(subset)
    for v in subset:
        covered |= set(np.nonzero(adj[v])[0])
    return len(covered) == n


def enumerate_mds(adj, nodes, max_size=6, ilp_first=True):
    """
    Find minimum dominating set size, then enumerate ALL MDS of that size.
    Uses an ILP (pulp) to get the size fast if available; falls back to
    increasing-size search. Enumeration of all-optimal is combinatorial but
    the manuscript networks yield MDS size ~3.
    """
    n = len(nodes)
    A = np.asarray(adj)
    # closed-neighborhood cover sets
    N = [set(np.nonzero(A[v])[0]) | {v} for v in range(n)]

    # ---- find MDS size ----
    size = None
    try:
        if ilp_first:
            import pulp
            prob = pulp.LpProblem("mds", pulp.LpMinimize)
            x = [pulp.LpVariable(f"x{i}", cat="Binary") for i in range(n)]
            prob += pulp.lpSum(x)
            for v in range(n):
                prob += pulp.lpSum(x[u] for u in N[v]) >= 1
            prob.solve(pulp.PULP_CBC_CMD(msg=0))
            size = int(round(sum(v.value() for v in x)))
    except Exception:
        size = None
    if size is None:                       # greedy upper bound then verify
        for k in range(1, max_size + 1):
            found = any(_is_dominating(A, c, n)
                        for c in itertools.combinations(range(n), k))
            if found:
                size = k; break

    # ---- enumerate all MDS of that size ----
    # prune: only nodes that can be in some cover; use combinations over
    # candidate high-degree nodes to bound cost.
    sols = []
    # candidate restriction: a node with tiny neighborhood rarely helps but
    # to stay exact we keep all; combinations(n, size) with n=104,size=3 ~ 1.8e5
    for c in itertools.combinations(range(n), size):
        if _is_dominating(A, c, n):
            sols.append(tuple(sorted(c)))
    # control frequency
    cf = {nodes[v]: 0.0 for v in range(n)}
    for s in sols:
        for v in s:
            cf[nodes[v]] += 1
    ns = max(len(sols), 1)
    cf = {k: v / ns for k, v in cf.items()}
    return dict(size=size, solutions=sols, n_solutions=len(sols),
                cf=cf, nodes=nodes)


# --------------------------------------------------------------------------- #
# 5. Modular Control Network (MCN) + AMCS
# --------------------------------------------------------------------------- #
def mcn_from_mds(mds, net, nodes, mod_of, modules):
    """
    For each MDS solution, a driver's dominating domain = itself + neighbors.
    Source module S dominates target module T = fraction of T's nodes covered
    by union of dominating domains of drivers in S. AMCS = avg over solutions.
    """
    A = net["adj"]; idx = {nd: i for i, nd in enumerate(nodes)}
    mod_list = list(modules.keys())
    mod_nodes = {m: [nd for nd in nodes if mod_of[nd] == m] for m in mod_list}
    # accumulate per-solution coverage
    amcs_acc = {(s, t): [] for s in mod_list for t in mod_list}
    for sol in mds["solutions"]:
        # dominating domain per driver
        dom = {}
        for v in sol:
            nd = nodes[v]
            dom[nd] = set([nodes[v]]) | {nodes[u] for u in np.nonzero(A[v])[0]}
        # per source module: union of its drivers' domains
        for s in mod_list:
            s_drivers = [nodes[v] for v in sol if mod_of[nodes[v]] == s]
            cover = set().union(*[dom[d] for d in s_drivers]) if s_drivers else set()
            for t in mod_list:
                tn = mod_nodes[t]
                frac = len([x for x in tn if x in cover]) / len(tn) if tn else 0.0
                amcs_acc[(s, t)].append(frac)
    amcs = {k: (np.mean(v) if v else 0.0) for k, v in amcs_acc.items()}
    # directed module graph (no self loops)
    M = nx.DiGraph()
    M.add_nodes_from(mod_list)
    for (s, t), w in amcs.items():
        if s != t and w > 0:
            M.add_edge(s, t, weight=w)
    out_strength = {m: sum(amcs[(m, t)] for t in mod_list if t != m) for m in mod_list}
    in_strength = {m: sum(amcs[(s, m)] for s in mod_list if s != m) for m in mod_list}
    avg_amcs = {m: np.mean([amcs[(m, t)] for t in mod_list if t != m]) for m in mod_list}
    return dict(amcs=amcs, M=M, mod_list=mod_list,
                out_strength=out_strength, in_strength=in_strength,
                avg_amcs=avg_amcs, mod_nodes=mod_nodes)


# --------------------------------------------------------------------------- #
# 6. Linear controllability (average + modal)
# --------------------------------------------------------------------------- #
def controllability(net):
    from scipy.linalg import solve_discrete_lyapunov, eig
    A = net["A_abs"].copy()
    # rescale spectral radius < 1
    ev = np.abs(np.linalg.eigvals(A)).max()
    A = A / (ev * 1.001 + 1e-9)
    n = A.shape[0]
    w, V = eig(A)
    ac, mc = np.zeros(n), np.zeros(n)
    for i in range(n):
        B = np.zeros((n, 1)); B[i] = 1
        try:
            W = solve_discrete_lyapunov(A, B @ B.T)
            ac[i] = np.trace(W)
        except Exception:
            ac[i] = np.nan
        # modal controllability
        mc[i] = np.sum((1 - np.abs(w) ** 2) * (np.abs(V[i, :]) ** 2))
    return pd.DataFrame({"avg_control": ac, "modal_control": mc}, index=net["nodes"])
