"""Step 1a: clean Wave-1 export into item matrix + hashed link key.

Inputs:
  ../../Code/data/raw/1/**/common_info.csv
  ../../Code/data/preprocessed/cleaned_scale_info.csv
  real_meta.json

Produces:
  w1_tmp.pkl
"""

from __future__ import annotations

import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)


import hashlib
import json
from pathlib import Path

import pandas as pd


PIPELINE_DIR = ensure_output_dir()
RAW1_DIR = SEARCH_DATA_DIR / "raw" / "1"


def norm_birthday(value) -> str:
    text = str(value).strip()
    if text.endswith(".0"):
        text = text[:-2]
    return text


def hkey(name, birthday, gender) -> str:
    value = f"{str(name).strip()}|{norm_birthday(birthday)}|{str(gender).strip()}"
    return hashlib.sha1(value.encode()).hexdigest()[:16]


def main() -> None:
    meta = json.load(open(PIPELINE_DIR / "real_meta.json", encoding="utf-8"))
    node_order = meta["node_order"]

    common_files = list(RAW1_DIR.glob("**/common_info.csv"))
    if not common_files:
        raise FileNotFoundError(f"Cannot find Wave-1 common_info.csv under {RAW1_DIR}")
    common_path = common_files[0]

    w1c = pd.read_csv(common_path, usecols=["cust_id", "real_name", "birthday", "gender"])
    w1c["linkkey"] = [hkey(n, b, g) for n, b, g in zip(w1c.real_name, w1c.birthday, w1c.gender)]

    scale_path = SEARCH_DATA_DIR / "preprocessed" / "cleaned_scale_info.csv"
    scale = pd.read_csv(scale_path, usecols=["cust_id"] + node_order)

    w1 = scale.merge(w1c[["cust_id", "linkkey"]], on="cust_id", how="inner")
    w1.to_pickle(PIPELINE_DIR / "w1_tmp.pkl")
    print("W1:", w1.shape)
    print("saved w1_tmp.pkl")


if __name__ == "__main__":
    main()
