"""Step 1b: clean Wave-3 raw CSV exports into item matrix.

Inputs:
  ../../Code/data/raw/3/**/scale_detailed_data/*_detailed_data.csv
  real_meta.json

Produces:
  w3_items_tmp.pkl
"""

from __future__ import annotations

import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)


import json
import os
from pathlib import Path

import pandas as pd


PIPELINE_DIR = ensure_output_dir()
RAW3_DIR = SEARCH_DATA_DIR / "raw" / "3"
DEFAULT_W3_SOURCE_DIR = RAW3_DIR

MODULE_TO_STEM = {
    "CIAS": "cias-r",
    "DASS": "dass",
    "ISI": "isi",
    "DIET": "diet",
    "SDQ": "sdq",
    "ACT": "activity",
}


def w3_source_dir() -> Path:
    configured = os.environ.get("W3_RAW_DIR")
    if configured:
        path = Path(configured)
        if path.exists():
            return path
        raise FileNotFoundError(f"W3_RAW_DIR does not exist: {path}")
    if DEFAULT_W3_SOURCE_DIR.exists():
        return DEFAULT_W3_SOURCE_DIR
    return RAW3_DIR


def find_detail_file(stem: str) -> Path:
    source_dir = w3_source_dir()
    matches = list(source_dir.glob(f"**/scale_detailed_data/{stem}_detailed_data.csv"))
    if not matches:
        raise FileNotFoundError(f"Cannot find Wave-3 detail file for {stem!r} under {source_dir}")
    return matches[0]


def main() -> None:
    meta = json.load(open(PIPELINE_DIR / "real_meta.json", encoding="utf-8"))
    node_order = meta["node_order"]
    mod_of = meta["mod_of"]

    w3 = None
    print("Wave-3 source:", w3_source_dir())
    for module, stem in MODULE_TO_STEM.items():
        cols = [c for c in node_order if mod_of[c] == module]
        f = find_detail_file(stem)
        d = pd.read_csv(f, usecols=["cust_id"] + cols)
        d = d.drop_duplicates("cust_id")
        w3 = d if w3 is None else w3.merge(d, on="cust_id", how="inner")
        print(module, "merged ->", w3.shape)

    w3.to_pickle(PIPELINE_DIR / "w3_items_tmp.pkl")
    print("saved w3_items_tmp.pkl")


if __name__ == "__main__":
    main()
