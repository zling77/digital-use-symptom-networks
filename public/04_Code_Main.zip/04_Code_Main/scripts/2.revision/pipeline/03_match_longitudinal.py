"""Step 2: hash-match W1/W3 individuals and build longitudinal matrices.

Inputs:
  w1_tmp.pkl
  w3_items_tmp.pkl
  scale_crosswalk.csv
  real_meta.json
  ../../Code/data/raw/3/**/common_info.csv
  ../../Code/data/raw/3/**/diet_score_data.xlsx, when available

Produces:
  longitudinal_data.pkl
  matched_domain_scores.csv
  matched_W1_items.pkl
  matched_W3_items.pkl
  comparable_nodes.json
"""

from __future__ import annotations

import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)


import hashlib
import json
import os
import pickle
from pathlib import Path

import pandas as pd
from scipy.stats import zscore


PIPELINE_DIR = ensure_output_dir()
RAW3_DIR = SEARCH_DATA_DIR / "raw" / "3"
W3_DIET_XLSX_NAME = "diet_score_data.xlsx"
DOMAINS = ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]


def norm_birthday(value) -> str:
    text = str(value).strip()
    if text.endswith(".0"):
        text = text[:-2]
    return text


def hkey(name, birthday, gender) -> str:
    value = f"{str(name).strip()}|{norm_birthday(birthday)}|{str(gender).strip()}"
    return hashlib.sha1(value.encode()).hexdigest()[:16]


def normalize_w3_gender(value) -> str:
    text = str(value).strip()
    return {"\u7537": "male", "\u5973": "female"}.get(text, text)


def w3_source_dir() -> Path:
    configured = os.environ.get("W3_RAW_DIR")
    if configured:
        path = Path(configured)
        if path.exists():
            return path
        raise FileNotFoundError(f"W3_RAW_DIR does not exist: {path}")

    diet_xlsx_matches = list(RAW3_DIR.glob(f"**/{W3_DIET_XLSX_NAME}"))
    if diet_xlsx_matches:
        return diet_xlsx_matches[0].parent

    common_info_matches = list(RAW3_DIR.glob("**/common_info.csv"))
    if common_info_matches:
        return common_info_matches[0].parent

    return RAW3_DIR


def find_w3_common_info() -> Path:
    source_dir = w3_source_dir()
    matches = list(source_dir.glob("**/common_info.csv"))
    if not matches:
        raise FileNotFoundError(f"Cannot find Wave-3 common_info.csv under {source_dir}")
    return matches[0]


def replace_w3_diet_from_original_export(
    w3: pd.DataFrame, node_order: list[str], mod_of: dict[str, str]
) -> pd.DataFrame:
    """Use original Wave-3 DIET raw option columns when the workbook is present.

    The third-wave detailed CSV contains derived binary score columns for DIET10-22.
    The longitudinal manuscript analysis used the original diet_m10-diet_m22
    1-8 response scale, so this replacement is required for exact reproduction.
    """

    diet_xlsx = w3_source_dir() / W3_DIET_XLSX_NAME
    if not diet_xlsx.exists():
        print(f"Wave-3 original DIET workbook not found; using existing DIET score columns: {diet_xlsx}")
        return w3

    diet_cols = [c for c in node_order if mod_of[c] == "DIET"]
    raw_cols = ["cust_id"] + [f"diet_m{i:02d}" for i in range(1, 23)]
    diet_raw = pd.read_excel(diet_xlsx, usecols=raw_cols)
    diet_raw = diet_raw.rename(columns={f"diet_m{i:02d}": f"diet_question{i}_score" for i in range(1, 23)})
    diet_raw = diet_raw[["cust_id"] + diet_cols].drop_duplicates("cust_id")

    non_diet_cols = [
        c for c in w3.columns if not (c.startswith("diet_question") and c.endswith("_score"))
    ]
    out = w3[non_diet_cols].merge(diet_raw, on="cust_id", how="inner")
    print(f"Wave-3 DIET source: {diet_xlsx}")
    print(f"Wave-3 DIET original rows after cust_id dedupe: {len(diet_raw)}")
    return out


def domain_scores(matrix: pd.DataFrame, node_order: list[str], mod_of: dict[str, str]) -> pd.DataFrame:
    out = {}
    for module in DOMAINS:
        cols = [c for c in node_order if mod_of[c] == module]
        out[module] = matrix[cols].apply(zscore, ddof=0).mean(axis=1)
    return pd.DataFrame(out, index=matrix.index)


def main() -> None:
    meta = json.load(open(PIPELINE_DIR / "real_meta.json", encoding="utf-8"))
    node_order = meta["node_order"]
    mod_of = meta["mod_of"]

    w1 = pd.read_pickle(PIPELINE_DIR / "w1_tmp.pkl")
    w3 = pd.read_pickle(PIPELINE_DIR / "w3_items_tmp.pkl")
    w3 = replace_w3_diet_from_original_export(w3, node_order, mod_of)

    print("Wave-3 source:", w3_source_dir())
    w3c = pd.read_csv(find_w3_common_info(), usecols=["cust_id", "real_name", "birthday", "gender"])
    w3c["linkkey"] = [
        hkey(n, b, normalize_w3_gender(g)) for n, b, g in zip(w3c.real_name, w3c.birthday, w3c.gender)
    ]
    w3 = w3.merge(w3c[["cust_id", "linkkey"]], on="cust_id", how="inner")

    k1 = w1["linkkey"]
    k3 = w3["linkkey"]
    bad = set(k1[k1.duplicated(keep=False)]) | set(k3[k3.duplicated(keep=False)])
    w1u = w1[~w1["linkkey"].isin(bad)].set_index("linkkey")
    w3u = w3[~w3["linkkey"].isin(bad)].set_index("linkkey")
    common = sorted(set(w1u.index) & set(w3u.index))

    crosswalk = pd.read_csv(PIPELINE_DIR / "scale_crosswalk.csv")
    w1m = w1u.loc[common, node_order].apply(pd.to_numeric, errors="coerce")
    w3m = w3u.loc[common, crosswalk["w3_col"].tolist()].apply(pd.to_numeric, errors="coerce")
    w3m.columns = crosswalk["w1_col"].tolist()
    w3p = w3m[node_order].copy()

    for q in [7, 11, 14, 21, 25]:
        col = f"sdq_question{q}_score"
        if col in w3p.columns:
            w3p[col] = 2 - w3p[col]

    for col in node_order:
        if mod_of[col] in ("DIET", "ACT"):
            w3p[col] = w3p[col] - 1

    d1 = domain_scores(w1m, node_order, mod_of)
    d3 = domain_scores(w3p, node_order, mod_of)
    d1.columns = [f"{c}_w1" for c in d1.columns]
    d3.columns = [f"{c}_w3" for c in d3.columns]

    domains = pd.concat([d1, d3], axis=1)
    domains.to_csv(PIPELINE_DIR / "matched_domain_scores.csv")
    w1m.to_pickle(PIPELINE_DIR / "matched_W1_items.pkl")
    w3p.to_pickle(PIPELINE_DIR / "matched_W3_items.pkl")

    diet_comparable = [
        "diet_question2_score",
        "diet_question5_score",
        "diet_question6_score",
        "diet_question7_score",
        "diet_question8_score",
        "diet_question9_score",
    ]
    comparable_nodes = [c for c in node_order if mod_of[c] != "DIET"] + diet_comparable
    json.dump(
        {
            "comparable_nodes": comparable_nodes,
            "diet_version_changed": [
                c for c in node_order if mod_of[c] == "DIET" and c not in diet_comparable
            ],
        },
        open(PIPELINE_DIR / "comparable_nodes.json", "w", encoding="utf-8"),
        ensure_ascii=False,
        indent=2,
    )

    longitudinal = {
        "D1": d1,
        "D3": d3,
        "W1m": w1m,
        "W3p": w3p,
        "node_order": node_order,
        "mod_of": mod_of,
        "comparable_nodes": comparable_nodes,
        "n_matched": len(w1m),
    }
    pickle.dump(longitudinal, open(PIPELINE_DIR / "longitudinal_data.pkl", "wb"))
    print("matched n:", len(w1m), "| comparable item nodes:", len(comparable_nodes))


if __name__ == "__main__":
    main()
