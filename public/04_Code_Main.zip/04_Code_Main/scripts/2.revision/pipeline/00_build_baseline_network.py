"""Build the baseline 104-node network and portable downstream checkpoints."""
from __future__ import annotations

import argparse
import json
import pickle
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = next(p for p in [Path(__file__).resolve().parent, *Path(__file__).resolve().parents] if (p / "project_paths.py").exists())
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from project_paths import SEARCH_DATA_DIR, OUTPUT_DIR, BASELINE_DIR, ensure_output_dir
from src.ModuleControlNetwork import ModuleControlNetwork

PUBLISHED_CV_ALPHA = 0.05810199433648097


def module_of(name: str) -> str:
    prefixes = {
        "cias-r_question": "CIAS", "dass_question": "DASS", "sdq_question": "SDQ",
        "diet_question": "DIET", "isi_question": "ISI", "activity_question": "ACT",
    }
    for prefix, domain in prefixes.items():
        if name.startswith(prefix):
            return domain
    raise ValueError(f"Unrecognized item column: {name}")


def item_number(name: str) -> int:
    match = re.search(r"question(\d+)_score$", name)
    return int(match.group(1)) if match else 10**9


def find_w3_file(stem: str) -> Path:
    matches = list((SEARCH_DATA_DIR / "raw" / "3").glob(f"**/scale_detailed_data/{stem}_detailed_data.csv"))
    if not matches:
        raise FileNotFoundError(f"Cannot find Wave-3 {stem!r} detailed CSV beneath SEARCH_DATA_DIR/raw/3")
    return matches[0]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--reselect-alpha", action="store_true",
        help="Repeat GraphicalLassoCV instead of using the manuscript's recorded CV-selected alpha.",
    )
    args = parser.parse_args()
    ensure_output_dir()
    cleaned = SEARCH_DATA_DIR / "preprocessed" / "cleaned_scale_info.csv"
    frame = pd.read_csv(cleaned)
    node_order = [column for column in frame.columns if column != "cust_id"]
    mod_of = {column: module_of(column) for column in node_order}
    if len(node_order) != 104:
        raise RuntimeError(f"Expected 104 item nodes; found {len(node_order)} in {cleaned}")

    network = ModuleControlNetwork(
        result_folder=BASELINE_DIR,
        data=frame[node_order],
        lasso_cv=args.reselect_alpha,
        lasso_cv_method="cv",
        lasso_alpha=None if args.reselect_alpha else PUBLISHED_CV_ALPHA,
        mds_method="precise",
        random_state=42,
    )
    network.build_network(domination_analysis=True, module_mapping=mod_of, module_analysis=True)

    solutions = [tuple(node_order.index(node) for node in solution) for solution in network.all_mds]
    control_frequency = {node: float(network.graph.nodes[node]["control_frequency"]) for node in node_order}
    checkpoint = {
        "pcor": network.sparse_matrix,
        "adj": (network.abs_sparse_matrix > 0).astype(int),
        "A_abs": network.abs_sparse_matrix,
        "node_order": node_order,
        "mod_of": mod_of,
        "alpha": float(network.lasso_alpha),
        "mds_solutions": solutions,
        "mds_cf": control_frequency,
        "mds_size": len(solutions[0]),
    }
    with (OUTPUT_DIR / "network_objects.pkl").open("wb") as handle:
        pickle.dump(checkpoint, handle)
    np.save(OUTPUT_DIR / "real_pcor.npy", network.sparse_matrix)
    np.save(OUTPUT_DIR / "real_Aabs.npy", network.abs_sparse_matrix)
    np.save(OUTPUT_DIR / "real_adj.npy", checkpoint["adj"])

    meta = {
        "node_order": node_order,
        "mod_of": mod_of,
        "alpha": float(network.lasso_alpha),
        "alpha_selection": "reselected by GraphicalLassoCV" if args.reselect_alpha else "recorded manuscript CV selection",
        "random_seed": 42,
    }
    (OUTPUT_DIR / "real_meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")

    stems = {"CIAS": "cias-r", "DASS": "dass", "SDQ": "sdq", "DIET": "diet", "ISI": "isi", "ACT": "activity"}
    headers = {domain: set(pd.read_csv(find_w3_file(stem), nrows=0).columns) for domain, stem in stems.items()}
    crosswalk = pd.DataFrame([
        {"module": mod_of[column], "item_num": item_number(column), "w1_col": column,
         "w3_col": column, "w3_exists": column in headers[mod_of[column]]}
        for column in node_order
    ])
    crosswalk.to_csv(OUTPUT_DIR / "scale_crosswalk.csv", index=False)
    missing = crosswalk.loc[~crosswalk["w3_exists"], "w1_col"].tolist()
    if missing:
        raise RuntimeError(f"Wave-3 item columns are missing: {missing}")

    print(f"baseline N={len(frame)}, nodes={len(node_order)}, edges={int(checkpoint['adj'].sum() // 2)}")
    print(f"alpha={network.lasso_alpha:.12g}, MDS size={checkpoint['mds_size']}, solutions={len(solutions)}")
    if args.reselect_alpha and not np.isclose(network.lasso_alpha, PUBLISHED_CV_ALPHA):
        print("NOTE: GraphicalLassoCV re-selection differs from the recorded manuscript alpha; "
              "omit --reselect-alpha for exact reproduction.")


if __name__ == "__main__":
    main()
