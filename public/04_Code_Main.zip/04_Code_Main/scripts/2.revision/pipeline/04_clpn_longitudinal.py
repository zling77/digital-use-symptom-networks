"""Step 4: cross-lagged panel network from local matched domain scores.

By default this skips bootstrap CIs so the non-stability pipeline can run quickly:
  python 05_clpn_longitudinal.py

To reproduce the original bootstrap CI later:
  python 05_clpn_longitudinal.py --bootstrap 1000

Produces:
  clpn_coefficients.csv
  clpn_pvalues.csv
  clpn_directionality.csv
"""

from __future__ import annotations

import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)


import argparse
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm


PIPELINE_DIR = ensure_output_dir()
DOMAINS = ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap", type=int, default=0, help="Bootstrap iterations for net-directionality CI.")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    longitudinal = pickle.load(open(PIPELINE_DIR / "longitudinal_data.pkl", "rb"))
    D1 = longitudinal["D1"]
    D3 = longitudinal["D3"]

    Dz1 = (D1 - D1.mean()) / D1.std()
    Dz3 = (D3 - D3.mean()) / D3.std()
    Dz1.columns = [c.replace("_w1", "") for c in Dz1.columns]
    Dz3.columns = [c.replace("_w3", "") for c in Dz3.columns]

    clpn = np.zeros((6, 6))
    auto = np.zeros(6)
    pvals = np.zeros((6, 6))
    X = sm.add_constant(Dz1[DOMAINS].values)
    for j, target in enumerate(DOMAINS):
        y = Dz3[target].values
        model = sm.OLS(y, X).fit(cov_type="HC3")
        betas = model.params[1:]
        ps = model.pvalues[1:]
        for i in range(6):
            if i == j:
                auto[j] = betas[i]
            clpn[i, j] = betas[i]
            pvals[i, j] = ps[i]

    cl = clpn.copy()
    np.fill_diagonal(cl, np.nan)
    outdeg = {d: np.nansum(np.abs(cl[i, :])) for i, d in enumerate(DOMAINS)}
    indeg = {d: np.nansum(np.abs(cl[:, j])) for j, d in enumerate(DOMAINS)}

    net_ci_lo = np.full(6, np.nan)
    net_ci_hi = np.full(6, np.nan)
    if args.bootstrap > 0:
        rng = np.random.default_rng(args.seed)
        n = len(Dz1)
        Xall = sm.add_constant(Dz1[DOMAINS].values)
        Yall = Dz3[DOMAINS].values
        boot_net = np.zeros((args.bootstrap, 6))
        for b in range(args.bootstrap):
            idx = rng.integers(0, n, n)
            Xb = Xall[idx]
            boot_cl = np.zeros((6, 6))
            for j in range(6):
                yb = Yall[idx, j]
                boot_cl[:, j] = np.linalg.lstsq(Xb, yb, rcond=None)[0][1:]
            np.fill_diagonal(boot_cl, np.nan)
            for d in range(6):
                boot_net[b, d] = np.nansum(np.abs(boot_cl[d, :])) - np.nansum(np.abs(boot_cl[:, d]))
        net_ci_lo, net_ci_hi = np.nanpercentile(boot_net, [2.5, 97.5], axis=0)

    row_idx = [f"{d}_w1" for d in DOMAINS]
    col_idx = [f"{d}_w3" for d in DOMAINS]
    pd.DataFrame(clpn, index=row_idx, columns=col_idx).to_csv(PIPELINE_DIR / "clpn_coefficients.csv")
    pd.DataFrame(pvals, index=row_idx, columns=col_idx).to_csv(PIPELINE_DIR / "clpn_pvalues.csv")

    netsum = pd.DataFrame(
        {
            "domain": DOMAINS,
            "out_strength": [outdeg[d] for d in DOMAINS],
            "in_strength": [indeg[d] for d in DOMAINS],
            "net": [outdeg[d] - indeg[d] for d in DOMAINS],
            "net_ci_lo": net_ci_lo,
            "net_ci_hi": net_ci_hi,
            "autoregression": auto,
            "role": [
                "source" if net_ci_lo[i] > 0 else ("sink" if net_ci_hi[i] < 0 else "ns")
                for i in range(6)
            ],
        }
    )
    netsum.to_csv(PIPELINE_DIR / "clpn_directionality.csv", index=False)
    print("saved clpn_coefficients.csv, clpn_pvalues.csv, clpn_directionality.csv")
    print(netsum.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
