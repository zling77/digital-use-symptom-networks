"""Rebuild the two supplementary figures whose titles changed in the final narrative."""
from __future__ import annotations

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
REF = ROOT / "reference_results"
OUT = ROOT / "outputs" / "collection_supplementary_figures"
OUT.mkdir(parents=True, exist_ok=True)

mpl.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "pdf.fonttype": 42,
    }
)
COLORS = {"CIAS": "#2C6798", "DASS": "#FF76DA", "SDQ": "#E58D00", "DIET": "#258B5E", "ISI": "#7C58A7", "ACT": "#59B5A6"}

# Supplementary Figure S6: target-set coverage, without temporal source/sink terminology.
target = pd.read_csv(REF / "target_controllability.csv")
labels = ["Whole network", "ISI + ACT", "DIET + SDQ", "CIAS", "DASS"]
values = target["n_drivers"].tolist()
counts = target["n_target"].tolist()
fig, ax = plt.subplots(figsize=(6.0, 5.0))
bars = ax.bar(range(len(values)), values, color="#4C78A8", edgecolor="black", linewidth=0.7)
ax.set_xticks(range(len(values)))
ax.set_xticklabels(labels, rotation=25, ha="right")
ax.set_ylabel("Minimum set-cover nodes")
ax.set_title("Target-set coverage requirements", fontweight="bold", pad=10)
ax.set_ylim(0, max(values) + 0.8)
for bar, value, count in zip(bars, values, counts):
    ax.text(bar.get_x() + bar.get_width() / 2, value + 0.08, f"{value}\n(of {count})", ha="center", va="bottom", fontsize=9)
fig.tight_layout()
fig.savefig(OUT / "Figure_S6.png", bbox_inches="tight", facecolor="white")
plt.close(fig)

# Supplementary Figure S12: simulation response, without source/sink terminology.
dynamics = pd.read_csv(REF / "dynamics_summary.csv").set_index("module")
order = ["SDQ", "DASS", "CIAS", "DIET", "ISI", "ACT"]
values = dynamics.loc[order, "total_activation"].tolist()
fig, ax = plt.subplots(figsize=(6.0, 5.0))
bars = ax.bar(order, values, color=[COLORS[d] for d in order], edgecolor="black", linewidth=0.7)
ax.set_ylabel("Steady-state total activation")
ax.set_title("Steady-state response by perturbed module", fontweight="bold", pad=10)
ax.set_ylim(0, max(values) + 5)
for bar, value in zip(bars, values):
    ax.text(bar.get_x() + bar.get_width() / 2, value + 0.35, f"{value:.0f}", ha="center", va="bottom", fontsize=9)
fig.tight_layout()
fig.savefig(OUT / "Figure_S12.png", bbox_inches="tight", facecolor="white")
plt.close(fig)

print(f"Collection supplementary figures written to {OUT}")
