import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Figure S5 — dynamical diffusion, targeted attack, steady-state activation

Produces : knockout_dynamics.png

As-run figure code (environment: psunet, seed 42, 300 dpi, MCOL domain palette).
Data-store paths point to the reproducible checkpoints / reviewer data tables;
repoint resolve_input(...) / absolute <legacy-artifacts>/... to local copies to re-run.
Each script contains a self-contained apply_figure_style() and the MCOL palette.
"""

import pickle
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


apply_figure_style()
MCOL = {"CIAS": "#2c5f8a", "DASS": "#FF76DA", "SDQ": "#e08e0b", "DIET": "#27865a", "ISI": "#7d5ba6", "ACT": "#5bb5a2"}
curves = pickle.load(open(str(resolve_input('attack_curves.pkl')), "rb"))
dyn = pickle.load(open(str(resolve_input('dynamics_sim.pkl')), "rb"))
fig, axes = plt.subplots(1, 3, figsize=(15.5, 4.8))

cols = {"MDS drivers (CF)": "#FF76DA", "Strength": "#2c5f8a", "Bridge strength": "#27865a",
        "Betweenness": "#e08e0b", "Random (avg)": "0.5"}

# Panel A (replace): dynamics time-course - activation trajectory per perturbed module
ax = axes[0]
for m in ["SDQ", "DASS", "CIAS", "DIET", "ISI", "ACT"]:
    ax.plot(range(len(dyn["sim"][m])), dyn["sim"][m], color=MCOL[m], lw=2, label=m)
ax.set_xlabel("Time step"); ax.set_ylabel("Total network activation")
ax.set_title("Dynamical spreading trajectory\n(sustained perturbation of each module)")
ax.legend(frameon=False, fontsize=7, ncol=2)

# Panel B: efficiency degradation (the informative attack panel)
ax = axes[1]
for name, (lcc, eff) in curves.items():
    ax.plot(range(len(eff)), eff, label=name, color=cols.get(name),
            lw=2.2 if "MDS" in name else 1.3, ls="--" if "Random" in name else "-")
ax.set_xlabel("Nodes removed"); ax.set_ylabel("Global efficiency")
ax.set_title("Efficiency under targeted attack\n(betweenness fastest; drivers ↑ efficiency)")
ax.legend(frameon=False, fontsize=7)

# Panel C: dynamics steady-state + sink reach
ax = axes[2]
mods = ["SDQ", "DASS", "CIAS", "DIET", "ISI", "ACT"]
x = np.arange(len(mods)); w = 0.4
ss = [dyn["sim"][m][-1] for m in mods]
sink = [dyn["sinkact"][m] for m in mods]
ax.bar(x, ss, color=[MCOL[m] for m in mods], edgecolor="black", lw=0.7)
ax.set_xticks(x); ax.set_xticklabels(mods)
ax.set_ylabel("Steady-state total activation")
ax.set_title("System response to module perturbation\n(source modules > sink modules)")
for i, v in enumerate(ss): ax.text(i, v + 0.5, f"{v:.0f}", ha="center", fontsize=7.5)
fig.tight_layout()
fig.savefig("knockout_dynamics.png", dpi=200, bbox_inches="tight")
print("saved (revised) knockout_dynamics.png")
plt.close(fig)
