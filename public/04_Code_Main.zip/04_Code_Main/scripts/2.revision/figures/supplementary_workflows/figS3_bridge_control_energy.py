import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Figure S3 — bridge centrality, expected influence, target controllability

Produces : bridge_control_energy.png

As-run figure code (environment: psunet, seed 42, 300 dpi, MCOL domain palette).
Data-store paths point to the reproducible checkpoints / reviewer data tables;
repoint resolve_input(...) / absolute <legacy-artifacts>/... to local copies to re-run.
Each script contains a self-contained apply_figure_style() and the MCOL palette.
"""

# skill:figure-style kernel.py (auto-injected on skill load)
META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


import numpy as np
import pandas as pd
import networkx as nx
import json
import pickle
from scipy.linalg import solve_discrete_lyapunov
import matplotlib.pyplot as plt

netobj = pickle.load(open(str(resolve_input('network_objects.pkl')), "rb"))
pcor = netobj["pcor"]
node_order = netobj["node_order"]
mod_of = netobj["mod_of"]
mds_cf = netobj["mds_cf"]
comm = [mod_of[n] for n in node_order]
p = len(node_order)

W = pcor.copy(); np.fill_diagonal(W, 0)
EI1 = W.sum(1)
EI2 = EI1 + (W @ EI1)
comm_arr = np.array(comm)
bridge_strength = np.zeros(p); bridge_ei = np.zeros(p)
for i in range(p):
    other = comm_arr != comm_arr[i]
    bridge_strength[i] = np.abs(W[i, other]).sum()
    bridge_ei[i] = W[i, other].sum()
Gb = nx.from_numpy_array((np.abs(W) > 1e-8).astype(float))
btw = nx.betweenness_centrality(Gb, weight=None)
bridge_betw = np.array([btw[i] for i in range(p)])

def short(c):
    m = mod_of[c]
    num = ''.join(ch for ch in c.split('_question')[-1].split('_score')[0] if ch.isdigit())
    return f"{m}{num}"

df = pd.DataFrame({"node": node_order, "module": comm,
    "EI1": EI1, "EI2": EI2, "bridge_strength": bridge_strength,
    "bridge_EI": bridge_ei, "bridge_betweenness": bridge_betw,
    "CF": [mds_cf[n] for n in node_order]})
df["short"] = df["node"].map(short)

A = np.abs(pcor).copy(); np.fill_diagonal(A, 0)
ev = np.abs(np.linalg.eigvals(A)).max()
An = A / (ev * 1.05)

w, V = np.linalg.eig(An)
avg_ctrl = np.zeros(p); modal_ctrl = np.zeros(p)
for i in range(p):
    B = np.zeros((p, 1)); B[i] = 1
    try:
        Wc = solve_discrete_lyapunov(An, B @ B.T); avg_ctrl[i] = np.trace(Wc)
    except Exception: avg_ctrl[i] = np.nan
    modal_ctrl[i] = np.sum((1 - np.abs(w) ** 2) * (np.abs(V[i, :]) ** 2))

target = np.array([1.0 if mod_of[n] in ("ISI", "ACT") else 0.0 for n in node_order])
target = target / np.linalg.norm(target)
ctrl_energy = np.full(p, np.nan)
for i in range(p):
    B = np.zeros((p, 1)); B[i] = 1
    try:
        Wc = solve_discrete_lyapunov(An, B @ B.T)
        Wc += 1e-6 * np.eye(p)
        ctrl_energy[i] = target @ np.linalg.solve(Wc, target)
    except Exception: pass
ctrl_energy_log = np.log10(ctrl_energy)
df["avg_control"] = avg_ctrl; df["modal_control"] = modal_ctrl
df["control_energy_log"] = ctrl_energy_log

adj = (np.abs(pcor) > 1e-8).astype(int); np.fill_diagonal(adj, 0)

def greedy_target_dominating(adj, target_idx):
    n = adj.shape[0]
    Ncover = [set(np.nonzero(adj[v])[0]) | {v} for v in range(n)]
    uncovered = set(target_idx); drivers = []
    while uncovered:
        best = max(range(n), key=lambda v: len(Ncover[v] & uncovered))
        gain = Ncover[best] & uncovered
        if not gain: break
        drivers.append(best); uncovered -= gain
    return len(drivers)

idx = {n: i for i, n in enumerate(node_order)}
rows = []
for label, mods in [("whole network", ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]),
                    ("sink (ISI+ACT)", ["ISI", "ACT"]),
                    ("source (DIET+SDQ)", ["DIET", "SDQ"]),
                    ("PSU (CIAS)", ["CIAS"]), ("DASS", ["DASS"])]:
    tgt = [idx[n] for n in node_order if mod_of[n] in mods]
    k = greedy_target_dominating(adj, tgt)
    rows.append((label, len(tgt), k, k / len(tgt)))
tc = pd.DataFrame(rows, columns=["target", "n_target", "n_drivers", "driver_ratio"])

apply_figure_style()
MCOL = {"CIAS": "#2c5f8a", "DASS": "#FF76DA", "SDQ": "#e08e0b", "DIET": "#27865a", "ISI": "#7d5ba6", "ACT": "#5bb5a2"}
fig, axes = plt.subplots(1, 3, figsize=(15.5, 4.8))

ax = axes[0]
for m in MCOL:
    sub = df[df.module == m]
    ax.scatter(sub.bridge_strength, sub.CF, s=32, color=MCOL[m], label=m, edgecolor="white", lw=0.4)
for _, r in df[(df.CF >= 0.2) | (df.bridge_strength > 0.85)].iterrows():
    ax.annotate(r["short"], (r.bridge_strength, r.CF), fontsize=6.5, xytext=(3, 3), textcoords="offset points")
ax.set_xlabel("Bridge strength"); ax.set_ylabel("Control frequency (CF)")
ax.set_title("Bridge vs driver:\ndistinct key-node sets")
ax.legend(frameon=False, fontsize=6, ncol=2)
r_bc = np.corrcoef(df.bridge_strength, df.CF)[0, 1]
ax.text(0.02, 0.95, f"r={r_bc:.2f}", transform=ax.transAxes, fontsize=8, va="top")

ax = axes[1]
top = df.reindex(df.EI1.abs().sort_values(ascending=False).index).head(12)[::-1]
ax.barh(range(len(top)), top.EI1, color=[MCOL[m] for m in top.module], edgecolor="black", lw=0.6)
ax.set_yticks(range(len(top))); ax.set_yticklabels(top["short"])
ax.set_xlabel("1-step expected influence (signed)")
ax.set_title("Expected influence\n(sign-aware centrality)")
ax.axvline(0, color="0.5", lw=0.8)

ax = axes[2]
tc_sorted = tc.sort_values("n_drivers")
bars = ax.bar(range(len(tc)), tc["n_drivers"], color="#4477aa", edgecolor="black", lw=0.7)
ax.set_xticks(range(len(tc))); ax.set_xticklabels(tc["target"], rotation=40, ha="right", fontsize=7)
ax.set_ylabel("Min. drivers needed")
ax.set_title("Target controllability\n(sinks need only 2 drivers)")
for i, (k, n) in enumerate(zip(tc.n_drivers, tc.n_target)):
    ax.text(i, k + 0.05, f"{k}\n(/{n})", ha="center", fontsize=6.5)
fig.tight_layout()
fig.savefig("bridge_control_energy.png", dpi=200, bbox_inches="tight")
print("saved. bridge-CF corr r=%.3f" % r_bc)
plt.close(fig)
