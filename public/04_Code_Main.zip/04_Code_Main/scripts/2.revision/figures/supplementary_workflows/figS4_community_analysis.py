import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Figure S4 — community detection, evolution, co-assignment

Produces : community_analysis.png

As-run figure code (environment: psunet, seed 42, 300 dpi, MCOL domain palette).
Data-store paths point to the reproducible checkpoints / reviewer data tables;
repoint resolve_input(...) / absolute <legacy-artifacts>/... to local copies to re-run.
Each script contains a self-contained apply_figure_style() and the MCOL palette.
"""

# skill:figure-style kernel.py (auto-injected on skill load)
META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


import os, sys, json, pickle
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from sklearn.preprocessing import QuantileTransformer
from sklearn.covariance import GraphicalLasso
from sklearn.metrics import adjusted_rand_score as ARI, normalized_mutual_info_score as NMI
import igraph as ig
import leidenalg
import community as community_louvain
from scipy.optimize import linear_sum_assignment

# Load data
L = pickle.load(open(str(resolve_input('longitudinal_data.pkl')), 'rb'))
W1m = L["W1m"]; W3p = L["W3p"]; node_order = L["node_order"]; mod_of = L["mod_of"]
comparable = L["comparable_nodes"]
ALPHA = json.load(open(str(resolve_input('real_meta.json'))))["alpha"]


def build_ggm(dfX, cols, alpha=ALPHA):
    qt = QuantileTransformer(output_distribution="normal", random_state=42, subsample=int(1e9))
    Xq = qt.fit_transform(dfX[cols].to_numpy(float))
    gl = GraphicalLasso(alpha=alpha, max_iter=1000).fit(Xq)
    prec = gl.precision_.copy(); d = np.sqrt(np.diag(prec)); pc = -prec / np.outer(d, d); np.fill_diagonal(pc, 0)
    return pc


def to_igraph(pcor, names):
    A = np.abs(pcor).copy(); np.fill_diagonal(A, 0)
    src, tgt = np.triu_indices_from(A, 1)
    edges = [(int(i), int(j)) for i, j in zip(src, tgt) if A[i, j] > 1e-8]
    w = [A[i, j] for i, j in edges]
    G = ig.Graph(n=len(names), edges=edges); G.es["weight"] = w
    G.vs["name"] = names
    return G, A


# Build full W1 network for multi-algorithm comparison
pcor_full = build_ggm(W1m, node_order)

# Run all community detection algorithms
priori = [mod_of[n] for n in node_order]
G1, A1 = to_igraph(pcor_full, node_order)

results = {}
# 1) Louvain
Gnx = nx.from_numpy_array(np.abs(pcor_full))
part = community_louvain.best_partition(Gnx, weight="weight", random_state=42)
results["Louvain"] = [part[i] for i in range(len(node_order))]
# 2) Leiden
la = leidenalg.find_partition(G1, leidenalg.ModularityVertexPartition, weights="weight", seed=42)
results["Leiden"] = la.membership
# 3) Walktrap
wt = G1.community_walktrap(weights="weight").as_clustering()
results["Walktrap"] = wt.membership
# 4) Spinglass
try:
    sg = G1.community_spinglass(weights="weight"); results["Spinglass"] = sg.membership
except Exception as e:
    print("spinglass:", e)
# 5) Fast greedy
fg = G1.community_fastgreedy(weights="weight").as_clustering(); results["FastGreedy"] = fg.membership
# 6) Infomap
im = G1.community_infomap(edge_weights="weight"); results["Infomap"] = im.membership

summ = []
for algo, mem in results.items():
    k = len(set(mem)); a = ARI(priori, mem); nn = NMI(priori, mem)
    summ.append((algo, k, a, nn))

# Bootstrap community stability
rng = np.random.default_rng(0)
n = len(W1m); Bc = 200
co = np.zeros((104, 104))
for b in range(Bc):
    idx = rng.integers(0, n, n)
    pcb = build_ggm(W1m.iloc[idx], node_order)
    Gb, _ = to_igraph(pcb, node_order)
    lab = leidenalg.find_partition(Gb, leidenalg.ModularityVertexPartition, weights="weight", seed=42).membership
    lab = np.array(lab)
    for c in set(lab):
        members = np.where(lab == c)[0]
        co[np.ix_(members, members)] += 1
co /= Bc

# Load community evolution data
cev = json.load(open(str(resolve_input('community_evolution.json'))))
mem1 = np.array(cev["mem1"])
mem3 = np.array(cev["mem3"])

# Load co-assignment matrix
co = np.load(str(resolve_input('community_coassign.npy')))

# Plot
apply_figure_style()
MCOL = {"CIAS": "#2c5f8a", "DASS": "#FF76DA", "SDQ": "#e08e0b", "DIET": "#27865a", "ISI": "#7d5ba6", "ACT": "#5bb5a2"}
fig, axes = plt.subplots(1, 3, figsize=(15.5, 4.8))

# Panel A: multi-algorithm ARI/NMI vs priori
ax = axes[0]
algos = [s[0] for s in summ]; aris = [s[2] for s in summ]; nmis = [s[3] for s in summ]
x = np.arange(len(algos)); w = 0.38
ax.bar(x - w / 2, aris, w, label="ARI", color="#4477aa", edgecolor="black", lw=0.6)
ax.bar(x + w / 2, nmis, w, label="NMI", color="#ee6677", edgecolor="black", lw=0.6)
ax.set_xticks(x); ax.set_xticklabels(algos, rotation=40, ha="right")
ax.set_ylabel("Agreement with 6 priori modules"); ax.set_ylim(0, 1)
ax.legend(frameon=False); ax.set_title("6 algorithms converge on\nthe six-domain structure")
for i, (a, nn) in enumerate(zip(aris, nmis)):
    ax.text(i - w / 2, a + 0.01, f"{a:.2f}", ha="center", fontsize=6.5)

# Panel B: cross-wave community evolution (alluvial-style)
ax = axes[1]
order_idx = sorted(range(len(comparable)), key=lambda i: (mod_of[comparable[i]], mem1[i]))
for rank, i in enumerate(order_idx):
    nd = comparable[i]; col = MCOL[mod_of[nd]]
    changed_flag = mem1[i] != mem3[i]
    ax.plot([0, 1], [mem1[i], mem3[i]], color=col, alpha=0.85 if changed_flag else 0.25,
            lw=2.2 if changed_flag else 0.8, zorder=3 if changed_flag else 1)
ax.set_xticks([0, 1]); ax.set_xticklabels(["Wave 1", "Wave 3"])
ax.set_ylabel("Community ID")
ax.set_title(f"Community evolution\n(ARI={ARI(mem1, mem3):.2f}; 8/89 nodes moved)")
from matplotlib.lines import Line2D
ax.legend(handles=[Line2D([0], [0], color=MCOL[m], lw=3, label=m) for m in MCOL],
          frameon=False, fontsize=6, ncol=2, loc="upper right")

# Panel C: community co-assignment heatmap (nodes ordered by module)
ax = axes[2]
ordidx = sorted(range(104), key=lambda i: (mod_of[node_order[i]],))
co_plot = co[np.ix_(ordidx, ordidx)]
im = ax.imshow(co_plot, cmap="viridis", vmin=0, vmax=1)
mods_sorted = [mod_of[node_order[i]] for i in ordidx]
bnd = [k for k in range(1, 104) if mods_sorted[k] != mods_sorted[k - 1]]
for b in bnd: ax.axhline(b - 0.5, color="white", lw=0.6); ax.axvline(b - 0.5, color="white", lw=0.6)
cur = 0
for m in ["CIAS", "DASS", "ISI", "DIET", "SDQ", "ACT"]:
    cnt = mods_sorted.count(m)
    if cnt > 0:
        ax.text(-3, cur + cnt / 2, m, ha="right", va="center", fontsize=7, color=MCOL[m], fontweight="bold")
        cur += cnt
ax.set_xticks([]); ax.set_yticks([])
ax.set_title("Bootstrap co-assignment\n(mean within-module=0.78)")
fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="P(same community)")
fig.tight_layout()
fig.savefig("community_analysis.png", dpi=200, bbox_inches="tight")
print("saved community_analysis.png")
plt.close(fig)
