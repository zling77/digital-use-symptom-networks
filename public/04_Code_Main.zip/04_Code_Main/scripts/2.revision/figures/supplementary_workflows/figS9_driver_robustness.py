import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Figure S9/S10 — driver-node bootstrap stability + regularization sensitivity

Produces : driver_robustness.png

As-run figure code (environment: psunet, seed 42, 300 dpi, MCOL domain palette).
Data-store paths point to the reproducible checkpoints / reviewer data tables;
repoint resolve_input(...) / absolute <legacy-artifacts>/... to local copies to re-run.
Each script contains a self-contained apply_figure_style() and the MCOL palette.
"""

# skill:figure-style kernel.py (auto-injected on skill load)
META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


import os, sys, json, pickle, re, glob
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import rankdata, norm
from sklearn.preprocessing import QuantileTransformer
from sklearn.covariance import GraphicalLasso
import networkx as nx
import itertools

meta = json.load(open(str(resolve_input('real_meta.json'))))
node_order = meta["node_order"]
mod_of = meta["mod_of"]
ALPHA = meta["alpha"]

def short(c):
    m = mod_of[c]
    num = ''.join(ch for ch in c.split('_question')[-1].split('_score')[0] if ch.isdigit())
    return f"{m}{num}"

# ---- rebuild real network from cleaned_scale_info ----
PLAN = str(PROJECT_ROOT)
scale = pd.read_csv(str(resolve_input("cleaned_scale_info.csv")))

from sklearn.preprocessing import QuantileTransformer
qt = QuantileTransformer(output_distribution="normal", random_state=42, subsample=int(1e9), copy=True)
Xq_full = qt.fit_transform(scale[node_order].to_numpy(dtype=float))

# ---- load longitudinal matched W1 data ----
RAW = f"{PLAN}/data/raw"
W1 = f"{RAW}/1/202208-202302省疾控心理筛查活动"
W3d2 = f"{RAW}/3/心理量表导出_第四次数据导出_按照数据模版_20240401/scale_detailed_data"

import hashlib
def hkey(n, b, g):
    return hashlib.sha1(f"{str(n).strip()}|{str(b).strip()}|{str(g).strip()}".encode()).hexdigest()[:16]

w1c = pd.read_csv(f"{W1}/common_info.csv", usecols=["cust_id", "real_name", "birthday", "gender"])
w1c["linkkey"] = [hkey(n, b, g) for n, b, g in zip(w1c.real_name, w1c.birthday, w1c.gender)]
scale_w1 = pd.read_csv(str(resolve_input("cleaned_scale_info.csv")), usecols=["cust_id"] + node_order)
w1_df = scale_w1.merge(w1c[["cust_id", "linkkey"]], on="cust_id", how="inner")

w3_specs = {
    "cias": ("ia_score", [f"ia_i{i:02d}_score" for i in range(1, 27)]),
    "sdq": ("sdq_score", [f"sdq_e{i:02d}_score" for i in range(1, 26)]),
    "dass": ("dass_score", [f"dass_d{i:02d}_score" for i in range(1, 22)]),
    "isi": ("isi_score", [f"isi_h{i:02d}_score" for i in range(1, 8)]),
    "diet": ("diet_score", [f"diet_m{i:02d}" for i in range(1, 23)]),
    "act": ("activity_score", [f"activity_n{i:02d}" for i in range(1, 5)]),
}
w3 = None
for dom, (kw, cols) in w3_specs.items():
    fs = [f for f in glob.glob(f"{W3d2}/*.xlsx") if kw in os.path.basename(f) and "parent" not in f and "teacher" not in f]
    d = pd.read_excel(fs[0], usecols=["cust_id"] + cols)
    d = d.drop_duplicates("cust_id")
    w3 = d if w3 is None else w3.merge(d, on="cust_id", how="inner")

w3c = pd.read_excel(glob.glob(f"{RAW}/3/*/*common_info*.xlsx")[0], usecols=["cust_id", "real_name", "birthday", "gender"])
w3c["linkkey"] = [hkey(n, b, g) for n, b, g in zip(w3c.real_name, w3c.birthday, w3c.gender)]
w3 = w3.merge(w3c[["cust_id", "linkkey"]], on="cust_id", how="inner")

k1 = w1_df["linkkey"]; k3 = w3["linkkey"]
dup1 = set(k1[k1.duplicated(keep=False)]); dup3 = set(k3[k3.duplicated(keep=False)])
bad = dup1 | dup3
w1u = w1_df[~w1_df["linkkey"].isin(bad)].set_index("linkkey")
w3u = w3[~w3["linkkey"].isin(bad)].set_index("linkkey")
common = sorted(set(w1u.index) & set(w3u.index))

cw = pd.read_csv(str(resolve_input('scale_crosswalk.csv')))
W1m = w1u.loc[common, node_order].apply(pd.to_numeric, errors="coerce")
W3m = w3u.loc[common, cw["w3_col"].tolist()].apply(pd.to_numeric, errors="coerce")
W3m.columns = cw["w1_col"].tolist()
W3m = W3m[node_order]
W3p = W3m.copy()
for q in [7, 11, 14, 21, 25]:
    col = f"sdq_question{q}_score"
    if col in W3p.columns: W3p[col] = 2 - W3p[col]
for c in node_order:
    if mod_of[c] in ("DIET", "ACT"): W3p[c] = W3p[c] - 1

# ---- MDS enumeration helper ----
def _is_dominating(adj, subset, n):
    covered = set(subset)
    for v in subset:
        covered |= set(np.nonzero(adj[v])[0])
    return len(covered) == n

def enumerate_mds(adj, nodes, max_size=6):
    n = len(nodes)
    A = np.asarray(adj)
    N = [set(np.nonzero(A[v])[0]) | {v} for v in range(n)]
    size = None
    try:
        import pulp
        prob = pulp.LpProblem("mds", pulp.LpMinimize)
        x = [pulp.LpVariable(f"x{i}", cat="Binary") for i in range(n)]
        prob += pulp.lpSum(x)
        for v in range(n):
            prob += pulp.lpSum(x[u] for u in N[v]) >= 1
        prob.solve(pulp.PULP_CBC_CMD(msg=0))
        size = int(round(sum(v.value() for v in x)))
    except Exception:
        size = None
    if size is None:
        for k in range(1, max_size + 1):
            found = any(_is_dominating(A, c, n) for c in itertools.combinations(range(n), k))
            if found:
                size = k; break
    sols = []
    for c in itertools.combinations(range(n), size):
        if _is_dominating(A, c, n):
            sols.append(tuple(sorted(c)))
    cf = {nodes[v]: 0.0 for v in range(n)}
    for s in sols:
        for v in s:
            cf[nodes[v]] += 1
    ns = max(len(sols), 1)
    cf = {k: v / ns for k, v in cf.items()}
    return dict(size=size, solutions=sols, n_solutions=len(sols), cf=cf, nodes=nodes)

def net_from_subsample(dfX, cols, alpha=ALPHA):
    qt = QuantileTransformer(output_distribution="normal", random_state=42, subsample=int(1e9))
    Xq = qt.fit_transform(dfX[cols].to_numpy(float))
    gl = GraphicalLasso(alpha=alpha, max_iter=500).fit(Xq)
    prec = gl.precision_.copy(); d = np.sqrt(np.diag(prec)); pc = -prec / np.outer(d, d); np.fill_diagonal(pc, 0)
    adj = (np.abs(pc) > 1e-8).astype(int); np.fill_diagonal(adj, 0)
    return adj

# ---- original network CF ----
gl_orig = GraphicalLasso(alpha=ALPHA, max_iter=1000).fit(Xq_full)
prec_orig = gl_orig.precision_.copy()
d_orig = np.sqrt(np.diag(prec_orig))
pcor_orig = -prec_orig / np.outer(d_orig, d_orig)
np.fill_diagonal(pcor_orig, 0)
adj_orig = (np.abs(pcor_orig) > 1e-8).astype(int); np.fill_diagonal(adj_orig, 0)
mds_orig = enumerate_mds(adj_orig, node_order)
cf_orig = mds_orig["cf"]

# ---- bootstrap driver stability ----
rng = np.random.default_rng(2024)
n = len(W1m); B = 300
cf_boot = np.zeros((B, len(node_order)))
mds_sizes = []
for b in range(B):
    idx = rng.choice(n, int(0.9 * n), replace=False)
    adj = net_from_subsample(W1m.iloc[idx], node_order)
    mds = enumerate_mds(adj, node_order)
    mds_sizes.append(mds["size"])
    for i, nd in enumerate(node_order): cf_boot[b, i] = mds["cf"][nd]
    if (b + 1) % 50 == 0: print(f"  {b+1}/{B} done")

res = []
for i, nd in enumerate(node_order):
    v = cf_boot[:, i]
    res.append({"node": nd, "short": short(nd), "module": mod_of[nd],
                "CF_orig": cf_orig[nd], "CF_boot_mean": v.mean(),
                "CF_ci_lo": np.percentile(v, 2.5), "CF_ci_hi": np.percentile(v, 97.5),
                "sel_freq": (v > 0).mean(),
                "core_freq": (v >= 0.3).mean()})
rd = pd.DataFrame(res).sort_values("CF_orig", ascending=False)
rd.to_csv("driver_stability.csv", index=False)

# ---- lambda sensitivity ----
qt2 = QuantileTransformer(output_distribution="normal", random_state=42, subsample=int(1e9))
Xq2 = qt2.fit_transform(W1m[node_order].to_numpy(float))
alphas = [0.04, 0.05, ALPHA, 0.07, 0.08, 0.10]
lam_rows = []
for a in alphas:
    gl = GraphicalLasso(alpha=a, max_iter=500).fit(Xq2)
    prec = gl.precision_.copy(); d = np.sqrt(np.diag(prec)); pc = -prec / np.outer(d, d); np.fill_diagonal(pc, 0)
    adj = (np.abs(pc) > 1e-8).astype(int); np.fill_diagonal(adj, 0)
    dens = adj.sum() / (104 * 103)
    mds = enumerate_mds(adj, node_order)
    top = sorted(mds["cf"].items(), key=lambda x: -x[1])[:3]
    lam_rows.append({"alpha": a, "density": dens, "mds_size": mds["size"], "n_sol": mds["n_solutions"],
                     "top_drivers": ", ".join(short(k) for k, v in top if v > 0)})
    print(f"alpha={a:.3f}: dens={dens:.3f} MDS={mds['size']} nsol={mds['n_solutions']} top={[short(k) for k, v in top if v > 0]}")
lamdf = pd.DataFrame(lam_rows)
lamdf.to_csv("lambda_sensitivity.csv", index=False)

# ---- plot ----
apply_figure_style()
MCOL = {"CIAS": "#2c5f8a", "DASS": "#FF76DA", "SDQ": "#e08e0b", "DIET": "#27865a", "ISI": "#7d5ba6", "ACT": "#5bb5a2"}
rd = pd.read_csv("driver_stability.csv")
fig, axes = plt.subplots(1, 3, figsize=(15.5, 4.8))

# Panel A: driver CF with bootstrap CI (top nodes)
ax = axes[0]
top = rd.head(10)[::-1]
yp = range(len(top))
ax.barh(yp, top.CF_boot_mean, color=[MCOL[m] for m in top.module], edgecolor="black", lw=0.6, alpha=0.85)
for k, (_, r) in enumerate(top.iterrows()):
    ax.plot([r.CF_ci_lo, r.CF_ci_hi], [k, k], color="black", lw=1.3)
    ax.plot(r.CF_orig, k, "D", color="black", ms=5)
ax.set_yticks(list(yp)); ax.set_yticklabels(top["short"])
ax.set_xlabel("Control frequency (bootstrap mean, 95% CI)")
ax.set_title("Driver-identity stability\n(◆ = original CF; 300× 90% subsample)")

# Panel B: selection frequency
ax = axes[1]
top2 = rd.head(10)[::-1]
ax.barh(range(len(top2)), top2.sel_freq, color=[MCOL[m] for m in top2.module], edgecolor="black", lw=0.6, label="in any MDS")
ax.barh(range(len(top2)), top2.core_freq, color=[MCOL[m] for m in top2.module], edgecolor="black", lw=0.6, alpha=0.45, hatch="///", label="core (CF≥0.3)")
ax.set_yticks(range(len(top2))); ax.set_yticklabels(top2["short"])
ax.set_xlabel("Bootstrap selection frequency")
ax.set_title("How often each node is a driver\n(DIET22: 90% any, 62% core)")
ax.legend(frameon=False, fontsize=7, loc="lower right")

# Panel C: lambda sensitivity spectrum
ax = axes[2]
lamdf = pd.read_csv("lambda_sensitivity.csv")
ax2 = ax.twinx()
ax.plot(lamdf.alpha, lamdf.density, "o-", color="#4477aa", label="density")
ax2.plot(lamdf.alpha, lamdf.mds_size, "s--", color="#ee6677", label="MDS size")
ax.axvline(0.058, color="green", ls=":", lw=1.5); ax.text(0.058, 0.62, "λ*=0.058", fontsize=7, color="green", rotation=90, va="top")
ax.set_xlabel("Regularization λ"); ax.set_ylabel("Network density", color="#4477aa")
ax2.set_ylabel("MDS size", color="#ee6677"); ax2.set_ylim(2, 5)
ax.set_title("λ-sensitivity spectrum\nDIET22/DASS14 persist across λ=0.04–0.08")
fig.tight_layout()
fig.savefig("driver_robustness.png", dpi=200, bbox_inches="tight")
print("saved driver_robustness.png")
plt.close(fig)
