"""Rebuild the five manuscript main figures as editable vector graphics.

Outputs
-------
Main_Figures/Editable_Rebuilt/Figure_1_editable.{svg,pdf,png}
...
Main_Figures/Editable_Rebuilt/Figure_5_editable.{svg,pdf,png}

The SVG output keeps text as live text and all plotted marks as vector objects.
No raster image is embedded in the rebuilt SVG files.
"""

from __future__ import annotations

import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)


import argparse
import json
import pickle
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, Rectangle


ROOT = PROJECT_ROOT
DATA_DIR = OUTPUT_DIR
PIPELINE_DIR = OUTPUT_DIR
NODE_RESULTS_DIR = BASELINE_DIR

DOMAINS = ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]
COLORS = {
    "CIAS": "#2C6798",
    "DASS": "#FF76DA",
    "SDQ": "#E58D00",
    "DIET": "#258B5E",
    "ISI": "#7C58A7",
    "ACT": "#59B5A6",
}
META_GREY = "#666666"


def configure_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 8,
            "axes.labelsize": 8,
            "axes.titlesize": 8,
            "legend.fontsize": 6.5,
            "xtick.labelsize": 6.5,
            "ytick.labelsize": 6.5,
            "axes.linewidth": 0.65,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "xtick.major.size": 3,
            "ytick.major.size": 3,
            "xtick.major.width": 0.65,
            "ytick.major.width": 0.65,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": False,
            "legend.frameon": False,
            "figure.dpi": 150,
            "savefig.dpi": 300,
            "savefig.bbox": "tight",
            "axes.titleweight": "normal",
            "axes.titlelocation": "left",
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def panel_letter(ax: plt.Axes, letter: str, x: float = -0.16, y: float = 1.04) -> None:
    ax.text(
        x,
        y,
        letter.lower(),
        transform=ax.transAxes,
        fontsize=9,
        fontweight="bold",
        va="bottom",
        ha="left",
    )


def save_figure(fig: plt.Figure, output_dir: Path, stem: str, dpi: int) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for suffix in ("svg", "pdf", "png"):
        fig.savefig(
            output_dir / f"{stem}.{suffix}",
            format=suffix,
            dpi=dpi,
            bbox_inches="tight",
            facecolor="white",
        )
    plt.close(fig)


def arrow(
    ax: plt.Axes,
    start: tuple[float, float],
    end: tuple[float, float],
    *,
    color: str,
    width: float,
    radius: float = 0.0,
    alpha: float = 0.78,
    mutation_scale: float = 10,
    shrink: float = 19,
    zorder: int = 1,
) -> None:
    patch = FancyArrowPatch(
        start,
        end,
        arrowstyle="-|>",
        connectionstyle=f"arc3,rad={radius}",
        linewidth=width,
        color=color,
        alpha=alpha,
        mutation_scale=mutation_scale,
        shrinkA=shrink,
        shrinkB=shrink,
        zorder=zorder,
    )
    ax.add_patch(patch)


def draw_nodes(
    ax: plt.Axes,
    positions: dict[str, tuple[float, float]],
    *,
    sizes: dict[str, float] | None = None,
    labels: dict[str, str] | None = None,
    font_size: float = 6.0,
) -> None:
    sizes = sizes or {node: 640 for node in positions}
    labels = labels or {node: node for node in positions}
    for node, (x, y) in positions.items():
        ax.scatter(
            x,
            y,
            s=sizes[node],
            color=COLORS.get(node, "#777777"),
            edgecolor="black",
            linewidth=0.8,
            zorder=3,
        )
        ax.text(
            x,
            y,
            labels[node],
            ha="center",
            va="center",
            color="white",
            fontsize=font_size,
            fontweight="bold",
            zorder=4,
        )


def load_network_objects() -> dict:
    with open(PIPELINE_DIR / "network_objects.pkl", "rb") as handle:
        return pickle.load(handle)


def short_node(node: str, module_of: dict[str, str]) -> str:
    module = module_of[node]
    number = "".join(
        character
        for character in node.split("_question")[-1].split("_score")[0]
        if character.isdigit()
    )
    return f"{module}{number}"


def figure_1(output_dir: Path, dpi: int) -> None:
    net = load_network_objects()
    pcor = np.asarray(net["pcor"], dtype=float)
    nodes = list(net["node_order"])
    module_of = net["mod_of"]
    control_frequency = net["mds_cf"]
    properties = pd.read_csv(NODE_RESULTS_DIR / "node_properties_mapped.csv").set_index(
        "index"
    )

    fig = plt.figure(figsize=(7.2, 2.7))
    grid = fig.add_gridspec(1, 3, width_ratios=[1.15, 1, 1], wspace=0.42)

    ax = fig.add_subplot(grid[0, 0])
    weights = np.abs(pcor).copy()
    np.fill_diagonal(weights, 0)
    upper_i, upper_j = np.triu_indices(len(nodes), 1)
    ranked = np.sort(weights[upper_i, upper_j])[::-1]
    threshold = ranked[500]
    graph = nx.Graph()
    graph.add_nodes_from(range(len(nodes)))
    for source, target in zip(upper_i, upper_j):
        if weights[source, target] > threshold:
            graph.add_edge(source, target, weight=weights[source, target])
    positions = nx.spring_layout(
        graph, k=0.32, seed=42, weight="weight", iterations=80
    )
    nx.draw_networkx_edges(
        graph,
        positions,
        ax=ax,
        width=0.18,
        edge_color="#CFCFCF",
        alpha=0.55,
    )
    strengths = properties["strength"].reindex(nodes).to_numpy(float)
    node_sizes = 25 + (strengths - strengths.min()) / np.ptp(strengths) * 80
    nx.draw_networkx_nodes(
        graph,
        positions,
        ax=ax,
        node_size=node_sizes,
        node_color=[COLORS[module_of[nodes[index]]] for index in graph.nodes()],
        edgecolors="white",
        linewidths=0.3,
    )
    drivers = [
        index
        for index, node in enumerate(nodes)
        if control_frequency[node] >= 0.3
    ]
    nx.draw_networkx_nodes(
        graph,
        positions,
        ax=ax,
        nodelist=drivers,
        node_size=[node_sizes[index] + 55 for index in drivers],
        node_color="none",
        edgecolors="black",
        linewidths=1.3,
    )
    for index in drivers:
        ax.annotate(
            short_node(nodes[index], module_of),
            positions[index],
            fontsize=5.5,
            fontweight="bold",
            xytext=(3, 3),
            textcoords="offset points",
        )
    ax.set_title("Six-domain symptom network")
    ax.axis("off")
    legend = [
        Line2D(
            [0],
            [0],
            marker="o",
            color="white",
            markerfacecolor=COLORS[module],
            markersize=5,
            label=module,
        )
        for module in DOMAINS
    ]
    ax.legend(
        handles=legend,
        loc="lower center",
        ncol=2,
        bbox_to_anchor=(0.5, -0.16),
        handletextpad=0.2,
        columnspacing=0.8,
        fontsize=5.2,
    )
    panel_letter(ax, "a")

    ax = fig.add_subplot(grid[0, 1])
    strength_z = (strengths - strengths.mean()) / strengths.std()
    frequencies = np.array([control_frequency[node] for node in nodes])
    for module in DOMAINS:
        indices = [
            index for index, node in enumerate(nodes) if module_of[node] == module
        ]
        ax.scatter(
            strength_z[indices],
            frequencies[indices],
            s=16,
            color=COLORS[module],
            edgecolor="white",
            linewidth=0.3,
            zorder=2,
        )
    for index, node in enumerate(nodes):
        if control_frequency[node] >= 0.3:
            ax.annotate(
                short_node(node, module_of),
                (strength_z[index], frequencies[index]),
                fontsize=5.5,
                fontweight="bold",
                xytext=(3, 2),
                textcoords="offset points",
            )
    ax.axhline(0, color="0.8", linewidth=0.5)
    ax.axvline(0, color="0.8", linewidth=0.5, linestyle="--")
    ax.set_xlabel("Node strength (z)")
    ax.set_ylabel("Control frequency")
    ax.set_title("Drivers \u2260 high-strength nodes")
    ax.margins(0.08)
    panel_letter(ax, "b")

    ax = fig.add_subplot(grid[0, 2])
    amcs_table = pd.read_csv(resolve_input("module_average_amcs.csv"))
    required_columns = {"domain", "average_amcs", "structural_role", "display_order"}
    if set(amcs_table.columns) != required_columns:
        raise ValueError(
            "module_average_amcs.csv must contain exactly: "
            + ", ".join(sorted(required_columns))
        )
    if amcs_table["domain"].duplicated().any() or set(amcs_table["domain"]) != set(DOMAINS):
        raise ValueError("module_average_amcs.csv must contain one row for each of the six domains")
    amcs_table = amcs_table.sort_values("display_order")
    order = amcs_table["domain"].tolist()
    amcs = amcs_table.set_index("domain")["average_amcs"].astype(float).to_dict()
    roles = amcs_table["structural_role"].tolist()
    y = np.arange(len(order))[::-1]
    ax.barh(
        y,
        [amcs[module] for module in order],
        color=[COLORS[module] for module in order],
        edgecolor="black",
        linewidth=0.4,
    )
    ax.set_yticks(y)
    ax.set_yticklabels(order)
    for y_value, role in zip(y, roles):
        ax.text(0.012, y_value, role, va="center", fontsize=5.3, color="0.3")
    ax.set_xlabel("Module out-strength (AMCS)")
    ax.set_title("Source\u2192relay\u2192sink hierarchy")
    ax.margins(y=0.05)
    panel_letter(ax, "c")

    save_figure(fig, output_dir, "Figure_1_editable", dpi)


def figure_2(output_dir: Path, dpi: int) -> None:
    coefficients = pd.read_csv(resolve_input("clpn_coefficients.csv"), index_col=0)
    p_values = pd.read_csv(resolve_input("clpn_pvalues.csv"), index_col=0)
    directionality = pd.read_csv(resolve_input("clpn_directionality.csv")).set_index(
        "domain"
    )
    coefficients.index = [value.replace("_w1", "") for value in coefficients.index]
    coefficients.columns = [
        value.replace("_w3", "") for value in coefficients.columns
    ]
    p_values.index = [value.replace("_w1", "") for value in p_values.index]
    p_values.columns = [value.replace("_w3", "") for value in p_values.columns]
    coefficients = coefficients.loc[DOMAINS, DOMAINS]
    p_values = p_values.loc[DOMAINS, DOMAINS]

    fig = plt.figure(figsize=(7.35, 3.35))
    grid = fig.add_gridspec(1, 3, width_ratios=[1.12, 1.08, 1.08], wspace=0.48)

    ax = fig.add_subplot(grid[0, 0])
    matrix = coefficients.to_numpy(float)
    cell_edges = np.arange(len(DOMAINS) + 1) - 0.5
    image = ax.pcolormesh(
        cell_edges,
        cell_edges,
        matrix,
        cmap="RdBu_r",
        vmin=-0.45,
        vmax=0.45,
        shading="flat",
        edgecolors="none",
    )
    ax.set_xlim(-0.5, len(DOMAINS) - 0.5)
    ax.set_ylim(len(DOMAINS) - 0.5, -0.5)
    for row in range(len(DOMAINS)):
        for column in range(len(DOMAINS)):
            value = matrix[row, column]
            star = "*" if row != column and p_values.iloc[row, column] < 0.05 else ""
            color = "white" if abs(value) >= 0.27 else "black"
            ax.text(
                column,
                row,
                f"{value:.2f}{star}",
                ha="center",
                va="center",
                fontsize=5.5,
                color=color,
            )
    ax.set_xticks(range(len(DOMAINS)))
    ax.set_xticklabels(DOMAINS, rotation=48, ha="right")
    ax.set_yticks(range(len(DOMAINS)))
    ax.set_yticklabels(DOMAINS)
    ax.set_xlabel("Wave 3 (outcome)")
    ax.set_ylabel("Wave 1 (predictor)")
    ax.set_title("Cross-lagged coefficients")
    colorbar_ax = ax.inset_axes([1.04, 0.17, 0.05, 0.58])
    color_map = mpl.colormaps["RdBu_r"]
    normalizer = mpl.colors.Normalize(vmin=-0.45, vmax=0.45)
    bins = np.linspace(-0.45, 0.45, 65)
    for lower, upper in zip(bins[:-1], bins[1:]):
        colorbar_ax.add_patch(
            Rectangle(
                (0, lower),
                1,
                upper - lower,
                facecolor=color_map(normalizer((lower + upper) / 2)),
                edgecolor="none",
            )
        )
    colorbar_ax.set_xlim(0, 1)
    colorbar_ax.set_ylim(-0.45, 0.45)
    colorbar_ax.set_xticks([])
    colorbar_ax.set_yticks(np.arange(-0.4, 0.41, 0.1))
    colorbar_ax.yaxis.tick_right()
    colorbar_ax.yaxis.set_label_position("right")
    colorbar_ax.set_ylabel("\u03b2", rotation=90, labelpad=4)
    colorbar_ax.tick_params(labelsize=5.5, length=2)
    panel_letter(ax, "a")

    ax = fig.add_subplot(grid[0, 1])
    positions = {
        "SDQ": (-0.55, 0.75),
        "DASS": (0.55, 0.75),
        "DIET": (-0.85, 0.05),
        "CIAS": (0.85, 0.05),
        "ISI": (-0.55, -0.75),
        "ACT": (0.55, -0.75),
    }
    selected_edges: list[tuple[str, str, float]] = []
    for source in DOMAINS:
        for target in DOMAINS:
            if source == target:
                continue
            beta = float(coefficients.loc[source, target])
            if p_values.loc[source, target] < 0.05 and abs(beta) >= 0.08:
                selected_edges.append((source, target, beta))
    for source, target, beta in selected_edges:
        radius = 0.0
        if (target, source, float(coefficients.loc[target, source])) in selected_edges:
            radius = 0.12 if source < target else -0.12
        arrow(
            ax,
            positions[source],
            positions[target],
            color="#C25345" if beta > 0 else "#3B6FB6",
            width=0.45 + abs(beta) * 9,
            radius=radius,
            mutation_scale=9,
            shrink=18,
            alpha=0.8,
        )
    draw_nodes(ax, positions, font_size=5.6)
    ax.set_xlim(-1.25, 1.25)
    ax.set_ylim(-1.12, 1.15)
    ax.set_title("Directed temporal network")
    ax.axis("off")
    ax.text(
        0.5,
        -0.04,
        "edges: significant cross-lagged \u03b2",
        transform=ax.transAxes,
        ha="center",
        fontsize=5.2,
        color=META_GREY,
    )
    panel_letter(ax, "b")

    ax = fig.add_subplot(grid[0, 2])
    order = ["DASS", "ISI", "DIET", "CIAS", "SDQ", "ACT"]
    y = np.arange(len(order))[::-1]
    values = directionality.loc[order, "net"].to_numpy(float)
    lower = values - directionality.loc[order, "net_ci_lo"].to_numpy(float)
    upper = directionality.loc[order, "net_ci_hi"].to_numpy(float) - values
    ax.barh(
        y,
        values,
        color=[COLORS[module] for module in order],
        edgecolor="black",
        linewidth=0.5,
    )
    ax.errorbar(
        values,
        y,
        xerr=np.vstack([lower, upper]),
        fmt="none",
        ecolor="black",
        elinewidth=1.0,
        capsize=4,
        capthick=1.0,
        zorder=3,
    )
    ax.axvline(0, color="0.45", linewidth=0.7)
    ax.set_yticks(y)
    ax.set_yticklabels(order)
    ax.set_xlabel("Net directionality (out \u2212 in)")
    ax.set_title("Temporal source\u2192sink")
    ax.text(
        0.97,
        0.08,
        "DASS source\nSDQ, ACT sink",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=5.5,
        bbox={
            "boxstyle": "round,pad=0.25",
            "facecolor": "#FFF9EA",
            "edgecolor": "0.7",
            "linewidth": 0.5,
        },
    )
    panel_letter(ax, "c")

    save_figure(fig, output_dir, "Figure_2_editable", dpi)


def figure_3(output_dir: Path, dpi: int, show_point_labels: bool) -> None:
    with open(resolve_input("bn_domain_edges.json"), encoding="utf-8") as handle:
        dag_edges = json.load(handle)["edges"]
    stability = pd.read_csv(resolve_input("bn_edge_stability.csv"))
    stability_lookup = dict(zip(stability["edge"], stability["bootstrap_freq"]))
    directionality = pd.read_csv(resolve_input("clpn_directionality.csv")).set_index(
        "domain"
    )
    dag_net = pd.read_csv(resolve_input("dag_robustness.csv")).set_index("domain")

    fig = plt.figure(figsize=(7.2, 3.05))
    grid = fig.add_gridspec(1, 3, width_ratios=[1.06, 1.12, 1.02], wspace=0.47)

    ax = fig.add_subplot(grid[0, 0])
    positions = {
        "SDQ": (-0.55, 0.72),
        "DASS": (0.35, 0.72),
        "DIET": (-0.95, 0.05),
        "CIAS": (0.82, 0.05),
        "ISI": (-0.55, -0.72),
        "ACT": (0.35, -0.72),
    }
    for source, target in dag_edges:
        frequency = stability_lookup.get(f"{source}->{target}", 0.5)
        radius = 0.08 if {source, target} == {"ISI", "DASS"} else 0.0
        arrow(
            ax,
            positions[source],
            positions[target],
            color="#444444",
            width=0.5 + 4.2 * frequency,
            radius=radius,
            mutation_scale=10,
            shrink=20,
            alpha=0.72,
        )
    draw_nodes(ax, positions, font_size=5.5)
    ax.set_xlim(-1.3, 1.25)
    ax.set_ylim(-1.08, 1.1)
    ax.set_title("Cross-sectional Bayesian DAG")
    ax.axis("off")
    ax.text(
        0.5,
        -0.04,
        "Hill-Climb + BIC; edge width = stability",
        transform=ax.transAxes,
        ha="center",
        fontsize=4.8,
        color=META_GREY,
    )
    panel_letter(ax, "a")

    ax = fig.add_subplot(grid[0, 1])
    top = stability.head(8).iloc[::-1]
    y = np.arange(len(top))
    ax.barh(
        y,
        top["bootstrap_freq"],
        color="#4C74A8",
        edgecolor="black",
        linewidth=0.4,
    )
    ax.set_yticks(y)
    ax.set_yticklabels(top["edge"], fontsize=5.7)
    ax.axvline(0.5, linestyle="--", color="0.65", linewidth=0.7)
    ax.set_xlim(0, 1.0)
    ax.set_xlabel("Bootstrap frequency (200\u00d7)")
    ax.set_title("Directed edge stability")
    panel_letter(ax, "b")

    ax = fig.add_subplot(grid[0, 2])
    x_values = directionality.loc[DOMAINS, "net"].to_numpy(float)
    y_values = dag_net.loc[DOMAINS, "net_outdeg_tertile"].to_numpy(float)
    slope, intercept = np.polyfit(x_values, y_values, 1)
    line_x = np.linspace(x_values.min(), x_values.max(), 100)
    ax.plot(
        line_x,
        slope * line_x + intercept,
        linestyle="--",
        color="0.4",
        linewidth=0.8,
        zorder=1,
    )
    for module, x_value, y_value in zip(DOMAINS, x_values, y_values):
        ax.scatter(
            x_value,
            y_value,
            s=170,
            color=COLORS[module],
            edgecolor="black",
            linewidth=0.7,
            zorder=3,
        )
        if show_point_labels:
            offsets = {
                "CIAS": (4, 4),
                "DASS": (4, 4),
                "SDQ": (4, 4),
                "DIET": (4, 4),
                "ISI": (4, 4),
                "ACT": (4, 4),
            }
            ax.annotate(
                module,
                (x_value, y_value),
                xytext=offsets[module],
                textcoords="offset points",
                fontsize=5.5,
                fontweight="bold",
            )
    ax.axhline(0, color="0.7", linewidth=0.6)
    ax.axvline(0, color="0.7", linewidth=0.6)
    correlation = np.corrcoef(x_values, y_values)[0, 1]
    ax.set_xlabel("CLPN net (longitudinal)")
    ax.set_ylabel("Bayesian DAG net (cross-sectional)")
    ax.set_title(f"Directionally consistent (r = {correlation:.2f})")
    ax.set_xlim(-0.2, 0.3)
    ax.set_ylim(-2.6, 2.8)
    panel_letter(ax, "c")

    save_figure(fig, output_dir, "Figure_3_editable", dpi)


def figure_4(output_dir: Path, dpi: int) -> None:
    mhq_pcor = pd.read_csv(resolve_input("mhq_network_pcor.csv"), index_col=0)
    mhq_pcor = mhq_pcor.rename(index={"PSU": "CIAS"}, columns={"PSU": "CIAS"})
    mhq_pcor = mhq_pcor.loc[DOMAINS, DOMAINS]
    strengths = mhq_pcor.abs().sum(axis=1)

    properties = pd.read_csv(NODE_RESULTS_DIR / "node_properties_mapped.csv")
    adolescent_strength = properties.groupby("module")["strength"].mean()
    adolescent_normalized = adolescent_strength / adolescent_strength.max()
    mhq_normalized = strengths / strengths.max()

    bootstrap_strength = np.load(resolve_input("mhq_boot_strength.npy"))
    bootstrap_domains = ["CIAS", "DASS", "SDQ", "ISI", "DIET", "ACT"]
    if bootstrap_strength.ndim != 2 or bootstrap_strength.shape[1] != len(
        bootstrap_domains
    ):
        raise ValueError(
            "mhq_boot_strength.npy must contain B x 6 bootstrap strength estimates"
        )
    valid_bootstrap = bootstrap_strength[
        np.isfinite(bootstrap_strength).all(axis=1)
    ]
    if valid_bootstrap.size == 0:
        raise ValueError("mhq_boot_strength.npy contains no complete bootstrap repeats")
    ci_bounds = pd.DataFrame(
        np.percentile(valid_bootstrap, [2.5, 97.5], axis=0).T,
        index=bootstrap_domains,
        columns=["low", "high"],
    )
    ci_low = ci_bounds["low"]
    ci_high = ci_bounds["high"]

    fig = plt.figure(figsize=(7.2, 3.25))
    grid = fig.add_gridspec(1, 3, width_ratios=[1.15, 1.0, 1.0], wspace=0.52)

    ax = fig.add_subplot(grid[0, 0])
    positions = {
        "SDQ": (-0.3, 0.78),
        "DASS": (0.55, 0.78),
        "ISI": (-0.72, 0.0),
        "CIAS": (1.05, -0.02),
        "DIET": (-0.3, -0.78),
        "ACT": (0.55, -0.78),
    }
    for source_index, source in enumerate(DOMAINS):
        for target in DOMAINS[source_index + 1 :]:
            value = float(mhq_pcor.loc[source, target])
            if value == 0:
                continue
            ax.plot(
                [positions[source][0], positions[target][0]],
                [positions[source][1], positions[target][1]],
                color="#CB4A3C" if value > 0 else "#3978B5",
                linewidth=0.25 + abs(value) * 18,
                alpha=0.68,
                zorder=1,
            )
    max_strength = strengths.max()
    sizes = {
        module: 210 + 520 * strengths[module] / max_strength for module in DOMAINS
    }
    draw_nodes(ax, positions, sizes=sizes, font_size=5.5)
    ax.set_xlim(-1.15, 1.35)
    ax.set_ylim(-1.18, 1.12)
    ax.set_title("MHQ young-adult network")
    ax.axis("off")
    ax.text(
        0.5,
        -0.08,
        "n = 147,506 \u00b7 240 countries",
        transform=ax.transAxes,
        ha="center",
        fontsize=5.5,
        color=META_GREY,
    )
    panel_letter(ax, "a")

    ax = fig.add_subplot(grid[0, 1])
    x = np.arange(len(DOMAINS))
    width = 0.36
    ax.bar(
        x - width / 2,
        mhq_normalized.loc[DOMAINS],
        width,
        color="#3E70A5",
        edgecolor="black",
        linewidth=0.4,
        label="MHQ (young adults)",
    )
    ax.bar(
        x + width / 2,
        adolescent_normalized.loc[DOMAINS],
        width,
        color="#CF6A42",
        edgecolor="black",
        linewidth=0.4,
        label="This study (adolescents)",
    )
    ax.set_xticks(x)
    ax.set_xticklabels(DOMAINS, fontsize=5.7)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Normalized strength")
    ax.set_title("Cross-cohort comparison", y=1.18)
    ax.legend(
        loc="upper center",
        bbox_to_anchor=(0.5, 1.14),
        fontsize=5.2,
        ncol=1,
        handlelength=1.2,
        borderaxespad=0,
    )
    panel_letter(ax, "b")

    ax = fig.add_subplot(grid[0, 2])
    order = ["CIAS", "ISI", "SDQ", "ACT", "DIET", "DASS"]
    y = np.arange(len(order))[::-1]
    values = strengths.loc[order].to_numpy(float)
    lower = values - np.array([ci_low[module] for module in order])
    upper = np.array([ci_high[module] for module in order]) - values
    ax.barh(
        y,
        values,
        color=[COLORS[module] for module in order],
        edgecolor="black",
        linewidth=0.5,
    )
    ax.errorbar(
        values,
        y,
        xerr=np.vstack([lower, upper]),
        fmt="none",
        ecolor="black",
        elinewidth=0.8,
        capsize=2,
        capthick=0.8,
    )
    ax.set_yticks(y)
    ax.set_yticklabels(order)
    ax.set_xlabel("Strength (95% bootstrap CI)")
    ax.set_title("Emotion hub is robust")
    ax.set_xlim(0, 0.78)
    panel_letter(ax, "c")

    save_figure(fig, output_dir, "Figure_4_editable", dpi)


def figure_5(output_dir: Path, dpi: int) -> None:
    directionality = pd.read_csv(
        resolve_input("mcs_clpn_directionality.csv"), index_col=0
    )
    coefficients = pd.read_csv(resolve_input("mcs_clpn_coefficients.csv"), index_col=0)
    nodes = list(coefficients.index)
    colors = {
        "Internalizing": COLORS["DASS"],
        "Conduct": COLORS["SDQ"],
        "Hyperactivity": COLORS["SDQ"],
        "Peer": COLORS["SDQ"],
        "SocialMedia": COLORS["CIAS"],
        "Gaming": COLORS["CIAS"],
    }
    labels = {
        "Internalizing": "Intern",
        "Conduct": "Conduct",
        "Hyperactivity": "Hyper",
        "Peer": "Peer",
        "SocialMedia": "SocMedia",
        "Gaming": "Gaming",
    }

    fig = plt.figure(figsize=(7.2, 2.9))
    grid = fig.add_gridspec(1, 3, width_ratios=[1, 1, 1.05], wspace=0.5)

    ax = fig.add_subplot(grid[0, 0])
    order = directionality.sort_values("net", ascending=True)
    y = np.arange(len(order))
    for y_value, domain in enumerate(order.index):
        value = order.loc[domain, "net"]
        ax.barh(
            y_value,
            value,
            color=colors[domain],
            edgecolor="black",
            linewidth=0.5,
        )
        low = order.loc[domain, "ci_lo"]
        high = order.loc[domain, "ci_hi"]
        ax.plot([low, high], [y_value, y_value], color="black", linewidth=1.1)
        ax.plot(
            [low, low],
            [y_value - 0.15, y_value + 0.15],
            color="black",
            linewidth=1.1,
        )
        ax.plot(
            [high, high],
            [y_value - 0.15, y_value + 0.15],
            color="black",
            linewidth=1.1,
        )
    ax.set_yticks(y)
    ax.set_yticklabels(order.index)
    ax.axvline(0, color="0.4", linewidth=0.7)
    ax.set_xlabel("Net directionality (out \u2212 in)")
    ax.set_title("MCS age 14\u219217 directionality")
    ax.margins(y=0.06)
    panel_letter(ax, "a")

    ax = fig.add_subplot(grid[0, 1])
    positions = {
        "Hyperactivity": (-0.5, 0.78),
        "Conduct": (0.55, 0.78),
        "Peer": (-0.9, 0.05),
        "Internalizing": (1.08, 0.05),
        "SocialMedia": (-0.5, -0.78),
        "Gaming": (0.55, -0.78),
    }
    matrix = coefficients.to_numpy(float)
    for source_index, source in enumerate(nodes):
        for target_index, target in enumerate(nodes):
            if source == target:
                continue
            beta = matrix[source_index, target_index]
            if abs(beta) < 0.05:
                continue
            radius = 0.10 if source < target else -0.10
            arrow(
                ax,
                positions[source],
                positions[target],
                color="#B44135" if beta > 0 else "#3B6FB6",
                width=0.35 + abs(beta) * 8.5,
                radius=radius,
                mutation_scale=8,
                shrink=17,
                alpha=0.72,
            )
    for node, (x_value, y_value) in positions.items():
        ax.scatter(
            x_value,
            y_value,
            s=500,
            color=colors[node],
            edgecolor="black",
            linewidth=0.8,
            zorder=3,
        )
        ax.text(
            x_value,
            y_value,
            labels[node],
            ha="center",
            va="center",
            color="white",
            fontweight="bold",
            fontsize=5.0,
            zorder=4,
        )
    ax.set_xlim(-1.35, 1.35)
    ax.set_ylim(-1.25, 1.25)
    ax.set_title("Directed temporal network")
    ax.axis("off")
    ax.text(
        0.5,
        -0.04,
        "edges: |\u03b2| \u2265 0.05; red +, blue \u2212",
        transform=ax.transAxes,
        ha="center",
        fontsize=6.2,
        color=META_GREY,
    )
    panel_letter(ax, "b")

    ax = fig.add_subplot(grid[0, 2])
    comparison = pd.DataFrame(
        {
            "Nanjing (emotion)": [0.249, -0.145],
            "MCS (internalizing)": [0.105, -0.211],
        },
        index=["Emotion /\ninternalizing", "Screen /\nactivity"],
    )
    x = np.arange(2)
    width = 0.36
    ax.bar(
        x - width / 2,
        comparison["Nanjing (emotion)"],
        width,
        color=COLORS["DASS"],
        edgecolor="black",
        linewidth=0.5,
        label="Nanjing (emotion)",
    )
    ax.bar(
        x + width / 2,
        comparison["MCS (internalizing)"],
        width,
        color=COLORS["CIAS"],
        edgecolor="black",
        linewidth=0.5,
        label="MCS (internalizing)",
    )
    ax.axhline(0, color="0.4", linewidth=0.7)
    ax.set_xticks(x)
    ax.set_xticklabels(comparison.index)
    ax.set_ylabel("Net directionality")
    ax.set_title("Cross-cohort agreement")
    ax.legend(fontsize=5.6, loc="lower left")
    panel_letter(ax, "c")

    save_figure(fig, output_dir, "Figure_5_editable", dpi)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Rebuild manuscript main figures as editable SVG/PDF."
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=OUTPUT_DIR / "figures" / "main",
    )
    parser.add_argument("--dpi", type=int, default=300)
    parser.add_argument(
        "--fig3-labels",
        action="store_true",
        help="Show domain labels beside points in Figure 3c.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    configure_style()
    figure_1(args.output_dir, args.dpi)
    figure_2(args.output_dir, args.dpi)
    figure_3(args.output_dir, args.dpi, args.fig3_labels)
    figure_4(args.output_dir, args.dpi)
    figure_5(args.output_dir, args.dpi)
    print(f"Saved editable figures to: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
