import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Figure S1a — two-wave individual matching flow (N 10,356 -> 6,092)

Produces : figS1_matching_flow.png
As-run figure code (psunet, Python 3.11, seed 42). Reads the de-identified
derived tables / checkpoints from the analysis trace (repoint <legacy-artifacts>/... paths
to ../../Data/ copies). Part of the split single-topic supplementary figure set.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font] + ["DejaVu Sans", "Arial", "Helvetica"]
    mpl.rcParams.update(rc)


MCOL = {"CIAS": "#2c5f8a", "PSU": "#2c5f8a", "DASS": "#FF76DA", "SDQ": "#e08e0b",
        "DIET": "#27865a", "ISI": "#7d5ba6", "ACT": "#5bb5a2"}

apply_figure_style(sizes=(11, 10, 9))

figw = 7.0
fig, ax = plt.subplots(figsize=(figw, 4.6))
boxes = [("Wave 1 (2022.09–2023.02)", "N = 10,356", 4),
         ("Wave 3 (2024.04 export)", "N = 7,535 (6-domain complete)", 3),
         ("Unique hashed-key match", "name + DOB + sex", 2),
         ("Matched longitudinal sample", "N = 6,092", 1)]
for title, sub, y in boxes:
    ax.add_patch(plt.Rectangle((0.1, y - 0.35), 0.8, 0.7, fc="#eef2f7", ec="#2c4a6e", lw=1.2))
    ax.text(0.5, y + 0.06, title, ha="center", va="center", fontweight="bold", fontsize=11)
    ax.text(0.5, y - 0.16, sub, ha="center", va="center", fontsize=9, color="0.35")
for y in [3.5, 2.5, 1.5]:
    ax.annotate("", xy=(0.5, y + 0.14), xytext=(0.5, y - 0.14),
                arrowprops=dict(arrowstyle="-|>", color="#2c4a6e", lw=1.4))
ax.set_xlim(0, 1)
ax.set_ylim(0.5, 4.7)
ax.axis("off")
ax.set_title("Two-wave individual matching (~1 year apart)", fontsize=12, loc="left", fontweight="bold")
fig.savefig("figS1_matching_flow.png", dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)
