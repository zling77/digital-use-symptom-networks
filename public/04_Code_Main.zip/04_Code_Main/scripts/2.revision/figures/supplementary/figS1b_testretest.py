import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Figure S1b — one-year six-domain score test-retest stability

Produces : figS1b_testretest.png
As-run figure code (psunet, Python 3.11, seed 42). Reads the de-identified
derived tables / checkpoints from the analysis trace (repoint <legacy-artifacts>/... paths
to ../../Data/ copies). Part of the split single-topic supplementary figure set.
"""

import numpy as np
import matplotlib.pyplot as plt

META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42,
    }
    mpl.rcParams.update(rc)


apply_figure_style(sizes=(11, 10, 9))

MCOL = {"CIAS": "#2c5f8a", "PSU": "#2c5f8a", "DASS": "#FF76DA", "SDQ": "#e08e0b",
        "DIET": "#27865a", "ISI": "#7d5ba6", "ACT": "#5bb5a2"}

figw = 7.0

tr = {"CIAS": 0.58, "DASS": 0.62, "SDQ": 0.43, "DIET": 0.34, "ISI": 0.57, "ACT": 0.31}
fig, ax = plt.subplots(figsize=(figw, 4.6))
ks = list(tr)
vals = [tr[k] for k in ks]
ax.bar(ks, vals, color=[MCOL[k] for k in ks], edgecolor="black", lw=0.6)
for i, v in enumerate(vals):
    ax.text(i, v + 0.012, f"{v:.2f}", ha="center", fontsize=10)
ax.axhline(0.30, ls="--", color="0.5", lw=0.9)
ax.set_ylabel("Cross-wave test–retest r (domain score)", fontsize=11)
ax.set_ylim(0, 0.72)
ax.set_title("One-year stability of the six domain scores", fontsize=12, loc="left", fontweight="bold")
fig.savefig("figS1b_testretest.png", dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)
