import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Figure S5b — global efficiency under targeted attack

Produces : figS5b_attack_efficiency.png
As-run figure code (psunet, Python 3.11, seed 42). Reads the de-identified
derived tables / checkpoints from the analysis trace (repoint <legacy-artifacts>/... paths
to ../../Data/ copies). Part of the split single-topic supplementary figure set.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

MCOL = {"CIAS": "#2c5f8a", "PSU": "#2c5f8a", "DASS": "#FF76DA", "SDQ": "#e08e0b", "DIET": "#27865a", "ISI": "#7d5ba6", "ACT": "#5bb5a2"}

eff = pd.read_csv(str(resolve_input('knockout_efficiency.csv')))
fig, ax = plt.subplots(figsize=(7.2, 5.4))
styles = {"MDS drivers (CF)": ("#FF76DA", 2.4, "-"), "Strength": ("#2c5f8a", 1.4, "-"),
          "Bridge strength": ("#27865a", 1.4, "-"), "Betweenness": ("#e08e0b", 1.4, "-"),
          "Random (avg)": ("0.5", 1.2, "--")}
x = np.arange(len(eff))
for col, (c, lw, ls) in styles.items():
    if col in eff:
        ax.plot(x, eff[col], color=c, lw=lw, ls=ls, label=col)
ax.set_xlabel("Nodes removed", fontsize=11)
ax.set_ylabel("Global efficiency", fontsize=11)
ax.set_title("Efficiency under targeted attack (driver removal preserves efficiency)", fontsize=11, loc="left", fontweight="bold")
ax.legend(fontsize=9, loc="upper right")
fig.savefig("figS5b_attack_efficiency.png", dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)
