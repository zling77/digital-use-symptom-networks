import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Figure S4a — six community-detection algorithms vs a-priori domains (ARI, NMI)

Produces : figS4_algorithm_agreement.png
As-run figure code (psunet, Python 3.11, seed 42). Reads the de-identified
derived tables / checkpoints from the analysis trace (repoint <legacy-artifacts>/... paths
to ../../Data/ copies). Part of the split single-topic supplementary figure set.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font] + mpl.rcParams.get("font.sans-serif", [])
    mpl.rcParams.update(rc)


apply_figure_style(sizes=(8, 7, 6))

cm_sum = pd.read_csv(str(resolve_input('community_multimethod_summary.csv')))
print(cm_sum)
fig, ax = plt.subplots(figsize=(7.2, 5.0))
x = np.arange(len(cm_sum)); w = 0.38
ax.bar(x - w/2, cm_sum["ARI_vs_priori"], w, label="ARI", color="#3a6ea5", edgecolor="black", lw=0.5)
ax.bar(x + w/2, cm_sum["NMI_vs_priori"], w, label="NMI", color="#c0504d", edgecolor="black", lw=0.5)
for i, v in enumerate(cm_sum["ARI_vs_priori"]): ax.text(i - w/2, v + 0.012, f"{v:.2f}", ha="center", fontsize=8.5)
ax.set_xticks(x); ax.set_xticklabels(cm_sum["algorithm"], rotation=25, ha="right", fontsize=9.5)
ax.set_ylabel("Agreement with six a-priori domains", fontsize=11); ax.set_ylim(0, 1.0)
ax.set_title("Six community algorithms recover the six-domain structure", fontsize=11, loc="left", fontweight="bold")
ax.legend(fontsize=9)
fig.savefig("figS4_algorithm_agreement.png", dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)
print("S4a done")
