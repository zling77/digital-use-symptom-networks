import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Figure S3c — target controllability (whole / sink / source / domain targets)

Produces : figS3c_target_controllability.png
As-run figure code (psunet, Python 3.11, seed 42). Reads the de-identified
derived tables / checkpoints from the analysis trace (repoint <legacy-artifacts>/... paths
to ../../Data/ copies). Part of the split single-topic supplementary figure set.
"""

import pandas as pd
import matplotlib.pyplot as plt

META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font] + ["DejaVu Sans", "Arial", "Helvetica"]
    mpl.rcParams.update(rc)


apply_figure_style(sizes=(11, 10, 9))

tc = pd.read_csv(str(resolve_input('target_controllability.csv')))

fig, ax = plt.subplots(figsize=(7.4, 5.6))
ax.bar(range(len(tc)), tc["n_drivers"], color="#3a6ea5", edgecolor="black", lw=0.6)
for i, (nd, ntg) in enumerate(zip(tc["n_drivers"], tc["n_target"])):
    ax.text(i, nd + 0.05, f"{nd}\n(/{ntg})", ha="center", va="bottom", fontsize=9)
ax.set_xticks(range(len(tc)))
ax.set_xticklabels(tc["target"], rotation=25, ha="right", fontsize=9)
ax.set_ylabel("Minimum drivers needed", fontsize=11)
ax.set_ylim(0, tc["n_drivers"].max() + 0.7)
ax.set_title("Target controllability: sinks need fewer drivers than sources", fontsize=11.5, loc="left", fontweight="bold")
fig.savefig("figS3c_target_controllability.png", dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)
