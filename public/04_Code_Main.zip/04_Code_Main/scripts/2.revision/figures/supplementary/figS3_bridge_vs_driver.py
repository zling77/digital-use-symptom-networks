import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Figure S3a — bridge centrality vs control frequency (distinct node sets)

Produces : figS3_bridge_vs_driver.png
As-run figure code (psunet, Python 3.11, seed 42). Reads the de-identified
derived tables / checkpoints from the analysis trace (repoint <legacy-artifacts>/... paths
to ../../Data/ copies). Part of the split single-topic supplementary figure set.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font] + ["DejaVu Sans", "Arial", "Helvetica"]
    mpl.rcParams.update(rc)


apply_figure_style(sizes=(11, 10, 9))

MCOL = {"CIAS": "#2c5f8a", "PSU": "#2c5f8a", "DASS": "#FF76DA", "SDQ": "#e08e0b",
        "DIET": "#27865a", "ISI": "#7d5ba6", "ACT": "#5bb5a2"}


def canon(m):
    m = str(m).upper()
    for k in ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]:
        if m.startswith(k):
            return k
    if m.startswith("PSU"):
        return "CIAS"
    return m


enm = pd.read_csv(str(resolve_input('extended_node_metrics.csv')))
enm["cmod"] = enm["module"].map(canon)

fig, ax = plt.subplots(figsize=(7.4, 5.6))
for cm in ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]:
    sub = enm[enm["cmod"] == cm]
    ax.scatter(sub["bridge_strength"], sub["CF"], s=90, color=MCOL[cm],
               edgecolor="black", lw=0.5, label=cm, alpha=0.9)
for _, r in enm.sort_values("CF", ascending=False).head(4).iterrows():
    ax.annotate(r["short"] if pd.notna(r.get("short")) else r["node"],
                (r["bridge_strength"], r["CF"]), fontsize=9, fontweight="bold",
                xytext=(5, 3), textcoords="offset points")
ax.text(0.03, 0.93, "r = 0.21", transform=ax.transAxes, fontsize=11)
ax.set_xlabel("Bridge strength", fontsize=11)
ax.set_ylabel("Control frequency (CF)", fontsize=11)
ax.set_title("Bridge centrality and structural drivers are distinct node sets",
             fontsize=11.5, loc="left", fontweight="bold")
ax.legend(ncol=2, fontsize=9, loc="center right")
fig.savefig("figS3_bridge_vs_driver.png", dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)
