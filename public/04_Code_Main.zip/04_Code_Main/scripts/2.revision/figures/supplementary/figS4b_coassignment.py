import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Figure S4c — bootstrap co-assignment matrix

Produces : figS4b_coassignment.png
As-run figure code (psunet, Python 3.11, seed 42). Reads the de-identified
derived tables / checkpoints from the analysis trace (repoint <legacy-artifacts>/... paths
to ../../Data/ copies). Part of the split single-topic supplementary figure set.
"""

import pickle
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

def autotrim(im, pad=12, white=248):
    a=np.array(im.convert("RGB"))
    mask=(a.min(axis=2)<white)
    rows=np.where(mask.any(axis=1))[0]; cols=np.where(mask.any(axis=0))[0]
    if len(rows)==0: return im
    r0,r1=max(0,rows[0]-pad),min(a.shape[0],rows[-1]+pad)
    c0,c1=max(0,cols[0]-pad),min(a.shape[1],cols[-1]+pad)
    return im.crop((c0,r0,c1,r1))

no = pickle.load(open(str(resolve_input('network_objects.pkl')), 'rb'))

node_order = no["node_order"]
mod_of = no["mod_of"]

MCOL = {"CIAS": "#2c5f8a", "PSU": "#2c5f8a", "DASS": "#FF76DA", "SDQ": "#e08e0b",
        "DIET": "#27865a", "ISI": "#7d5ba6", "ACT": "#5bb5a2"}

def canon(m):
    m = str(m).upper()
    for k in ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]:
        if m.startswith(k): return k
    if m.startswith("PSU"): return "CIAS"
    return m

def cm2(n):
    m = mod_of[n]
    return canon(m)

im = Image.open(str(resolve_input('community_analysis.png'))).convert("RGB")
W, H = im.size
panelc = autotrim(im.crop((2084, 0, W, H)), pad=10)
panelc.save("figS4b_coassignment.png")
