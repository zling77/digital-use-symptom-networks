"""Run local network-control stability analyses.

Outputs:
  network_estimation_robustness.csv
  nulldist_sizes.npy
  nulldist_node_freq.npy
  nulldist_mds.csv
  network_stability_comparison.csv
"""

from __future__ import annotations

import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)


import json
import pickle
import time
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
import pulp
from sklearn.covariance import graphical_lasso
from sklearn.preprocessing import QuantileTransformer


PIPELINE_DIR = ensure_output_dir()
DATA_DIR = REFERENCE_DIR


def solver():
    return pulp.PULP_CBC_CMD(msg=0)


def mds_solve(amat: np.ndarray):
    n = amat.shape[0]
    prob = pulp.LpProblem("mds", pulp.LpMinimize)
    x = [pulp.LpVariable(f"x{i}", cat="Binary") for i in range(n)]
    prob += pulp.lpSum(x)
    for i in range(n):
        nb = [j for j in range(n) if amat[i, j] > 0]
        prob += x[i] + pulp.lpSum(x[j] for j in nb) >= 1
    prob.solve(solver())
    sol = [i for i in range(n) if pulp.value(x[i]) and pulp.value(x[i]) > 0.5]
    return sol


def mds_cf(amat: np.ndarray, n_sol=60, seed=42):
    n = amat.shape[0]
    rng = np.random.default_rng(seed)
    base = mds_solve(amat)
    k = len(base)
    counts = np.zeros(n)
    found = 0
    for _ in range(n_sol):
        prob = pulp.LpProblem("mds_weighted", pulp.LpMinimize)
        x = [pulp.LpVariable(f"x{i}", cat="Binary") for i in range(n)]
        weights = rng.uniform(1, 1.05, n)
        prob += pulp.lpSum(weights[i] * x[i] for i in range(n))
        for i in range(n):
            nb = [j for j in range(n) if amat[i, j] > 0]
            prob += x[i] + pulp.lpSum(x[j] for j in nb) >= 1
        prob += pulp.lpSum(x) <= k
        prob.solve(solver())
        sol = tuple(i for i in range(n) if pulp.value(x[i]) and pulp.value(x[i]) > 0.5)
        if len(sol) == k:
            found += 1
            for i in sol:
                counts[i] += 1
    return counts / max(found, 1), k, found


def ebic_glasso(s: np.ndarray, n: int, gamma=0.5, n_lam=100):
    lam_max = np.abs(s - np.diag(np.diag(s))).max()
    lams = np.geomspace(lam_max, lam_max * 0.01, n_lam)
    best = None
    for lam in lams:
        try:
            cov, prec = graphical_lasso(s, alpha=lam, max_iter=100)
        except Exception:
            continue
        e = (np.abs(prec[np.triu_indices_from(prec, 1)]) > 1e-8).sum()
        sign, logdet = np.linalg.slogdet(prec)
        if sign <= 0:
            continue
        ll = n / 2 * (logdet - np.sum(s * prec))
        p = s.shape[0]
        ebic = -2 * ll + e * np.log(n) + 4 * e * gamma * np.log(p)
        if best is None or ebic < best[0]:
            best = (ebic, lam, prec, e)
    return best


def locate(node_order, sub):
    hits = [i for i, nm in enumerate(node_order) if sub in nm]
    return hits[0] if hits else None


def run_network_estimation_robustness(mds_solutions=60, reselect_ebic=False):
    net = pickle.load(open(PIPELINE_DIR / "network_objects.pkl", "rb"))
    meta = json.load(open(PIPELINE_DIR / "real_meta.json", encoding="utf-8"))
    node_order = meta["node_order"]

    clean = pd.read_csv(SEARCH_DATA_DIR / "preprocessed" / "cleaned_scale_info.csv")
    x = clean[node_order].to_numpy(float)
    xq = QuantileTransformer(output_distribution="normal", random_state=42, subsample=int(1e9)).fit_transform(x)
    s = np.corrcoef(xq.T)
    n = x.shape[0]

    variants = {}
    # These are the manuscript's recorded EBIC-selected grid points. Re-selection
    # is optional because graphical_lasso likelihoods can shift across sklearn versions.
    published_ebic = {0.0: 0.019931710704494125, 0.25: 0.022916623812736063, 0.5: 0.02891749949473567}
    for gamma in [0.0, 0.25, 0.5]:
        if reselect_ebic:
            best = ebic_glasso(s, n, gamma=gamma, n_lam=100)
            if best is None:
                continue
            _, selected_lambda, prec, _ = best
        else:
            selected_lambda = published_ebic[gamma]
            _, prec = graphical_lasso(s, alpha=selected_lambda, max_iter=100)
        a = (np.abs(prec) > 1e-8).astype(int)
        np.fill_diagonal(a, 0)
        variants[f"EBIC gamma={gamma}"] = a

    a_pub = (np.abs(net["adj"]) > 1e-12).astype(int)
    np.fill_diagonal(a_pub, 0)
    variants["Primary CV-glasso"] = a_pub

    pc = net["pcor"]
    a_pos = (pc > 1e-12).astype(int)
    np.fill_diagonal(a_pos, 0)
    variants["CV positive-edges-only"] = a_pos

    idx_diet22 = locate(node_order, "diet_question22")
    idx_dass14 = locate(node_order, "dass_question14")
    idx_sdq18 = locate(node_order, "sdq_question18")
    rows = []
    for name, amat in variants.items():
        if name == "Primary CV-glasso":
            solutions = net["mds_solutions"]
            cf = np.zeros(len(node_order), dtype=float)
            for solution in solutions:
                for node_idx in solution:
                    cf[int(node_idx)] += 1.0
            cf /= max(len(solutions), 1)
            k, found = int(net["mds_size"]), len(solutions)
        else:
            cf, k, found = mds_cf(amat, n_sol=mds_solutions, seed=42)
        order = np.argsort(-cf)
        rank = {i: int(np.where(order == i)[0][0]) + 1 for i in [idx_diet22, idx_dass14, idx_sdq18]}
        rows.append(
            {
                "network": name,
                "density": round(amat.sum() / (len(node_order) * (len(node_order) - 1)), 3),
                "mds_size": k,
                "n_solutions_sampled": found,
                "DIET22_CF": round(cf[idx_diet22], 3),
                "DIET22_rank": rank[idx_diet22],
                "DASS14_CF": round(cf[idx_dass14], 3),
                "DASS14_rank": rank[idx_dass14],
                "SDQ18_CF": round(cf[idx_sdq18], 3),
                "SDQ18_rank": rank[idx_sdq18],
            }
        )
        print(rows[-1])
    pd.DataFrame(rows).to_csv(PIPELINE_DIR / "network_estimation_robustness.csv", index=False)


def run_null_model(b=500):
    net = pickle.load(open(PIPELINE_DIR / "network_objects.pkl", "rb"))
    meta = json.load(open(PIPELINE_DIR / "real_meta.json", encoding="utf-8"))
    node_order, mod_of = meta["node_order"], meta["mod_of"]
    a = (np.abs(net["adj"]) > 1e-12).astype(int)
    np.fill_diagonal(a, 0)
    g = nx.from_numpy_array(a)
    rng = np.random.default_rng(42)
    null_sizes = np.zeros(b, dtype=int)
    node_in_mds = np.zeros(a.shape[0])
    t0 = time.time()
    for i in range(b):
        gs = g.copy()
        nx.double_edge_swap(
            gs,
            nswap=g.number_of_edges() * 3,
            max_tries=g.number_of_edges() * 50,
            seed=int(rng.integers(1e9)),
        )
        an = nx.to_numpy_array(gs)
        an = (an > 0).astype(int)
        np.fill_diagonal(an, 0)
        sol = mds_solve(an)
        null_sizes[i] = len(sol)
        for j in sol:
            node_in_mds[j] += 1
        if (i + 1) % 100 == 0:
            print(f"null {i + 1}/{b} elapsed={time.time() - t0:.0f}s")

    np.save(PIPELINE_DIR / "nulldist_sizes.npy", null_sizes)
    np.save(PIPELINE_DIR / "nulldist_node_freq.npy", node_in_mds / b)

    real_cf = net["mds_cf"]
    rows = []
    for node in ["diet_question22_score", "sdq_question18_score", "dass_question14_score"]:
        idx = node_order.index(node)
        rows.append(
            {
                "node": node.replace("_score", "").replace("sdq_question", "SDQquestion"),
                "module": mod_of[node],
                "degree": int(a[idx].sum()),
                "real_CF": real_cf[node],
                "null_domination_freq": node_in_mds[idx] / b,
            }
        )
    pd.DataFrame(rows).to_csv(PIPELINE_DIR / "nulldist_mds.csv", index=False)


def compare():
    rows = []
    for name in ["network_estimation_robustness.csv", "nulldist_mds.csv"]:
        local = pd.read_csv(PIPELINE_DIR / name)
        paper = pd.read_csv(DATA_DIR / name)
        common = [
            c
            for c in local.columns
            if c in paper.columns
            and pd.api.types.is_numeric_dtype(local[c])
            and pd.api.types.is_numeric_dtype(paper[c])
            and not pd.api.types.is_bool_dtype(local[c])
        ]
        max_abs = np.nan
        if common and len(local) == len(paper):
            max_abs = float((local[common].reset_index(drop=True) - paper[common].reset_index(drop=True)).abs().max().max())
        rows.append({"file": name, "max_abs_numeric_diff": max_abs})
    pd.DataFrame(rows).to_csv(PIPELINE_DIR / "network_stability_comparison.csv", index=False)


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--null-bootstrap', type=int, default=500)
    parser.add_argument('--mds-solutions', type=int, default=60)
    parser.add_argument('--reselect-ebic', action='store_true')
    args = parser.parse_args()
    run_network_estimation_robustness(args.mds_solutions, args.reselect_ebic)
    run_null_model(b=args.null_bootstrap)
    compare()
    print("saved network stability outputs")


if __name__ == "__main__":
    main()
