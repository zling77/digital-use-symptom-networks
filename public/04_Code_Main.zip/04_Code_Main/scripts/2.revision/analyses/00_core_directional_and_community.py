"""Run local revision analyses from current pipeline outputs and compare to Data/.

This script intentionally avoids the original hard-coded <legacy-user-path>/... artifact
paths in the revision scripts. Outputs are written into this pipeline folder.
"""

from __future__ import annotations

import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)


import itertools
import json
import pickle
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy import stats
from scipy.optimize import linear_sum_assignment
from scipy.stats import pearsonr, spearmanr, zscore
from sklearn.covariance import GraphicalLasso
from sklearn.preprocessing import QuantileTransformer

warnings.filterwarnings("ignore")

PIPELINE_DIR = ensure_output_dir()
DATA_DIR = REFERENCE_DIR
DOMS = ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]
ALPHA = 0.05810199433648097


def load_longitudinal():
    ld = pickle.load(open(PIPELINE_DIR / "longitudinal_data.pkl", "rb"))
    d1 = ld["D1"].copy()
    d3 = ld["D3"].copy()
    d1.columns = [c.replace("_w1", "") for c in d1.columns]
    d3.columns = [c.replace("_w3", "") for c in d3.columns]
    return ld, d1[DOMS], d3[DOMS]


def clpn_coef(x1: pd.DataFrame, y3: pd.DataFrame, doms: list[str]):
    b = pd.DataFrame(0.0, index=doms, columns=doms)
    p = pd.DataFrame(1.0, index=doms, columns=doms)
    xc = sm.add_constant(x1[doms])
    for out in doms:
        m = sm.OLS(y3[out], xc).fit(cov_type="HC3")
        for pr in doms:
            b.loc[pr, out] = m.params[pr]
            p.loc[pr, out] = m.pvalues[pr]
    return b, p


def net_dir(b: pd.DataFrame, doms: list[str], pmat: pd.DataFrame | None = None, alpha: float | None = None):
    bo = b.copy().astype(float)
    for d in doms:
        bo.loc[d, d] = 0.0
    mat = bo.abs()
    if pmat is not None and alpha is not None:
        mat = mat * (pmat < alpha).astype(float)
    return mat.sum(axis=1) - mat.sum(axis=0)


def run_clpn_sensitivity(d1, d3):
    x1 = pd.DataFrame(zscore(d1.values, axis=0), columns=DOMS, index=d1.index)
    y3 = pd.DataFrame(zscore(d3.values, axis=0), columns=DOMS, index=d3.index)
    b, p = clpn_coef(x1, y3, DOMS)
    alpha_bonf = 0.05 / 30
    sens = pd.DataFrame({"all_edges": net_dir(b, DOMS), "sig_edges": net_dir(b, DOMS, p, alpha_bonf)})
    sens.round(3).to_csv(PIPELINE_DIR / "clpn_sensitivity.csv")

    doms5 = ["CIAS", "DASS", "SDQ", "ISI", "ACT"]
    b5, _ = clpn_coef(x1[doms5], y3[doms5], doms5)
    net5 = net_dir(b5, doms5)
    pd.DataFrame({"domain": doms5, "net_directionality_5domain": [net5[d] for d in doms5]}).to_csv(
        PIPELINE_DIR / "clpn_5domain.csv", index=False
    )
    print("saved clpn_sensitivity.csv, clpn_5domain.csv")


def run_hash_and_attrition(ld):
    import hashlib
    raw_common_path = next((SEARCH_DATA_DIR / "raw" / "1").glob("**/common_info.csv"))
    raw_common = pd.read_csv(raw_common_path, usecols=["real_name", "birthday", "gender"])
    def _norm_birthday(value):
        value = str(value).strip()
        return value[:-2] if value.endswith(".0") else value
    raw_common["linkkey"] = [
        hashlib.sha1(f"{str(n).strip()}|{_norm_birthday(b)}|{str(g).strip()}".encode()).hexdigest()[:16]
        for n, b, g in zip(raw_common.real_name, raw_common.birthday, raw_common.gender)
    ]
    dup_w1 = raw_common["linkkey"].duplicated(keep=False).sum()
    n_dup_keys = raw_common.loc[raw_common["linkkey"].duplicated(keep=False), "linkkey"].nunique()
    pd.DataFrame(
        {
            "metric": ["W1 records", "records with duplicated key", "distinct duplicated keys", "collision rate %"],
            "value": [len(raw_common), dup_w1, n_dup_keys, round(100 * dup_w1 / len(raw_common), 3)],
        }
    ).to_csv(PIPELINE_DIR / "hash_collision_risk.csv", index=False)
    w1_tmp = pd.read_pickle(PIPELINE_DIR / "w1_tmp.pkl")

    meta = json.load(open(PIPELINE_DIR / "real_meta.json", encoding="utf-8"))
    node_order, mod_of = meta["node_order"], meta["mod_of"]
    clean = pd.read_csv(SEARCH_DATA_DIR / "preprocessed" / "cleaned_scale_info.csv")
    base = pd.DataFrame({"cust_id": clean["cust_id"]})
    for dm in DOMS:
        cols = [c for c in node_order if mod_of[c] == dm]
        base[dm] = clean[cols].sum(axis=1)

    matched_keys = set(ld["W1m"].index)
    w1_link = w1_tmp[["cust_id", "linkkey"]].copy()
    w1_link["matched"] = w1_link["linkkey"].isin(matched_keys)
    base = base.merge(w1_link[["cust_id", "matched"]], on="cust_id", how="left")
    base["matched"] = base["matched"].fillna(False)

    rows = []
    for dm in DOMS:
        m = base.loc[base["matched"], dm]
        u = base.loc[~base["matched"], dm]
        pooled = np.sqrt(((len(m) - 1) * m.var() + (len(u) - 1) * u.var()) / (len(m) + len(u) - 2))
        t, p = stats.ttest_ind(m, u, equal_var=False)
        rows.append(
            {
                "domain": dm,
                "matched_mean": m.mean(),
                "unmatched_mean": u.mean(),
                "SMD_cohens_d": (m.mean() - u.mean()) / pooled,
                "p_value": p,
            }
        )
    pd.DataFrame(rows).to_csv(PIPELINE_DIR / "matched_vs_unmatched.csv", index=False)
    print("saved hash_collision_risk.csv, matched_vs_unmatched.csv")


def get_pgmpy_estimators():
    from pgmpy.estimators import HillClimbSearch

    try:
        from pgmpy.estimators import BIC, BICGauss
    except Exception:
        from pgmpy.estimators import BicScore as BIC

        BICGauss = None
    return HillClimbSearch, BIC, BICGauss


def estimate_dag(data: pd.DataFrame, gaussian: bool = False):
    HillClimbSearch, BIC, BICGauss = get_pgmpy_estimators()
    hc = HillClimbSearch(data)
    score = BICGauss(data) if gaussian and BICGauss is not None else BIC(data)
    return list(hc.estimate(scoring_method=score, show_progress=False).edges())


def edge_net(edges: list[tuple[str, str]], doms=DOMS):
    out = {d: 0 for d in doms}
    for u, v in edges:
        out[u] += 1
        out[v] -= 1
    return out


def run_dag_analyses(d1, bootstrap=200):
    dt = d1.apply(lambda s: pd.qcut(s.rank(method="first"), 3, labels=[0, 1, 2]).astype(int))
    edges = estimate_dag(dt)
    json.dump({"edges": edges}, open(PIPELINE_DIR / "bn_domain_edges.json", "w", encoding="utf-8"), indent=2)

    try:
        edges_gauss = estimate_dag(d1, gaussian=True)
    except Exception:
        edges_gauss = []
    nt = edge_net(edges)
    ng = edge_net(edges_gauss) if edges_gauss else {d: np.nan for d in DOMS}
    dag_rob = pd.DataFrame(
        {
            "domain": DOMS,
            "net_outdeg_tertile": [nt[d] for d in DOMS],
            "net_outdeg_gaussian": [ng[d] for d in DOMS],
        }
    )
    dag_rob["DASS_outgoing_preserved"] = ""
    dag_rob.to_csv(PIPELINE_DIR / "dag_robustness.csv", index=False)

    rng = np.random.default_rng(42)
    counts: dict[tuple[str, str], int] = {}
    n = len(dt)
    for _ in range(bootstrap):
        idx = rng.integers(0, n, n)
        try:
            for e in estimate_dag(dt.iloc[idx].reset_index(drop=True)):
                counts[e] = counts.get(e, 0) + 1
        except Exception:
            continue
    st = pd.DataFrame(
        [{"edge": f"{u}->{v}", "from": u, "to": v, "bootstrap_freq": c / max(bootstrap, 1)} for (u, v), c in counts.items()]
    ).sort_values("bootstrap_freq", ascending=False)
    st.to_csv(PIPELINE_DIR / "bn_edge_stability.csv", index=False)

    clpn = pd.read_csv(PIPELINE_DIR / "clpn_directionality.csv").set_index("domain")
    conv = dag_rob[["domain", "net_outdeg_tertile"]].copy()
    conv["clpn_net_directionality"] = conv["domain"].map(clpn["net"])
    conv.to_csv(PIPELINE_DIR / "directed_convergence.csv", index=False)

    x = conv["clpn_net_directionality"].to_numpy(float)
    y = conv["net_outdeg_tertile"].to_numpy(float)
    pear = pearsonr(x, y).statistic
    spear = spearmanr(x, y).statistic
    exact = np.mean([
        abs(pearsonr(x, np.array(p)).statistic) >= abs(pear)
        for p in itertools.permutations(y)
    ])
    pd.DataFrame(
        [{"pearson_r": pear, "spearman_r": spear, "exact_permutation_p": exact, "n_domains": len(DOMS)}]
    ).to_csv(PIPELINE_DIR / "dag_agreement_robustness.csv", index=False)

    loo = []
    for drop in DOMS:
        keep = [d for d in DOMS if d != drop]
        r = pearsonr(conv.set_index("domain").loc[keep, "clpn_net_directionality"], conv.set_index("domain").loc[keep, "net_outdeg_tertile"]).statistic
        loo.append({"dropped_domain": drop, "pearson_r": r})
    pd.DataFrame(loo).to_csv(PIPELINE_DIR / "dag_leave_one_domain_out.csv", index=False)
    print("saved DAG analyses")


def build_ggm(df_x: pd.DataFrame, cols: list[str], alpha=ALPHA):
    qt = QuantileTransformer(output_distribution="normal", random_state=42, subsample=int(1e9))
    xq = qt.fit_transform(df_x[cols].to_numpy(float))
    gl = GraphicalLasso(alpha=alpha, max_iter=1000).fit(xq)
    prec = gl.precision_.copy()
    d = np.sqrt(np.diag(prec))
    pc = -prec / np.outer(d, d)
    np.fill_diagonal(pc, 0)
    return pc


def run_community_evolution(ld, bootstrap=100):
    import igraph as ig
    import leidenalg
    from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score

    w1m, w3p = ld["W1m"], ld["W3p"]
    mod_of = ld["mod_of"]
    comparable = ld["comparable_nodes"]
    pc1 = build_ggm(w1m, comparable)
    pc3 = build_ggm(w3p, comparable)

    def graph_from_pc(pc):
        a = np.abs(pc).copy()
        np.fill_diagonal(a, 0)
        src, tgt = np.triu_indices_from(a, 1)
        edges = [(int(i), int(j)) for i, j in zip(src, tgt) if a[i, j] > 1e-8]
        weights = [a[i, j] for i, j in edges]
        g = ig.Graph(n=len(comparable), edges=edges)
        g.es["weight"] = weights
        return g

    mem1 = np.array(leidenalg.find_partition(graph_from_pc(pc1), leidenalg.ModularityVertexPartition, weights="weight", seed=42).membership)
    mem3 = np.array(leidenalg.find_partition(graph_from_pc(pc3), leidenalg.ModularityVertexPartition, weights="weight", seed=42).membership)

    def align(a, b):
        ka, kb = len(set(a)), len(set(b))
        mat = np.zeros((ka, kb))
        for x, y in zip(a, b):
            mat[x, y] += 1
        ri, ci = linear_sum_assignment(-mat)
        mapping = {ci[k]: ri[k] for k in range(len(ri))}
        return np.array([mapping.get(y, -1) for y in b])

    mem3a = align(mem1, mem3)
    evo = pd.DataFrame(
        {
            "node": comparable,
            "module": [mod_of[c] for c in comparable],
            "comm_w1": mem1,
            "comm_w3": mem3a,
            "changed": mem1 != mem3a,
        }
    )
    evo.to_csv(PIPELINE_DIR / "community_evolution_table.csv", index=False)
    summary = pd.DataFrame(
        [{"ARI": adjusted_rand_score(mem1, mem3a), "NMI": normalized_mutual_info_score(mem1, mem3a), "changed_nodes": int(evo["changed"].sum())}]
    )
    summary.to_csv(PIPELINE_DIR / "community_evolution_summary.csv", index=False)

    # Lightweight node stability: frequency that each node keeps the same aligned community across 100 resamples.
    rng = np.random.default_rng(42)
    n = len(w1m)
    stable = np.zeros(len(comparable))
    b = bootstrap
    for i in range(b):
        idx = rng.integers(0, n, n)
        try:
            m1 = np.array(
                leidenalg.find_partition(
                    graph_from_pc(build_ggm(w1m.iloc[idx], comparable)),
                    leidenalg.ModularityVertexPartition,
                    weights="weight",
                    seed=int(rng.integers(1e9)),
                ).membership
            )
            m3 = np.array(
                leidenalg.find_partition(
                    graph_from_pc(build_ggm(w3p.iloc[idx], comparable)),
                    leidenalg.ModularityVertexPartition,
                    weights="weight",
                    seed=int(rng.integers(1e9)),
                ).membership
            )
            m3a = align(m1, m3)
            stable += (m1 == m3a)
        except Exception:
            continue
        if (i + 1) % 20 == 0:
            print(f"  community stability {i + 1}/{b}")
    pd.DataFrame({"node": comparable, "module": [mod_of[c] for c in comparable], "same_comm_freq": stable / b}).to_csv(
        PIPELINE_DIR / "community_node_stability.csv", index=False
    )
    print("saved community evolution/stability")


def compare_outputs():
    rows = []
    for name in [
        "clpn_sensitivity.csv",
        "clpn_5domain.csv",
        "hash_collision_risk.csv",
        "matched_vs_unmatched.csv",
        "dag_robustness.csv",
        "directed_convergence.csv",
        "dag_agreement_robustness.csv",
        "dag_leave_one_domain_out.csv",
        "community_evolution_table.csv",
    ]:
        local = PIPELINE_DIR / name
        paper = DATA_DIR / name
        status = "missing"
        max_abs = np.nan
        if local.exists() and paper.exists():
            a = pd.read_csv(local)
            b = pd.read_csv(paper)
            common = [
                c
                for c in a.columns
                if c in b.columns
                and pd.api.types.is_numeric_dtype(a[c])
                and pd.api.types.is_numeric_dtype(b[c])
                and not pd.api.types.is_bool_dtype(a[c])
                and not pd.api.types.is_bool_dtype(b[c])
            ]
            status = "compared"
            if common and len(a) == len(b):
                max_abs = float((a[common].reset_index(drop=True) - b[common].reset_index(drop=True)).abs().max().max())
        elif local.exists():
            status = "local_only"
        rows.append({"file": name, "status": status, "max_abs_numeric_diff": max_abs})
    pd.DataFrame(rows).to_csv(PIPELINE_DIR / "local_revision_analysis_comparison.csv", index=False)


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--dag-bootstrap', type=int, default=200)
    parser.add_argument('--community-bootstrap', type=int, default=100)
    args = parser.parse_args()
    ld, d1, d3 = load_longitudinal()
    print("matched n:", ld["n_matched"])
    run_clpn_sensitivity(d1, d3)
    run_hash_and_attrition(ld)
    run_dag_analyses(d1, args.dag_bootstrap)
    run_community_evolution(ld, args.community_bootstrap)
    compare_outputs()
    print("saved local_revision_analysis_comparison.csv")


if __name__ == "__main__":
    main()
