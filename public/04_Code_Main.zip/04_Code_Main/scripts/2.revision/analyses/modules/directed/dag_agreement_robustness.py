import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
CLPN<->DAG agreement: Pearson/Spearman, exact 6! permutation p, bootstrap 95% CI

Produces : dag_agreement_robustness.csv
Key inputs: dag_robustness.csv (BN tertile net out-degree), CLPN net directionality

As-run analysis code from the revision cycle (environment: psunet, seed 42).
Data-store paths [resolve_input(...) / absolute <legacy-artifacts>/...] point to the
reviewer data tables shipped in ../../Data/ or the reproducible checkpoints; repoint
them to your local copies to re-run. Numbers match the manuscript and Response letter.
"""

import pandas as pd
import numpy as np
from scipy.stats import pearsonr, spearmanr
from itertools import permutations

# Use the full-precision machine-readable values shared with the figure and SI.
comparison = pd.read_csv(resolve_input("directed_convergence.csv"))
x = comparison["clpn_net"].to_numpy(float)
y = comparison["bn_net"].to_numpy(float)

r_p, p_p = pearsonr(x, y)
r_s, p_s = spearmanr(x, y)

# Exact permutation test (6! = 720 permutations)
perm_r = [pearsonr(x, y[list(pm)])[0] for pm in permutations(range(6))]
perm_r = np.array(perm_r)
p_perm = np.mean(np.abs(perm_r) >= abs(r_p))

# Bootstrap CI over the 6 points
rng = np.random.default_rng(42)
boot = []
for _ in range(5000):
    idx = rng.integers(0, 6, 6)
    if len(set(idx)) > 1:
        try:
            boot.append(pearsonr(x[idx], y[idx])[0])
        except:
            pass
ci = np.nanpercentile(boot, [2.5, 97.5])

agg = pd.DataFrame({
    "statistic": ["Pearson r", "Pearson P (two-sided)", "Spearman rho", "Spearman P (two-sided)",
                  "exact permutation P (two-sided)", "bootstrap CI low", "bootstrap CI high"],
    "value": [round(r_p, 3), round(p_p, 3), round(r_s, 3), round(p_s, 3),
              round(p_perm, 4), round(ci[0], 3), round(ci[1], 3)]
})
agg.to_csv(ensure_output_dir() / "dag_agreement_robustness.csv", index=False)
