import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
DAG<->CLPN agreement: leave-one-domain-out refit

Produces : dag_leave_one_domain_out.csv
           (the Pearson/Spearman + exact-permutation + bootstrap-CI table is in
            dag_agreement_robustness.py, which writes dag_agreement_robustness.csv)
Key inputs: dag_robustness.csv (BN tertile net out-degree), CLPN net directionality

As-run analysis code from the revision cycle (environment: psunet, seed 42).
Data-store paths [resolve_input(...) / absolute <legacy-artifacts>/...] point to the
reviewer data tables shipped in ../../Data/ or the reproducible checkpoints; repoint
them to your local copies to re-run. Numbers match the manuscript and Response letter.
"""

import pandas as pd
import numpy as np
from scipy.stats import pearsonr

doms = ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]

clpn_vec = {"CIAS": -0.061, "DASS": 0.249, "SDQ": -0.090, "DIET": -0.014, "ISI": 0.061, "ACT": -0.145}

dr = pd.read_csv(str(resolve_input('dag_robustness.csv')))
bn_vec = dict(zip(dr["domain"], dr["net_outdeg_tertile"]))

x = np.array([clpn_vec[d] for d in doms])
y = np.array([bn_vec[d] for d in doms])

loo = []
for k, dleft in enumerate(doms):
    keep = [i for i in range(6) if i != k]
    rk, _ = pearsonr(x[keep], y[keep])
    loo.append({"dropped": dleft, "r_without": round(rk, 3)})

loo_df = pd.DataFrame(loo)
loo_df.to_csv("dag_leave_one_domain_out.csv", index=False)
