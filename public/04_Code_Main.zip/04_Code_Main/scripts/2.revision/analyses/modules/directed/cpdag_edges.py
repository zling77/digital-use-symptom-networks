import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
CPDAG / Markov-equivalence class of the domain DAG; which edges are orientable vs reversible

Produces : cpdag_edges.csv
Key inputs: longitudinal_data.pkl (D1 domain scores)

As-run analysis code from the revision cycle (environment: psunet, seed 42).
Data-store paths [resolve_input(...) / absolute <legacy-artifacts>/...] point to the
reviewer data tables shipped in ../../Data/ or the reproducible checkpoints; repoint
them to your local copies to re-run. Numbers match the manuscript and Response letter.
"""

import pickle
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

from pgmpy.estimators import HillClimbSearch, BIC
from pgmpy.base import DAG

doms = ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]

ld = pickle.load(open(str(resolve_input('longitudinal_data.pkl')), "rb"))
D1 = ld["D1"]
Dc = D1.copy()
Dc.columns = doms

Dt = Dc.apply(lambda s: pd.qcut(s.rank(method="first"), 3, labels=[0, 1, 2]).astype(int))
hc = HillClimbSearch(Dt)
dag_tertile = hc.estimate(scoring_method=BIC(Dt), show_progress=False)
edges_tertile = list(dag_tertile.edges())

dag_obj = DAG(edges_tertile)
dag_obj.add_nodes_from(doms)
cpdag = dag_obj.to_pdag()

cp_edges = list(cpdag.edges())
es = set(cp_edges)
undirected = set()
for u, v in cp_edges:
    if (v, u) in es:
        undirected.add(frozenset({u, v}))

cpdag_summary = pd.DataFrame({
    "edge": [f"{a}—{b}" for a, b in [tuple(x) for x in undirected]],
    "status": ["reversible (Markov-equivalent)"] * len(undirected)
})
cpdag_summary.to_csv("cpdag_edges.csv", index=False)
