import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
DAG robustness — tertile-discretized + continuous-Gaussian Bayesian networks; net out-degree per domain

Produces : dag_robustness.csv
Inputs   : longitudinal_data.pkl (D1 domain scores)
Run order: pgmpy HillClimb+BIC / BICGauss

As-run code from the revision cycle (environment: psunet, Python 3.11, seed 42).
Reads the original Nanjing SEARCH raw exports under
  <legacy-user-path>/xizhezhang/mac\u6570\u636e/code/\u5f20\u73b2-PSU/plan/data/raw/
and the external GMP / MCS files; repoint those paths to your local copies.
Data-store paths (<legacy-artifacts>/... or resolve_input) are reproducible
checkpoints from the analysis trace. Numbers match the manuscript, SI and
Response-to-Reviewers.
"""

import pickle
import numpy as np
import pandas as pd
import pgmpy
from pgmpy.estimators import HillClimbSearch, BIC, BICGauss
import warnings
warnings.filterwarnings("ignore")

ld = pickle.load(open(str(resolve_input('longitudinal_data.pkl')), 'rb'))

doms = ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]
D1 = ld["D1"]
Dc = D1.copy()
Dc.columns = doms

# --- (a) tertile-discretized DAG ---
Dt = Dc.apply(lambda s: pd.qcut(s.rank(method="first"), 3, labels=[0, 1, 2]).astype(int))
hc = HillClimbSearch(Dt)
dag_tertile = hc.estimate(scoring_method=BIC(Dt), show_progress=False)
edges_tertile = list(dag_tertile.edges())

# --- (b) continuous Gaussian Bayesian network ---
hcg = HillClimbSearch(Dc)
dag_gauss = hcg.estimate(scoring_method=BICGauss(Dc), show_progress=False)
edges_gauss = list(dag_gauss.edges())

def net_outdeg(edges):
    nod = {dm: 0 for dm in doms}
    for u, v in edges:
        nod[u] += 1
        nod[v] -= 1
    return nod

nt = net_outdeg(edges_tertile)
ng = net_outdeg(edges_gauss)

dag_rob = pd.DataFrame({
    "domain": doms,
    "net_outdeg_tertile": [nt[dm] for dm in doms],
    "net_outdeg_gaussian": [ng[dm] for dm in doms],
})
dag_rob["DASS_outgoing_preserved"] = ""
dag_rob.to_csv("dag_robustness.csv", index=False)
