import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Dynamical module-perturbation simulation — tanh spreading on the spectrally-normalized network

Produces : dynamics_sim.pkl (per-module trajectories + sink activation); dynamics_summary.csv is derived from it
Inputs   : network_objects.pkl
Run order: -

As-run code from the revision cycle (environment: psunet, Python 3.11, seed 42).
Reads the original Nanjing SEARCH raw exports under
  <legacy-user-path>/xizhezhang/mac\u6570\u636e/code/\u5f20\u73b2-PSU/plan/data/raw/
and the external GMP / MCS files; repoint those paths to your local copies.
Data-store paths (<legacy-artifacts>/... or resolve_input) are reproducible
checkpoints from the analysis trace. Numbers match the manuscript, SI and
Response-to-Reviewers.
"""

import numpy as np
import pickle
import json

# Load network objects
netobj = pickle.load(open("network_objects.pkl", "rb"))
pcor = netobj["pcor"]
node_order = netobj["node_order"]
mod_of = netobj["mod_of"]

A = np.abs(pcor).copy()
np.fill_diagonal(A, 0)
ev = np.abs(np.linalg.eigvals(A)).max()
An = A / (ev * 1.05)
p = len(node_order)
mods = ["DIET", "SDQ", "DASS", "CIAS", "ISI", "ACT"]
idx_by_mod = {m: [i for i, n in enumerate(node_order) if mod_of[n] == m] for m in mods}

def simulate(perturb_mod, g=0.9, T=50, drive=1.0):
    x = np.zeros(p)
    total = []
    for t in range(T):
        u = np.zeros(p)
        for i in idx_by_mod[perturb_mod]: u[i] = drive
        x = np.tanh(g * (An @ x) + u)
        total.append(x.sum())
    return np.array(total)

sim = {}
for m in mods:
    sim[m] = simulate(m)
    print(f"perturb {m}: steady-state total activation = {sim[m][-1]:.2f}")

def sink_activation(perturb_mod, g=0.9, T=50):
    x = np.zeros(p)
    for t in range(T):
        u = np.zeros(p)
        for i in idx_by_mod[perturb_mod]: u[i] = 1.0
        x = np.tanh(g * (An @ x) + u)
    sink_idx = idx_by_mod["ISI"] + idx_by_mod["ACT"]
    return x[sink_idx].mean()

print("\nActivation reaching sink modules (ISI+ACT) when perturbing each module:")
sinkact = {m: sink_activation(m) for m in mods}
for m in sorted(sinkact, key=lambda x: -sinkact[x]):
    print(f"  {m}: {sinkact[m]:.3f}")

pickle.dump({"sim": sim, "sinkact": sinkact}, open("dynamics_sim.pkl", "wb"))
