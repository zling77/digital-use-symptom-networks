import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Targeted-attack knockout — global efficiency / LCC as nodes are removed by CF, strength, bridge, betweenness, random

Produces : attack_curves.pkl; knockout_efficiency.csv and knockout_lcc.csv are derived from it
Inputs   : network_objects.pkl, extended_node_metrics.csv, psu_pipeline.py, author node_properties_mapped.csv
Run order: networkx global_efficiency

As-run code from the revision cycle (environment: psunet, Python 3.11, seed 42).
Reads the original Nanjing SEARCH raw exports under
  <legacy-user-path>/xizhezhang/mac\u6570\u636e/code/\u5f20\u73b2-PSU/plan/data/raw/
and the external GMP / MCS files; repoint those paths to your local copies.
Data-store paths (<legacy-artifacts>/... or resolve_input) are reproducible
checkpoints from the analysis trace. Numbers match the manuscript, SI and
Response-to-Reviewers.
"""

import numpy as np
import pandas as pd
import networkx as nx
import json
import pickle



import os
import sys
import glob
import re
import hashlib
import importlib

os.chdir(OUTPUT_DIR)
sys.path.insert(0, os.getcwd())

import psu_pipeline as pp
importlib.reload(pp)

RAW = str(SEARCH_DATA_DIR / 'raw')
W1 = f"{RAW}/1/202208-202302省疾控心理筛查活动"
W3d2 = f"{RAW}/3/心理量表导出_第四次数据导出_按照数据模版_20240401/scale_detailed_data"

PLAN = str(PROJECT_ROOT)

meta = json.load(open("real_meta.json"))
node_order = meta["node_order"]
mod_of = meta["mod_of"]
ALPHA = meta["alpha"]

netobj = pickle.load(open("network_objects.pkl", "rb"))
pcor = netobj["pcor"]
cf = netobj["mds_cf"]

ext = pd.read_csv("extended_node_metrics.csv").set_index("node")

A = np.abs(pcor).copy()
np.fill_diagonal(A, 0)
p = len(node_order)

auth = pd.read_csv(str(resolve_input('node_properties_mapped.csv'))).set_index("index")

orderings = {
    "MDS drivers (CF)": sorted(node_order, key=lambda n: -cf[n]),
    "Bridge strength":  ext["bridge_strength"].reindex(node_order).sort_values(ascending=False).index.tolist(),
    "Betweenness":      ext["bridge_betweenness"].reindex(node_order).sort_values(ascending=False).index.tolist(),
}
orderings["Strength"] = auth["strength"].reindex(node_order).sort_values(ascending=False).index.tolist()


def attack_curve(order, weighted=True):
    idx = {n: i for i, n in enumerate(node_order)}
    remaining = list(range(p))
    lcc = []
    eff = []
    Acur = A.copy()
    for step, nd in enumerate([None] + order):
        if nd is not None:
            r = idx[nd]
            if r in remaining:
                remaining.remove(r)
        sub = np.array(remaining)
        if len(sub) < 2:
            lcc.append(0)
            eff.append(0)
            continue
        As = (A[np.ix_(sub, sub)] > 1e-8).astype(int)
        G = nx.from_numpy_array(As)
        cc = max(nx.connected_components(G), key=len) if G.number_of_edges() > 0 else set()
        lcc.append(len(cc) / p)
        eff.append(nx.global_efficiency(G))
    return lcc, eff


curves = {}
rng = np.random.default_rng(1)
for name, order in orderings.items():
    curves[name] = attack_curve(order[:60])
# random baseline (avg of 20)
rand_lcc = np.zeros(61)
rand_eff = np.zeros(61)
for _ in range(20):
    o = list(node_order)
    rng.shuffle(o)
    l, e = attack_curve(o[:60])
    rand_lcc += np.array(l)
    rand_eff += np.array(e)
curves["Random (avg)"] = (rand_lcc / 20, rand_eff / 20)
print("attack curves computed:", list(curves.keys()))
pickle.dump(curves, open("attack_curves.pkl", "wb"))
