import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Cross-method correlation among control/centrality metrics (control frequency vs strength/EI/bridge/betweenness/controllability)

Produces : method_convergence_corr.csv
Key inputs: extended_node_metrics.csv

As-run analysis code from the revision cycle (environment: psunet, seed 42).
Data-store paths [resolve_input(...) / absolute <legacy-artifacts>/...] point to the
reviewer data tables shipped in ../../Data/ or the reproducible checkpoints; repoint
them to your local copies to re-run. Numbers match the manuscript and Response letter.
"""

# skill:figure-style kernel.py (auto-injected on skill load)
META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font, "DejaVu Sans"]
    mpl.rcParams.update(rc)


import pandas as pd, numpy as np, pickle
from scipy.stats import spearmanr

PLAN=str(PROJECT_ROOT)
np_auth=pd.read_csv(str(resolve_input("node_properties_mapped.csv")))
ext=pd.read_csv(str(resolve_input('extended_node_metrics.csv')))
m=np_auth.merge(ext,left_on="index",right_on="node",how="inner")

metrics=["strength","closeness_centrality","betweenness_centrality","eigenvector_centrality",
         "bridge_centrality","average_controllability","modal_controllability",
         "control_frequency","participation_coefficient",
         "EI1","EI2","bridge_strength","bridge_betweenness","control_energy_log"]
metrics=[x for x in metrics if x in m.columns]
M=m[metrics].apply(pd.to_numeric,errors="coerce")
from scipy.stats import spearmanr
corr,_=spearmanr(M.values)
corr=pd.DataFrame(corr,index=metrics,columns=metrics)

metrics=[x for x in metrics if x!="bridge_centrality"]
M=m[metrics].apply(pd.to_numeric,errors="coerce").fillna(m[metrics].median())
corr,_=spearmanr(M.values); corr=pd.DataFrame(corr,index=metrics,columns=metrics)
corr.to_csv("method_convergence_corr.csv")
