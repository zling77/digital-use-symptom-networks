import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
Domain-level structural-control vs CLPN net-directionality (Spearman rho=0.71)

Produces : domain_level_comparison.csv
Key inputs: network_objects.pkl, clpn_directionality.csv

As-run analysis code from the revision cycle (environment: psunet, seed 42).
Data-store paths [resolve_input(...) / absolute <legacy-artifacts>/...] point to the
reviewer data tables shipped in ../../Data/ or the reproducible checkpoints; repoint
them to your local copies to re-run. Numbers match the manuscript and Response letter.
"""

import json
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

# Load metadata
meta = json.load(open(str(resolve_input('real_meta.json'))))
node_order = meta["node_order"]

doms = ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]

def modname(nm):
    for p, dm in [("cias", "CIAS"), ("dass", "DASS"), ("sdq", "SDQ"), ("diet", "DIET"), ("isi", "ISI"), ("activity", "ACT")]:
        if nm.startswith(p):
            return dm
    return "?"

dom_of = [modname(nm) for nm in node_order]

# Load cleaned scale info
clean = pd.read_csv(str(resolve_input('cleaned_scale_info.csv')))

# Domain scores (sum of items) full baseline
DB = pd.DataFrame({dm: clean[[node_order[i] for i in range(104) if dom_of[i] == dm]].sum(1) for dm in doms})

from scipy.stats import zscore
DBz = DB.apply(zscore)

# GGM on 6 domains via partial correlation from precision matrix
Sd = np.corrcoef(DBz.values.T)
prec = np.linalg.inv(Sd)
d_ = np.sqrt(np.diag(prec))
pcor_dom = -prec / np.outer(d_, d_)
np.fill_diagonal(pcor_dom, 0)

strength_dom = {doms[i]: np.abs(pcor_dom[i]).sum() for i in range(6)}

clpn_net_dom = {"CIAS": -0.061, "DASS": 0.249, "SDQ": -0.090, "DIET": -0.014, "ISI": 0.061, "ACT": -0.145}

cmp = pd.DataFrame({
    "domain": doms,
    "domain_structural_strength": [strength_dom[d] for d in doms],
    "clpn_net_directionality": [clpn_net_dom[d] for d in doms]
})
cmp["struct_rank"] = cmp["domain_structural_strength"].rank(ascending=False).astype(int)
cmp["temporal_rank"] = cmp["clpn_net_directionality"].rank(ascending=False).astype(int)

cmp.to_csv("domain_level_comparison.csv", index=False)
