import sys as _sys
from pathlib import Path as _Path
_PROJECT_ROOT = next(
    p for p in [_Path(__file__).resolve().parent, *_Path(__file__).resolve().parents]
    if (p / "project_paths.py").exists()
)
if str(_PROJECT_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_PROJECT_ROOT))
from project_paths import (
    PROJECT_ROOT, SEARCH_DATA_DIR, OUTPUT_DIR, REFERENCE_DIR,
    BASELINE_DIR, ensure_output_dir, resolve_input
)

"""
CLPN with age/sex/grade covariates + school-clustered SE

Produces : clpn_covariate_sensitivity.csv
Key inputs: longitudinal_data.pkl, common_info.csv (covariates), raw W1 org_name (school)

As-run analysis code from the revision cycle (environment: psunet, seed 42).
Data-store paths [resolve_input(...) / absolute <legacy-artifacts>/...] point to the
reviewer data tables shipped in ../../Data/ or the reproducible checkpoints; repoint
them to your local copies to re-run. Numbers match the manuscript and Response letter.
"""

import pickle
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import zscore

# Load longitudinal data
ld = pickle.load(open(str(resolve_input('longitudinal_data.pkl')), "rb"))
D1 = ld["D1"].copy()
D3 = ld["D3"].copy()
doms = ["CIAS", "DASS", "SDQ", "DIET", "ISI", "ACT"]
D1.columns = [c.replace("_w1", "") for c in D1.columns]
D3.columns = [c.replace("_w3", "") for c in D3.columns]

# Load linkkeys and matched individuals
lk = pd.read_csv(str(resolve_input('w1_linkkeys.csv')))
mi = pd.read_csv(str(resolve_input('matched_individuals.csv')))

# linkkey -> cust_id (W1)
lk2 = lk.drop_duplicates("linkkey").set_index("linkkey")["cust_id"]

# Load common_info for covariates
common = pd.read_csv(str(resolve_input('common_info.csv')))
common["sex_num"] = (common["sex"] == "男").astype(int)
cov = common.set_index("cust_id")[["age", "sex_num", "grade"]]

# Build covariate frame aligned to D1 index (linkkey)
idx = D1.index
cust = lk2.reindex(idx)
covdf = pd.DataFrame(index=idx)
covdf["cust_id"] = cust.values
covdf = covdf.join(cov, on="cust_id")

# Load school info
raw_common = pd.read_csv(
    str(resolve_input('common_info.csv')),
    usecols=["cust_id", "org_name"]
)
school = raw_common.drop_duplicates("cust_id").set_index("cust_id")["org_name"]
covdf["school"] = covdf["cust_id"].map(school)
school_codes = covdf["school"].astype("category").cat.codes.values

Z1 = D1[doms].apply(zscore)
Z3 = D3[doms].apply(zscore)
Cov = covdf[["age", "sex_num", "grade"]].apply(zscore)


def clpn_net(Z1, Z3, extra=None, cluster=None):
    B = np.zeros((6, 6))
    X0 = Z1.copy()
    if extra is not None:
        X0 = pd.concat([X0, extra], axis=1)
    X = sm.add_constant(X0)
    for j, dj in enumerate(doms):
        y = Z3[dj].values
        if cluster is not None:
            res = sm.OLS(y, X).fit(cov_type="cluster", cov_kwds={"groups": cluster})
        else:
            res = sm.OLS(y, X).fit(cov_type="HC3")
        for i, di in enumerate(doms):
            B[i, j] = res.params[di]
    net = {}
    for i, di in enumerate(doms):
        out = np.sum(np.abs(B[i, :])) - np.abs(B[i, i])
        inn = np.sum(np.abs(B[:, i])) - np.abs(B[i, i])
        net[di] = out - inn
    return net, B


net_prim, _ = clpn_net(Z1, Z3)
net_cov, _ = clpn_net(Z1, Z3, extra=Cov)
net_clus, _ = clpn_net(Z1, Z3, cluster=school_codes)

res = pd.DataFrame({
    "domain": doms,
    "net_primary": [net_prim[d] for d in doms],
    "net_covariate_adj": [net_cov[d] for d in doms],
    "net_cluster_robust": [net_clus[d] for d in doms]
})

res.to_csv("clpn_covariate_sensitivity.csv", index=False)
