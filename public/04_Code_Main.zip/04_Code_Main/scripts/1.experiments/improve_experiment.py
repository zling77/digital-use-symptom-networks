from __future__ import annotations

import argparse
import math
import os
import sys
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import numpy as np
import pandas as pd

# 可选依赖：画图更美观；缺失时自动降级到 matplotlib
try:
    import seaborn as sns  # type: ignore
except Exception:  # pragma: no cover
    sns = None

import matplotlib.pyplot as plt

from scipy import stats

import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.diagnostic import het_breuschpagan


# ----------------------------
# 路径与运行环境
# ----------------------------

def _find_plan_root() -> Path:
    """
    以当前脚本位置为锚点，找到 plan/ 根目录（包含 data/、results/、src/）。
    """
    here = Path(__file__).resolve()
    # .../plan/scripts/1.experiments/6.improve_experiment.py
    # => plan_root = .../plan
    for p in [here.parent, *here.parents]:
        if (p / "data").exists() and (p / "results").exists() and (p / "src").exists():
            return p
    # fallback：当前工作目录向上找
    cwd = Path.cwd().resolve()
    for p in [cwd, *cwd.parents]:
        if (p / "data").exists() and (p / "results").exists() and (p / "src").exists():
            return p
    raise RuntimeError("未找到 plan 根目录（需包含 data/、results/、src/）。")


def _ensure_cwd(plan_root: Path) -> None:
    try:
        os.chdir(plan_root)
    except Exception as e:
        raise RuntimeError(f"无法切换到工作目录 {plan_root}: {e}") from e


def _now_run_id() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


# ----------------------------
# 工具：基于条目得分和节点强度构造个体层面的 IndStrength
# ----------------------------

def compute_individual_strength_from_cleaned(plan_root: Path) -> Path:
    """
    基于当前项目已有结果，构造一个“可复现、可在方法中精确定义”的
    individual-level 网络耦合指标 IndStrength，并保存为 CSV。

    设计思路：
    - 使用 full-sample GGM 得到的节点 strength（node_properties_mapped.csv）
      作为权重 s_j；
    - 对 cleaned_scale_info.csv 中对应条目列做 nonparanormal（秩→正态）变换，得到
      每个个体 i 在每个节点 j 的 x_ij~；
    - 定义
          IndStrength_i = (1 / P) * sum_j x_ij~ * s_j
      其中 P 为参与计算的节点个数。

    返回值：
        生成的 CSV 路径：
        results/experiments/statistical_tests/individual_strength_recomputed.csv
    """
    import numpy as np
    from scipy.stats import rankdata, norm

    plan_root = plan_root.resolve()

    # 1) 读取条目数据与人口学信息
    scale_path = plan_root / "data/preprocessed/cleaned_scale_info.csv"
    info_path = plan_root / "data/preprocessed/common_info.csv"
    node_path = plan_root / "results/experiments/network_analysis/lasso_method=cv#mds_method=precise/node_properties_mapped.csv"

    if not scale_path.exists():
        raise FileNotFoundError(f"cleaned_scale_info.csv 不存在: {scale_path}")
    if not info_path.exists():
        raise FileNotFoundError(f"common_info.csv 不存在: {info_path}")
    if not node_path.exists():
        raise FileNotFoundError(f"node_properties_mapped.csv 不存在: {node_path}")

    scale_df = pd.read_csv(scale_path)
    info_df = pd.read_csv(info_path)
    node_df = pd.read_csv(node_path)

    # 2) 构造 label（若尚未存在）
    if "label" not in scale_df.columns:
        cias_cols = [c for c in scale_df.columns if c.startswith("cias-r_question")]
        if not cias_cols:
            raise RuntimeError("在 cleaned_scale_info.csv 中未找到 CIAS-R 条目（cias-r_question...），无法构造 label。")
        cias_total = scale_df[cias_cols].apply(pd.to_numeric, errors="coerce").sum(axis=1)
        scale_df["label"] = (cias_total > 46).astype(int)

    # 3) 节点强度向量（full-sample GGM）
    if "index" not in node_df.columns or "strength" not in node_df.columns:
        raise RuntimeError("node_properties_mapped.csv 需包含 'index' 与 'strength' 列。")
    node_strength = node_df.set_index("index")["strength"]

    # 4) 与条目列对齐
    item_cols = [c for c in scale_df.columns if c in node_strength.index]
    if not item_cols:
        raise RuntimeError("cleaned_scale_info.csv 与 node_properties_mapped.csv 间未找到任何匹配条目列。")

    print(f"[IndStrength] 匹配到的条目列数量：{len(item_cols)}")
    print(f"[IndStrength] 未匹配的节点数量：{len(node_strength) - len(item_cols)}")

    item_scores = scale_df[item_cols].apply(pd.to_numeric, errors="coerce")

    # 5) nonparanormal 变换（按列 rank→正态）
    def _npn(col: pd.Series) -> pd.Series:
        valid = col.notna()
        result = col.astype(float).copy()
        n_valid = int(valid.sum())
        if n_valid < 3:
            return result
        ranks = rankdata(col[valid], method="average")
        result[valid] = norm.ppf(ranks / (n_valid + 1.0))
        return result

    item_np = item_scores.apply(_npn)

    # 6) 计算 IndStrength
    weights = node_strength.reindex(item_cols).to_numpy()
    if np.any(pd.isna(weights)):
        raise RuntimeError("node_properties_mapped.csv 中存在与条目列对应但 strength 为 NaN 的节点。")

    P = float(len(item_cols))
    ind_strength = item_np.to_numpy() @ weights / P

    # 7) 组装分析数据（cust_id, label, ind_strength, age, grade, sex）
    result_df = pd.DataFrame({
        "cust_id": pd.to_numeric(scale_df.get("cust_id"), errors="coerce"),
        "label":   scale_df["label"],
        "ind_strength": ind_strength,
    })

    info_df = info_df.copy()
    info_df["cust_id"] = pd.to_numeric(info_df.get("cust_id"), errors="coerce")
    demo_cols = [c for c in ["cust_id", "age", "grade", "sex"] if c in info_df.columns]
    demo_df = info_df[demo_cols]

    result_df = result_df.merge(demo_df, on="cust_id", how="left")

    print("[IndStrength] 基本检查：")
    print(f"  行数：{len(result_df)}")
    print(f"  ind_strength 唯一值数量：{result_df['ind_strength'].nunique()}")
    print(result_df["ind_strength"].describe())
    print(result_df["label"].value_counts(dropna=False))

    out_path = plan_root / "results/experiments/statistical_tests/individual_strength_recomputed.csv"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    result_df.to_csv(out_path, index=False)
    print(f"[IndStrength] 已保存至：{out_path}")
    return out_path


# ----------------------------
# 统计工具：信度、SMD、winsorize
# ----------------------------

def cronbach_alpha(df_items: pd.DataFrame) -> float:
    """
    Cronbach's alpha（对 item 进行行缺失删去）。
    返回 np.nan 表示无法计算。
    """
    x = df_items.apply(pd.to_numeric, errors="coerce")
    x = x.dropna(axis=0, how="any")
    k = x.shape[1]
    if k < 2 or x.shape[0] < 5:
        return float("nan")
    item_vars = x.var(axis=0, ddof=1)
    total = x.sum(axis=1)
    total_var = total.var(ddof=1)
    if total_var <= 0 or np.isnan(total_var):
        return float("nan")
    alpha = (k / (k - 1.0)) * (1.0 - (item_vars.sum() / total_var))
    return float(alpha)


def mcdonald_omega_total_approx(df_items: pd.DataFrame) -> float:
    """
    McDonald's omega（总量表）的一种“近似”实现：单因子因子分析估计载荷。
    - 仅用于探索性质量检查；若失败返回 NaN。
    """
    try:
        from sklearn.decomposition import FactorAnalysis  # type: ignore
    except Exception:
        return float("nan")

    x = df_items.apply(pd.to_numeric, errors="coerce").dropna(axis=0, how="any")
    if x.shape[1] < 2 or x.shape[0] < 20:
        return float("nan")
    try:
        fa = FactorAnalysis(n_components=1, random_state=0)
        fa.fit(x.values)
        loadings = fa.components_.T[:, 0]
        # 估计独特方差（uniqueness）
        psi = getattr(fa, "noise_variance_", None)
        if psi is None:
            return float("nan")
        # omega_total = (sum λ)^2 / ((sum λ)^2 + sum ψ)
        num = float(np.sum(loadings) ** 2)
        den = num + float(np.sum(psi))
        if den <= 0:
            return float("nan")
        return float(num / den)
    except Exception:
        return float("nan")


def winsorize_series(s: pd.Series, p: float = 0.01) -> pd.Series:
    s_num = pd.to_numeric(s, errors="coerce")
    lo = s_num.quantile(p)
    hi = s_num.quantile(1 - p)
    return s_num.clip(lower=lo, upper=hi)


def smd_numeric(x0: pd.Series, x1: pd.Series) -> float:
    x0 = pd.to_numeric(x0, errors="coerce").dropna()
    x1 = pd.to_numeric(x1, errors="coerce").dropna()
    if len(x0) < 2 or len(x1) < 2:
        return float("nan")
    m0, m1 = float(x0.mean()), float(x1.mean())
    v0, v1 = float(x0.var(ddof=1)), float(x1.var(ddof=1))
    pooled = math.sqrt((v0 + v1) / 2.0) if (v0 + v1) > 0 else float("nan")
    if pooled == 0 or np.isnan(pooled):
        return float("nan")
    return (m1 - m0) / pooled


def smd_binary(p0: float, p1: float) -> float:
    # 对二元指示变量的 SMD： (p1-p0)/sqrt((p0(1-p0)+p1(1-p1))/2)
    denom = math.sqrt((p0 * (1 - p0) + p1 * (1 - p1)) / 2.0)
    if denom == 0:
        return float("nan")
    return (p1 - p0) / denom


def compute_smd_table(df: pd.DataFrame, treatment_col: str, covariates: List[str]) -> pd.DataFrame:
    """
    输出每个协变量（numeric / categorical）的 SMD（组1-组0）。
    约定 treatment_col 为 0/1（二分类），其他值会尝试转为 0/1。
    """
    out_rows = []
    if treatment_col not in df.columns:
        raise ValueError(f"treatment_col `{treatment_col}` 不在数据列中。")
    t = pd.to_numeric(df[treatment_col], errors="coerce")
    if t.dropna().nunique() != 2:
        raise ValueError(f"treatment_col `{treatment_col}` 不是二分类（当前 unique={t.dropna().unique()[:10]}）。")
    # 强制映射到 {0,1}
    vals = sorted(t.dropna().unique().tolist())
    mapping = {vals[0]: 0, vals[1]: 1}
    t01 = t.map(mapping)
    df = df.copy()
    df["_t01"] = t01

    for col in covariates:
        if col not in df.columns:
            out_rows.append({"variable": col, "type": "missing", "level": "", "smd": np.nan})
            continue
        s = df[col]
        # numeric
        if pd.api.types.is_numeric_dtype(s) or str(s.dtype).startswith(("float", "int")):
            x0 = df.loc[df["_t01"] == 0, col]
            x1 = df.loc[df["_t01"] == 1, col]
            out_rows.append({"variable": col, "type": "numeric", "level": "", "smd": smd_numeric(x0, x1)})
        else:
            # categorical：对每个 level 生成 0/1 indicator 的 SMD
            s_cat = s.astype("category")
            levels = [lv for lv in s_cat.cat.categories.tolist() if pd.notna(lv)]
            for lv in levels:
                ind = (s_cat == lv).astype(float)
                p0 = float(ind[df["_t01"] == 0].mean()) if (df["_t01"] == 0).any() else float("nan")
                p1 = float(ind[df["_t01"] == 1].mean()) if (df["_t01"] == 1).any() else float("nan")
                out_rows.append({"variable": col, "type": "categorical", "level": str(lv), "smd": smd_binary(p0, p1)})

    smd_df = pd.DataFrame(out_rows)
    smd_df["abs_smd"] = smd_df["smd"].abs()
    return smd_df.sort_values(["abs_smd", "variable"], ascending=[False, True]).reset_index(drop=True)


# ----------------------------
# 数据加载：项目默认逻辑（CIAS-R>46 生成 label）
# ----------------------------

def build_label_from_cias(scale_df: pd.DataFrame, threshold: float = 46) -> pd.Series:
    cias_cols = [c for c in scale_df.columns if c.startswith("cias-r_")]
    if len(cias_cols) == 0:
        raise ValueError("未找到 `cias-r_` 开头的列，无法按 CIAS-R 总分构造 label。")
    total = scale_df[cias_cols].apply(pd.to_numeric, errors="coerce").sum(axis=1)
    return (total > threshold).astype(int)


def load_default_data(plan_root: Path) -> Tuple[pd.DataFrame, pd.DataFrame]:
    data_path = plan_root / "data" / "preprocessed" / "cleaned_scale_info.csv"
    info_path = plan_root / "data" / "preprocessed" / "common_info.csv"
    scale_df = pd.read_csv(data_path)
    info_df = pd.read_csv(info_path)
    return scale_df, info_df


def merge_scale_info(scale_df: pd.DataFrame, info_df: pd.DataFrame) -> pd.DataFrame:
    if "cust_id" not in scale_df.columns or "cust_id" not in info_df.columns:
        raise ValueError("scale_df 或 info_df 缺少 `cust_id` 列，无法合并。")
    # 补 label（与 2.statistical_test.ipynb 逻辑一致）
    if "label" not in scale_df.columns:
        scale_df = scale_df.copy()
        scale_df["label"] = build_label_from_cias(scale_df, threshold=46)
    scale_df = scale_df.copy()
    info_df = info_df.copy()
    scale_df["cust_id"] = pd.to_numeric(scale_df["cust_id"], errors="coerce")
    info_df["cust_id"] = pd.to_numeric(info_df["cust_id"], errors="coerce")
    if "label" in info_df.columns:
        info_df = info_df.drop(columns=["label"])
    merged = info_df.merge(scale_df, on="cust_id", how="inner", suffixes=("_info", ""))
    return merged


def try_load_analysis_data(plan_root: Path, analysis_data_arg: Optional[str]) -> Tuple[pd.DataFrame, str]:
    """
    优先读取用户指定 --analysis-data；
    否则尝试读取项目已有网络指标文件（优先全局指标，其次个体指标）；
    再否则回退到 scale+info 合并。
    """
    if analysis_data_arg:
        p = Path(analysis_data_arg)
        if not p.is_absolute():
            p = (plan_root / p).resolve()
        if not p.exists():
            raise FileNotFoundError(f"--analysis-data 不存在：{p}")
        return pd.read_csv(p), str(p)

    # 优先检查全局网络指标（包含 global_strength, density 等）
    candidate_global = plan_root / "results" / "experiments" / "statistical_tests" / "network_global_metrics_comparison.csv"
    if candidate_global.exists():
        return pd.read_csv(candidate_global), str(candidate_global)
    
    # 其次检查个体网络指标
    candidate_individual = plan_root / "results" / "experiments" / "statistical_tests" / "individual_network_metrics_comparison.csv"
    if candidate_individual.exists():
        return pd.read_csv(candidate_individual), str(candidate_individual)

    scale_df, info_df = load_default_data(plan_root)
    merged = merge_scale_info(scale_df, info_df)
    return merged, "merged(scale+info)"


# ----------------------------
# 建模：连续/二元/计数；纵向：MixedLM/GEE
# ----------------------------

def _build_design_matrix(
    df: pd.DataFrame,
    y_col: str,
    t_col: str,
    covariates: List[str],
    add_interactions: Optional[List[Tuple[str, str]]] = None,
) -> Tuple[pd.Series, pd.DataFrame]:
    """
    统一构造（y, X），对分类变量自动做 one-hot（drop_first=True）。
    interactions：例如 [(t_col, "age")] 表示加入 t*age。
    """
    if y_col not in df.columns:
        raise ValueError(f"outcome `{y_col}` 不在数据列中。")
    if t_col not in df.columns:
        raise ValueError(f"treatment `{t_col}` 不在数据列中。")

    use_cols = [t_col] + [c for c in covariates if c in df.columns]
    x_raw = df[use_cols].copy()
    # treatment 强制 numeric
    x_raw[t_col] = pd.to_numeric(x_raw[t_col], errors="coerce")

    # dummies（对 object/category）
    cat_cols = [c for c in x_raw.columns if c != t_col and (x_raw[c].dtype == "object" or str(x_raw[c].dtype) == "category")]
    x_num = x_raw.drop(columns=cat_cols, errors="ignore")
    x_cat = pd.get_dummies(x_raw[cat_cols], drop_first=True, dummy_na=False) if len(cat_cols) else None
    X = pd.concat([x_num, x_cat], axis=1) if x_cat is not None else x_num

    # interactions
    if add_interactions:
        for a, b in add_interactions:
            if a in X.columns and b in X.columns:
                X[f"{a}:{b}"] = X[a] * X[b]

    y = pd.to_numeric(df[y_col], errors="coerce")
    
    # 确保 X 中所有列都是数值型
    for col in X.columns:
        if X[col].dtype == "object" or not pd.api.types.is_numeric_dtype(X[col]):
            X[col] = pd.to_numeric(X[col], errors="coerce")
    
    # 删除缺失行
    keep = ~(y.isna() | X.isna().any(axis=1))
    y2 = y.loc[keep]
    X2 = X.loc[keep].copy()
    
    # 确保所有列都是 float64 类型
    for col in X2.columns:
        if not pd.api.types.is_numeric_dtype(X2[col]):
            X2[col] = pd.to_numeric(X2[col], errors="coerce")
        X2[col] = X2[col].astype(float)
    
    X2 = sm.add_constant(X2, has_constant="add")
    return y2, X2


@dataclass
class ModelResult:
    outcome: str
    outcome_type: str
    n: int
    treatment: str
    effect_term: str
    effect: float
    se: float
    ci95_lo: float
    ci95_hi: float
    p_value: float
    model: str


def fit_main_model(
    df: pd.DataFrame,
    outcome: str,
    treatment: str,
    covariates: List[str],
    outcome_type: str,
    robust_se: bool = True,
    winsorize_p: Optional[float] = None,
) -> Tuple[ModelResult, sm.base.model.Results]:
    df_use = df.copy()
    if winsorize_p is not None:
        df_use[outcome] = winsorize_series(df_use[outcome], p=winsorize_p)

    y, X = _build_design_matrix(df_use, outcome, treatment, covariates)
    
    # 确保 y 和 X 都是数值型（float64）
    y_clean = y.astype(float)
    X_clean = X.astype(float)

    if outcome_type == "continuous":
        model = sm.OLS(y_clean, X_clean)
        res = model.fit(cov_type="HC3" if robust_se else "nonrobust")
    elif outcome_type == "binary":
        model = sm.Logit(y_clean, X_clean)
        res = model.fit(disp=False)
        if robust_se:
            res = res.get_robustcov_results(cov_type="HC3")
    elif outcome_type == "count":
        model = sm.GLM(y_clean, X_clean, family=sm.families.NegativeBinomial())
        res = model.fit()
        if robust_se:
            res = res.get_robustcov_results(cov_type="HC3")
    else:
        raise ValueError("outcome_type 必须是 continuous/binary/count")

    term = treatment if treatment in res.params.index else treatment
    if term not in res.params.index:
        raise RuntimeError(f"模型中未找到 treatment 系数 `{treatment}`（可用项：{list(res.params.index)[:20]}...）。")

    eff = float(res.params[term])
    se = float(res.bse[term])
    z = 1.96
    ci_lo, ci_hi = eff - z * se, eff + z * se
    p = float(res.pvalues[term])

    mr = ModelResult(
        outcome=outcome,
        outcome_type=outcome_type,
        n=int(res.nobs),
        treatment=treatment,
        effect_term=term,
        effect=eff,
        se=se,
        ci95_lo=ci_lo,
        ci95_hi=ci_hi,
        p_value=p,
        model=res.model.__class__.__name__,
    )
    return mr, res


def compute_vif(df: pd.DataFrame, X: pd.DataFrame, treatment: str, covariates: List[str]) -> pd.DataFrame:
    """
    计算方差膨胀因子（VIF），用于检查多重共线性。
    仅对连续结局的线性模型有意义。
    """
    vif_cols = [c for c in [treatment] + covariates if c in X.columns]
    if len(vif_cols) == 0:
        return pd.DataFrame(columns=["variable", "VIF"])
    
    # 只保留数值型列
    numeric_cols = [c for c in vif_cols if pd.api.types.is_numeric_dtype(X[c])]
    if len(numeric_cols) == 0:
        return pd.DataFrame(columns=["variable", "VIF"])
    
    X_vif = X[numeric_cols].copy()
    X_vif = X_vif.dropna()
    
    if len(X_vif) < len(numeric_cols) + 1:
        return pd.DataFrame(columns=["variable", "VIF"])
    
    # 添加常数项
    X_vif_const = sm.add_constant(X_vif, has_constant="add")
    
    rows = []
    for i, col in enumerate(X_vif_const.columns):
        if col == "const":
            continue
        try:
            vif_val = variance_inflation_factor(X_vif_const.values, i)
            rows.append({"variable": col, "VIF": float(vif_val) if np.isfinite(vif_val) else np.nan})
        except Exception:
            rows.append({"variable": col, "VIF": np.nan})
    
    return pd.DataFrame(rows)


def continuous_model_diagnostics(
    res: sm.base.model.Results,
    y: pd.Series,
    X: pd.DataFrame,
    df: pd.DataFrame,
    treatment: str,
    covariates: List[str],
) -> Dict[str, Any]:
    """
    对连续结局模型进行诊断：
    - 残差正态性（Shapiro-Wilk）
    - 异方差性（Breusch-Pagan）
    - 影响点（Cook's distance）
    - 多重共线性（VIF）
    """
    diag = {}
    
    # 残差统计
    resid = pd.Series(res.resid)
    diag["residual_mean"] = float(np.mean(resid))
    diag["residual_sd"] = float(np.std(resid, ddof=1))
    
    # Shapiro-Wilk 正态性检验（样本量大时只抽样）
    if len(resid) >= 3:
        sample_size = min(len(resid), 5000)
        resid_sample = resid.sample(n=sample_size, random_state=42) if len(resid) > sample_size else resid
        try:
            shapiro_stat, shapiro_p = stats.shapiro(resid_sample)
            diag["shapiro_wilk_statistic"] = float(shapiro_stat)
            diag["shapiro_wilk_p"] = float(shapiro_p)
        except Exception:
            diag["shapiro_wilk_statistic"] = np.nan
            diag["shapiro_wilk_p"] = np.nan
    else:
        diag["shapiro_wilk_statistic"] = np.nan
        diag["shapiro_wilk_p"] = np.nan
    
    # Breusch-Pagan 异方差检验（仅对 OLS）
    if hasattr(res.model, "exog") and hasattr(res, "resid"):
        try:
            bp_stat, bp_p, _, _ = het_breuschpagan(res.resid, res.model.exog)
            diag["breusch_pagan_statistic"] = float(bp_stat)
            diag["breusch_pagan_p"] = float(bp_p)
        except Exception:
            diag["breusch_pagan_statistic"] = np.nan
            diag["breusch_pagan_p"] = np.nan
    else:
        diag["breusch_pagan_statistic"] = np.nan
        diag["breusch_pagan_p"] = np.nan
    
    # Cook's distance（影响点检测）
    if hasattr(res, "get_influence"):
        try:
            infl = res.get_influence()
            cooks = infl.cooks_distance[0]
            diag["max_cooks_distance"] = float(np.max(cooks))
            diag["mean_cooks_distance"] = float(np.mean(cooks))
            # 识别高影响点（Cook's D > 4/n）
            threshold = 4.0 / len(cooks) if len(cooks) > 0 else np.inf
            diag["n_high_influence"] = int(np.sum(cooks > threshold))
        except Exception:
            diag["max_cooks_distance"] = np.nan
            diag["mean_cooks_distance"] = np.nan
            diag["n_high_influence"] = 0
    else:
        diag["max_cooks_distance"] = np.nan
        diag["mean_cooks_distance"] = np.nan
        diag["n_high_influence"] = 0
    
    # VIF（多重共线性）
    vif_df = compute_vif(df, X, treatment, covariates)
    diag["vif_table"] = vif_df
    
    return diag


def bootstrap_effect(
    df: pd.DataFrame,
    outcome: str,
    treatment: str,
    covariates: List[str],
    outcome_type: str,
    n_boot: int,
    seed: int,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    effects = []
    n = len(df)
    for b in range(n_boot):
        idx = rng.integers(0, n, size=n)
        dfi = df.iloc[idx].reset_index(drop=True)
        try:
            mr, _ = fit_main_model(
                dfi, outcome=outcome, treatment=treatment, covariates=covariates,
                outcome_type=outcome_type, robust_se=True
            )
            effects.append({"boot": b, "effect": mr.effect})
        except Exception:
            effects.append({"boot": b, "effect": np.nan})
    eff_df = pd.DataFrame(effects)
    return eff_df


def permutation_test_effect(
    df: pd.DataFrame,
    outcome: str,
    treatment: str,
    covariates: List[str],
    outcome_type: str,
    n_perm: int,
    seed: int,
) -> Dict[str, float]:
    # 观测效应
    mr_obs, _ = fit_main_model(
        df, outcome=outcome, treatment=treatment, covariates=covariates, outcome_type=outcome_type, robust_se=True
    )
    obs = mr_obs.effect

    rng = np.random.default_rng(seed)
    perm_effs = []
    for i in range(n_perm):
        dfi = df.copy()
        dfi[treatment] = rng.permutation(dfi[treatment].values)
        try:
            mr_i, _ = fit_main_model(
                dfi, outcome=outcome, treatment=treatment, covariates=covariates, outcome_type=outcome_type, robust_se=True
            )
            perm_effs.append(mr_i.effect)
        except Exception:
            perm_effs.append(np.nan)

    perm = np.array([x for x in perm_effs if np.isfinite(x)])
    # 双侧
    p = (1.0 + float(np.sum(np.abs(perm) >= abs(obs)))) / (len(perm) + 1.0) if len(perm) else float("nan")
    return {
        "observed_effect": float(obs),
        "n_perm": int(n_perm),
        "n_used": int(len(perm)),
        "perm_p_value_two_sided": float(p),
        "perm_mean": float(np.nanmean(perm)) if len(perm) else float("nan"),
        "perm_sd": float(np.nanstd(perm, ddof=1)) if len(perm) > 1 else float("nan"),
    }


def heterogeneity_by_interactions(
    df: pd.DataFrame,
    outcome: str,
    treatment: str,
    covariates: List[str],
    subgroup_vars: List[str],
    outcome_type: str,
) -> pd.DataFrame:
    rows = []
    for sg in subgroup_vars:
        if sg not in df.columns:
            rows.append({"subgroup": sg, "status": "missing", "term": "", "effect": np.nan, "se": np.nan, "p": np.nan})
            continue
        # 为了让交互项可进 X：对分类变量先 dummies，然后只与 treatment 交互数值列
        try:
            y, X = _build_design_matrix(df, outcome, treatment, covariates + [sg])
            # 找到 sg 对应的列（可能变成 sg_xxx dummies）
            sg_cols = [c for c in X.columns if c == sg or c.startswith(f"{sg}_")]
            for c in sg_cols:
                if treatment in X.columns and c in X.columns:
                    # 确保都是数值型再相乘
                    X[f"{treatment}:{c}"] = X[treatment].astype(float) * X[c].astype(float)
        except Exception as e:
            rows.append({"subgroup": sg, "status": f"build_matrix_failed: {e}", "term": "", "effect": np.nan, "se": np.nan, "p": np.nan})
            continue

        try:
            # 确保 X 和 y 都是数值型
            X_clean = X.astype(float)
            y_clean = y.astype(float)
            
            if outcome_type == "continuous":
                res = sm.OLS(y_clean, X_clean).fit(cov_type="HC3")
            elif outcome_type == "binary":
                res = sm.Logit(y_clean, X_clean).fit(disp=False).get_robustcov_results(cov_type="HC3")
            elif outcome_type == "count":
                res = sm.GLM(y_clean, X_clean, family=sm.families.NegativeBinomial()).fit().get_robustcov_results(cov_type="HC3")
            else:
                raise ValueError
        except Exception as e:
            rows.append({"subgroup": sg, "status": f"fit_failed: {e}", "term": "", "effect": np.nan, "se": np.nan, "p": np.nan})
            continue

        # 输出所有交互项
        inter_terms = [c for c in res.params.index if c.startswith(f"{treatment}:")]
        if not inter_terms:
            rows.append({"subgroup": sg, "status": "no_interaction_term", "term": "", "effect": np.nan, "se": np.nan, "p": np.nan})
            continue
        for term in inter_terms:
            rows.append({
                "subgroup": sg,
                "status": "ok",
                "term": term,
                "effect": float(res.params[term]),
                "se": float(res.bse[term]),
                "p": float(res.pvalues[term]),
            })
    return pd.DataFrame(rows)


def monte_carlo_power_sim(
    df: pd.DataFrame,
    outcome: str,
    treatment: str,
    covariates: List[str],
    outcome_type: str,
    n_sims: int,
    n_multipliers: List[float],
    alpha: float,
    seed: int,
) -> pd.DataFrame:
    """
    基于当前协变量分布与拟合模型，做“反向设计”功效模拟：
    - 从 df 里 bootstrap 协变量结构；
    - 以拟合模型参数生成 y；
    - 重新拟合并记录 p<alpha 的比例（power）。
    """
    rng = np.random.default_rng(seed)
    # 拟合一次得到参数
    mr, res = fit_main_model(df, outcome, treatment, covariates, outcome_type, robust_se=True)

    # 设计矩阵
    y_obs, X_obs = _build_design_matrix(df, outcome, treatment, covariates)
    beta = res.params.reindex(X_obs.columns).fillna(0.0).values

    # 噪声水平
    if outcome_type == "continuous":
        sigma = float(np.sqrt(res.mse_resid)) if hasattr(res, "mse_resid") else float(np.std(res.resid, ddof=1))
        if not np.isfinite(sigma) or sigma <= 0:
            sigma = float(np.std(y_obs - res.fittedvalues, ddof=1))
    else:
        sigma = float("nan")

    rows = []
    base_n = X_obs.shape[0]
    for mult in n_multipliers:
        n = int(round(base_n * mult))
        if n < 20:
            rows.append({"n_multiplier": mult, "n": n, "power": np.nan, "status": "n_too_small"})
            continue
        sig = 0
        used = 0
        for s in range(n_sims):
            idx = rng.integers(0, base_n, size=n)
            X = X_obs.iloc[idx].reset_index(drop=True).astype(float)
            linpred = X.values @ beta
            if outcome_type == "continuous":
                y = linpred + rng.normal(0.0, sigma, size=n)
                try:
                    res_i = sm.OLS(y, X).fit(cov_type="HC3")
                    p = float(res_i.pvalues.get(treatment, np.nan))
                except Exception:
                    p = np.nan
            elif outcome_type == "binary":
                p_i = 1.0 / (1.0 + np.exp(-linpred))
                y = rng.binomial(1, p_i, size=n)
                try:
                    res_i = sm.Logit(y, X).fit(disp=False).get_robustcov_results(cov_type="HC3")
                    p = float(res_i.pvalues.get(treatment, np.nan))
                except Exception:
                    p = np.nan
            elif outcome_type == "count":
                mu = np.exp(linpred)
                y = rng.poisson(mu, size=n)
                try:
                    res_i = sm.GLM(y, X, family=sm.families.Poisson()).fit().get_robustcov_results(cov_type="HC3")
                    p = float(res_i.pvalues.get(treatment, np.nan))
                except Exception:
                    p = np.nan
            else:
                p = np.nan

            if np.isfinite(p):
                used += 1
                if p < alpha:
                    sig += 1

        power = sig / used if used else np.nan
        rows.append({"n_multiplier": mult, "n": n, "power": power, "status": "ok", "n_used": used})

    return pd.DataFrame(rows)


# ----------------------------
# 图形输出
# ----------------------------

def _save_fig(fig: plt.Figure, out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_missingness(df: pd.DataFrame, out_png: Path, topk: int = 40) -> pd.DataFrame:
    miss = df.isna().mean().sort_values(ascending=False)
    miss_df = miss.reset_index()
    miss_df.columns = ["variable", "missing_rate"]
    top = miss_df.head(topk)

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.barh(top["variable"][::-1], top["missing_rate"][::-1], color="#808080")
    ax.set_xlabel("Missing rate")
    ax.set_title("Top missing variables")
    _save_fig(fig, out_png)
    return miss_df


def plot_smd(smd_df: pd.DataFrame, out_png: Path, threshold: float = 0.1, topk: int = 60) -> None:
    d = smd_df.copy()
    d["name"] = np.where(d["level"].astype(str).str.len() > 0, d["variable"] + "=" + d["level"], d["variable"])
    d = d.sort_values("abs_smd", ascending=True).tail(topk)
    fig, ax = plt.subplots(figsize=(10, max(4, int(len(d) * 0.18))))
    ax.axvline(threshold, color="red", lw=1, ls="--")
    ax.axvline(-threshold, color="red", lw=1, ls="--")
    ax.barh(d["name"], d["smd"], color=np.where(d["smd"] >= 0, "#4C72B0", "#DD8452"))
    ax.set_xlabel("Standardized Mean Difference (SMD)")
    ax.set_title("Baseline balance (SMD)")
    _save_fig(fig, out_png)


def plot_bootstrap(eff_df: pd.DataFrame, out_png: Path) -> None:
    x = eff_df["effect"].dropna().values
    fig, ax = plt.subplots(figsize=(8, 5))
    if len(x):
        ax.hist(x, bins=30, color="#4C72B0", alpha=0.85)
        ax.axvline(np.nanmedian(x), color="black", lw=1)
        ax.set_title("Bootstrap effect distribution")
        ax.set_xlabel("Effect")
        ax.set_ylabel("Count")
    else:
        ax.text(0.5, 0.5, "No bootstrap samples available", ha="center", va="center")
    _save_fig(fig, out_png)


def plot_power_curve(power_df: pd.DataFrame, out_png: Path) -> None:
    d = power_df[power_df["status"] == "ok"].copy()
    fig, ax = plt.subplots(figsize=(7, 5))
    if len(d):
        ax.plot(d["n"], d["power"], marker="o", color="#2C3E50")
        ax.set_ylim(0, 1)
        ax.set_xlabel("Sample size (n)")
        ax.set_ylabel("Power")
        ax.set_title("Monte Carlo power curve")
    else:
        ax.text(0.5, 0.5, "No power results", ha="center", va="center")
    _save_fig(fig, out_png)


def plot_residuals_vs_fitted(res: sm.base.model.Results, out_png: Path) -> None:
    """
    绘制残差 vs 拟合值图（仅连续结局）。
    """
    if not hasattr(res, "fittedvalues") or not hasattr(res, "resid"):
        return
    
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(res.fittedvalues, res.resid, alpha=0.6, color="#4C72B0")
    ax.axhline(0, linestyle="--", color="black", linewidth=1)
    ax.set_xlabel("Fitted values")
    ax.set_ylabel("Residuals")
    ax.set_title("Residuals vs fitted values")
    _save_fig(fig, out_png)


def plot_qq_residuals(res: sm.base.model.Results, out_png: Path) -> None:
    """
    绘制残差 Q-Q 图（仅连续结局）。
    """
    if not hasattr(res, "resid"):
        return
    
    resid = pd.Series(res.resid).dropna()
    if len(resid) < 3:
        return
    
    fig, ax = plt.subplots(figsize=(7, 5))
    stats.probplot(resid, dist="norm", plot=ax)
    ax.set_title("Q-Q plot of residuals")
    _save_fig(fig, out_png)


# ----------------------------
# 主流程：产出 md 报告
# ----------------------------

def infer_scale_item_sets(df: pd.DataFrame) -> Dict[str, List[str]]:
    """
    根据列名前缀自动识别常见量表 item 集合（可按需扩展）。
    """
    patterns = {
        "CIAS-R": "cias-r_",
        "DASS": "dass_",
        "ISI": "isi_",
        "SDQ": "sdq_",
        "DIET": "diet_",
        "ACTIVITY": "activity_",
    }
    out = {}
    for name, prefix in patterns.items():
        cols = [c for c in df.columns if c.startswith(prefix)]
        if cols:
            out[name] = cols
    return out


def write_report_md(
    out_md: Path,
    meta: Dict,
    audit: Dict[str, Path],
    key_tables: Dict[str, Path],
    key_figs: Dict[str, Path],
    notes: List[str],
) -> None:
    lines = []
    lines.append(f"# 实验完善分析报告\n")
    lines.append(f"- 运行时间：{meta.get('run_time')}\n")
    lines.append(f"- 输入数据：{meta.get('data_source')}\n")
    lines.append(f"- treatment：`{meta.get('treatment')}`；outcome：`{meta.get('outcome')}`（type={meta.get('outcome_type')}）\n")
    lines.append("\n---\n")

    lines.append("## 1. 这次分析要回答什么（而不只是“显著不显著”）\n")
    lines.append("- **效应是否存在且方向稳定**：用主模型估计 + bootstrap + permutation 检查方向一致性。\n")
    lines.append("- **不确定性来自哪里**：用置信区间宽度、缺失结构、信度、基线不平衡提示瓶颈。\n")
    lines.append("- **是否存在异质性**：用有限、可解释的交互项（预定义 subgroups）识别分层/富集线索。\n")
    lines.append("- **下一轮实验怎么改**：用 Monte Carlo 在当前噪声与协变量结构下做样本量—功效曲线。\n")

    lines.append("\n## 2. 数据审计（质量、缺失、异常结构）\n")
    if "missingness_csv" in audit:
        lines.append(f"- 缺失率表：`{audit['missingness_csv'].as_posix()}`\n")
    if "missingness_fig" in key_figs:
        lines.append(f"- 缺失率图：`{key_figs['missingness_fig'].as_posix()}`\n")

    lines.append("\n## 3. 测量质量（内部一致性）\n")
    if "reliability_csv" in key_tables:
        lines.append(f"- 信度表：`{key_tables['reliability_csv'].as_posix()}`\n")

    lines.append("\n## 4. 基线平衡（SMD）\n")
    if "smd_csv" in key_tables:
        lines.append(f"- SMD 表：`{key_tables['smd_csv'].as_posix()}`\n")
    if "smd_fig" in key_figs:
        lines.append(f"- SMD 图：`{key_figs['smd_fig'].as_posix()}`\n")
    lines.append("- 经验阈值：**|SMD| > 0.1** 提示需要更严格的分层/阻断随机化或基线协变量调整。\n")

    lines.append("\n## 5. 主模型估计（效应大小 + 不确定性）\n")
    if "main_model_csv" in key_tables:
        lines.append(f"- 主模型结果：`{key_tables['main_model_csv'].as_posix()}`\n")
    else:
        lines.append("- 未运行：未提供 outcome 或 outcome 列不存在。\n")

    lines.append("\n## 6. 稳健性（bootstrap / permutation / 敏感性）\n")
    if "bootstrap_csv" in key_tables:
        lines.append(f"- Bootstrap 样本：`{key_tables['bootstrap_csv'].as_posix()}`\n")
    if "bootstrap_fig" in key_figs:
        lines.append(f"- Bootstrap 分布图：`{key_figs['bootstrap_fig'].as_posix()}`\n")
    if "permutation_csv" in key_tables:
        lines.append(f"- Permutation 结果：`{key_tables['permutation_csv'].as_posix()}`\n")

    lines.append("\n## 7. 异质性（交互项）\n")
    if "heterogeneity_csv" in key_tables:
        lines.append(f"- 交互项结果：`{key_tables['heterogeneity_csv'].as_posix()}`\n")

    lines.append("\n## 8. 反向设计：Monte Carlo 功效模拟\n")
    if "power_csv" in key_tables:
        lines.append(f"- 功效模拟结果：`{key_tables['power_csv'].as_posix()}`\n")
    if "power_fig" in key_figs:
        lines.append(f"- 功效曲线图：`{key_figs['power_fig'].as_posix()}`\n")

    if notes:
        lines.append("\n## 9. 运行提示与注意事项\n")
        for n in notes:
            lines.append(f"- {n}\n")

    out_md.parent.mkdir(parents=True, exist_ok=True)
    out_md.write_text("".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description="Improve experiment analysis pipeline (audit -> model -> robustness -> power).")
    parser.add_argument("--analysis-data", type=str, default=None, help="用于建模的分析数据 CSV（优先）。不提供则自动尝试读取项目默认文件。")
    parser.add_argument("--treatment", type=str, default="label", help="分组/处理变量（默认 label，需为二分类 0/1）。")
    parser.add_argument(
        "--outcome",
        type=str,
        default=None,
        help="结局变量列名。不提供则跳过主模型/稳健性/功效模拟。"
             " 若使用 network_global_metrics_comparison.csv，推荐主终点为 global_strength，"
             "density 与 global_efficiency 作为关键次终点；"
             "degree_assortativity 与可控性相关指标作为补充/探索性终点。",
    )
    parser.add_argument("--outcome-type", type=str, default="continuous", choices=["continuous", "binary", "count"], help="结局类型。")
    parser.add_argument("--covariates", nargs="*", default=["age", "sex", "grade"], help="处理前协变量列表（默认 age sex grade）。")
    parser.add_argument("--subgroup-vars", nargs="*", default=[], help="异质性分析的预定义 subgroup 变量（交互项）。")
    parser.add_argument("--n-boot", type=int, default=100, help="bootstrap 次数（默认 100，与 5.bootstrap.ipynb 保持一致）。")
    parser.add_argument("--n-perm", type=int, default=100, help="permutation 次数（默认 100，与 5.bootstrap.ipynb 保持一致）。")
    parser.add_argument("--power-sims", type=int, default=500, help="功效模拟次数（默认 500）。")
    parser.add_argument("--power-alpha", type=float, default=0.05, help="功效模拟显著性水平（默认 0.05）。")
    parser.add_argument("--power-multipliers", type=str, default="1.0,1.5,2.0,3.0", help="功效模拟样本量倍数，例如 1.0,1.5,2.0,3.0")
    parser.add_argument("--seed", type=int, default=0, help="随机种子。")
    parser.add_argument("--winsorize", type=float, default=None, help="可选：对 outcome winsorize（例如 0.01）。")
    args = parser.parse_args()

    plan_root = _find_plan_root()
    _ensure_cwd(plan_root)

    run_id = _now_run_id()
    out_dir = plan_root / "results" / "experiments" / "improve_experiment" / run_id
    fig_dir = out_dir / "figures"
    out_dir.mkdir(parents=True, exist_ok=True)
    fig_dir.mkdir(parents=True, exist_ok=True)

    df, source = try_load_analysis_data(plan_root, args.analysis_data)

    # 若分析数据没有 label，但包含 CIAS-R items：补 label
    if args.treatment not in df.columns and any(c.startswith("cias-r_") for c in df.columns):
        df = df.copy()
        df[args.treatment] = build_label_from_cias(df, threshold=46)

    meta = {
        "run_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "data_source": source,
        "treatment": args.treatment,
        "outcome": args.outcome or "",
        "outcome_type": args.outcome_type,
    }

    notes: List[str] = []
    key_tables: Dict[str, Path] = {}
    key_figs: Dict[str, Path] = {}
    audit_paths: Dict[str, Path] = {}

    # 1) 审计：缺失率
    miss_csv = out_dir / "missingness_table.csv"
    miss_fig = fig_dir / "missingness_top.png"
    miss_df = plot_missingness(df, miss_fig, topk=40)
    miss_df.to_csv(miss_csv, index=False)
    audit_paths["missingness_csv"] = miss_csv
    key_figs["missingness_fig"] = miss_fig

    # 2) 信度（仅对 item 列充足时）
    reliability_csv = out_dir / "reliability_scales.csv"
    scale_sets = infer_scale_item_sets(df)
    rel_rows = []
    for scale_name, cols in scale_sets.items():
        items = df[cols]
        rel_rows.append({
            "scale": scale_name,
            "n_items": len(cols),
            "cronbach_alpha": cronbach_alpha(items),
            "omega_total_approx": mcdonald_omega_total_approx(items),
        })
    rel_df = pd.DataFrame(rel_rows)
    rel_df.to_csv(reliability_csv, index=False)
    key_tables["reliability_csv"] = reliability_csv

    # 3) 基线平衡：SMD
    if args.treatment in df.columns:
        smd_csv = out_dir / "baseline_balance_smd.csv"
        try:
            smd_df = compute_smd_table(df, args.treatment, args.covariates)
            smd_df.to_csv(smd_csv, index=False)
            key_tables["smd_csv"] = smd_csv
            smd_fig = fig_dir / "baseline_balance_smd.png"
            plot_smd(smd_df, smd_fig, threshold=0.1, topk=60)
            key_figs["smd_fig"] = smd_fig
        except Exception as e:
            notes.append(f"SMD 计算失败：{e}")
    else:
        notes.append(f"未找到 treatment 列 `{args.treatment}`，跳过 SMD。")

    # 4) 主模型 + 稳健性 + 异质性 + 功效（可选）
    if args.outcome is not None:
        if args.outcome not in df.columns:
            notes.append(f"outcome `{args.outcome}` 不在数据列中，跳过主模型/稳健性/功效模拟。")
        else:
            try:
                mr, res = fit_main_model(
                    df,
                    outcome=args.outcome,
                    treatment=args.treatment,
                    covariates=args.covariates,
                    outcome_type=args.outcome_type,
                    robust_se=True,
                    winsorize_p=args.winsorize,
                )
                main_csv = out_dir / "main_model_result.csv"
                pd.DataFrame([asdict(mr)]).to_csv(main_csv, index=False)
                key_tables["main_model_csv"] = main_csv
                
                # 模型诊断（仅连续结局）
                if args.outcome_type == "continuous":
                    try:
                        y, X = _build_design_matrix(df, args.outcome, args.treatment, args.covariates)
                        diag_dict = continuous_model_diagnostics(
                            res, y, X, df, args.treatment, args.covariates
                        )
                        diag_csv = out_dir / "model_diagnostics.csv"
                        diag_rows = []
                        for k, v in diag_dict.items():
                            if k == "vif_table":
                                continue
                            diag_rows.append({"diagnostic": k, "value": v})
                        if "vif_table" in diag_dict and isinstance(diag_dict["vif_table"], pd.DataFrame):
                            diag_dict["vif_table"].to_csv(out_dir / "vif_table.csv", index=False)
                            key_tables["vif_csv"] = out_dir / "vif_table.csv"
                        pd.DataFrame(diag_rows).to_csv(diag_csv, index=False)
                        key_tables["diagnostics_csv"] = diag_csv
                        
                        # 残差图
                        resid_fig = fig_dir / "residuals_vs_fitted.png"
                        plot_residuals_vs_fitted(res, resid_fig)
                        key_figs["residuals_fig"] = resid_fig
                        
                        qq_fig = fig_dir / "qq_residuals.png"
                        plot_qq_residuals(res, qq_fig)
                        key_figs["qq_fig"] = qq_fig
                    except Exception as e:
                        notes.append(f"模型诊断失败：{e}")
            except Exception as e:
                notes.append(f"主模型拟合失败：{e}")

            # bootstrap
            try:
                boot_df = bootstrap_effect(
                    df,
                    outcome=args.outcome,
                    treatment=args.treatment,
                    covariates=args.covariates,
                    outcome_type=args.outcome_type,
                    n_boot=int(args.n_boot),
                    seed=int(args.seed),
                )
                boot_csv = out_dir / "bootstrap_effects.csv"
                boot_df.to_csv(boot_csv, index=False)
                key_tables["bootstrap_csv"] = boot_csv
                boot_fig = fig_dir / "bootstrap_effects.png"
                plot_bootstrap(boot_df, boot_fig)
                key_figs["bootstrap_fig"] = boot_fig
            except Exception as e:
                notes.append(f"bootstrap 失败：{e}")

            # permutation
            try:
                perm = permutation_test_effect(
                    df,
                    outcome=args.outcome,
                    treatment=args.treatment,
                    covariates=args.covariates,
                    outcome_type=args.outcome_type,
                    n_perm=int(args.n_perm),
                    seed=int(args.seed),
                )
                perm_csv = out_dir / "permutation_test.csv"
                pd.DataFrame([perm]).to_csv(perm_csv, index=False)
                key_tables["permutation_csv"] = perm_csv
            except Exception as e:
                notes.append(f"permutation test 失败：{e}")

            # heterogeneity
            if args.subgroup_vars:
                try:
                    het_df = heterogeneity_by_interactions(
                        df,
                        outcome=args.outcome,
                        treatment=args.treatment,
                        covariates=args.covariates,
                        subgroup_vars=args.subgroup_vars,
                        outcome_type=args.outcome_type,
                    )
                    het_csv = out_dir / "heterogeneity_interactions.csv"
                    het_df.to_csv(het_csv, index=False)
                    key_tables["heterogeneity_csv"] = het_csv
                except Exception as e:
                    notes.append(f"异质性分析失败：{e}")

            # power sim
            try:
                multipliers = [float(x.strip()) for x in str(args.power_multipliers).split(",") if x.strip()]
                power_df = monte_carlo_power_sim(
                    df,
                    outcome=args.outcome,
                    treatment=args.treatment,
                    covariates=args.covariates,
                    outcome_type=args.outcome_type,
                    n_sims=int(args.power_sims),
                    n_multipliers=multipliers,
                    alpha=float(args.power_alpha),
                    seed=int(args.seed),
                )
                power_csv = out_dir / "power_simulation.csv"
                power_df.to_csv(power_csv, index=False)
                key_tables["power_csv"] = power_csv
                power_fig = fig_dir / "power_curve.png"
                plot_power_curve(power_df, power_fig)
                key_figs["power_fig"] = power_fig
            except Exception as e:
                notes.append(f"功效模拟失败：{e}")
    else:
        notes.append("未提供 --outcome：已完成审计/信度/平衡/描述性输出。若要跑主模型与稳健性，请指定 --outcome。")

    # 写报告
    report_md = out_dir / "analysis_report.md"
    write_report_md(
        report_md,
        meta=meta,
        audit=audit_paths,
        key_tables=key_tables,
        key_figs=key_figs,
        notes=notes,
    )

    print(f"[OK] 输出目录：{out_dir}")
    print(f"[OK] 报告：{report_md}")
    if notes:
        print("[WARN] 运行提示：")
        for n in notes:
            print(f"  - {n}")


if __name__ == "__main__":
    main()
