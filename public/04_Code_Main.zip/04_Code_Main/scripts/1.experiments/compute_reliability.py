"""
compute_reliability.py
======================
从 cleaned_scale_info.csv 计算各量表的 Cronbach's alpha。

输出：reliability_scales.csv
列：scale, n_items, n_valid, alpha, interpretation

用法：
    python compute_reliability.py \
        --scale data/preprocessed/cleaned_scale_info.csv \
        --out results/experiments/improve_experiment/20260311_215205/reliability_scales.csv
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd


# ── 量表定义 ────────────────────────────────────────────────────────────────
# 前缀 → 显示名称
SCALE_PREFIXES = {
    "cias-r_question":   "CIAS-R",
    "dass_question":     "DASS-21",
    "isi_question":      "ISI",
    "diet_question":     "DIET",
    "sdq_question":      "SDQ",
    "activity_question": "ACT",
}


def cronbach_alpha(df: pd.DataFrame) -> float:
    """
    计算 Cronbach's alpha。
    公式：α = (k / (k-1)) * (1 - sum(var_i) / var_total)
    输入 df：行=被试，列=条目（已转为数值，缺失值会被 pairwise 排除）。
    """
    df = df.apply(pd.to_numeric, errors="coerce")
    # 删除全缺失行
    df = df.dropna(how="all")
    # 至少需要2个条目、10个被试
    k = df.shape[1]
    if k < 2:
        return np.nan
    # 用 pairwise complete 计算协方差矩阵
    cov_matrix = df.cov()
    if cov_matrix.isnull().all().all():
        return np.nan
    # 各条目方差之和
    item_var_sum = np.diag(cov_matrix.values).sum()
    # 总分方差（= 协方差矩阵所有元素之和）
    total_var = cov_matrix.values.sum()
    if total_var == 0:
        return np.nan
    alpha = (k / (k - 1)) * (1 - item_var_sum / total_var)
    return float(alpha)


def interpret_alpha(alpha: float) -> str:
    if np.isnan(alpha):
        return "N/A"
    if alpha >= 0.90:
        return "Excellent (≥.90)"
    if alpha >= 0.80:
        return "Good (.80–.89)"
    if alpha >= 0.70:
        return "Acceptable (.70–.79)"
    if alpha >= 0.60:
        return "Questionable (.60–.69)"
    if alpha >= 0.50:
        return "Poor (.50–.59)"
    return "Unacceptable (<.50)"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--scale",
        default="data/preprocessed/cleaned_scale_info.csv",
        help="条目得分文件路径",
    )
    parser.add_argument(
        "--out",
        default="reliability_scales.csv",
        help="输出文件路径",
    )
    args = parser.parse_args()

    scale_path = Path(args.scale)
    out_path   = Path(args.out)

    if not scale_path.exists():
        print(f"[ERROR] 文件不存在：{scale_path}", file=sys.stderr)
        sys.exit(1)

    out_path.parent.mkdir(parents=True, exist_ok=True)

    print(f"读取：{scale_path}")
    df = pd.read_csv(scale_path)
    print(f"原始维度：{df.shape}")

    records = []

    for prefix, scale_name in SCALE_PREFIXES.items():
        # 找到该量表的所有条目列
        item_cols = [c for c in df.columns if c.startswith(prefix)]

        if len(item_cols) == 0:
            print(f"  [WARN] {scale_name}：未找到以 '{prefix}' 开头的列，跳过。")
            continue

        item_df = df[item_cols].apply(pd.to_numeric, errors="coerce")
        n_valid  = item_df.dropna(how="all").shape[0]
        alpha    = cronbach_alpha(item_df)

        print(
            f"  {scale_name:8s}  条目数={len(item_cols):3d}  "
            f"有效被试={n_valid:6d}  α={alpha:.4f}  {interpret_alpha(alpha)}"
        )

        records.append({
            "scale":          scale_name,
            "n_items":        len(item_cols),
            "n_valid":        n_valid,
            "alpha":          round(alpha, 4),
            "interpretation": interpret_alpha(alpha),
        })

    result_df = pd.DataFrame(records)
    result_df.to_csv(out_path, index=False)
    print(f"\n[OK] 已保存至：{out_path}")
    print(result_df.to_string(index=False))


if __name__ == "__main__":
    main()

