import warnings
from pathlib import Path
import json
from typing import List
import numpy as np
import pandas as pd
import networkx as nx
from sklearn.covariance import GraphicalLasso, GraphicalLassoCV
from sklearn.exceptions import ConvergenceWarning
import community.community_louvain as louvain

from src.utils.logger import setup_logger
from src.utils.network_metrics import (
    participation_coefficient,
    within_module_z_score,
    normalize_A_for_stability,
    average_controllability,
    modal_controllability,
    rich_club_curve,
    normalized_rich_club,
    global_strength,
    bridge_centrality,
    find_redundant_pairs,
    make_alpha_grid,
)
from src.utils.mds_finder import (
    find_all_mds_bruteforce,
    find_all_mds_gpu,
    find_all_mds_hybrid,
)
from src.utils.data_utils import (
    EBICSelector,
    npn_transform,
)

logger = setup_logger(__name__)
    
class ModuleControlNetwork:
    def __init__(
        self,
        result_folder: Path | str,
        data: pd.DataFrame = None,
        lasso_cv: bool = True,
        lasso_cv_method: str = "ebic",  # "ebic" or "cv"
        lasso_alpha: float = None,
        lasso_max_iter: int = 1000,
        louvain_resolution: float = 1.0,
        mds_method: str = "hybrid",
        mds_max_solutions: int = 1000,
        mds_high_degree_top_pctl: float = 0.95,  # DC: top-5% by default
        rich_club_randomizations: int = 20,
        random_state: int = 42,
    ):
        """
        Initializes the ModuleControlNetwork with parameters.
        """
        self.result_folder = Path(result_folder)
        self.result_folder.mkdir(parents=True, exist_ok=True)

        # Load data
        if data is not None:
            self.data = data
        else:
            raise ValueError("Must specify data.")

        # LASSO alpha selection
        self.lasso_cv = lasso_cv
        if self.lasso_cv:
            assert lasso_alpha is None, "Cannot specify alpha when using cross-validation."
            assert lasso_cv_method in ("ebic", "cv"), "lasso_cv_method must be 'ebic' or 'cv'."
            self.lasso_cv_method = lasso_cv_method
            if Path(self.result_folder / "summary.json").exists():
                with open(self.result_folder / "summary.json", "r") as f:
                    summary = json.load(f)
                lasso_alpha = summary.get("lasso_alpha", None)
                if lasso_alpha is not None:
                    self.lasso_cv = False
        else:
            assert lasso_alpha is not None, "Must specify alpha when not using cross-validation."
        self.lasso_alpha_range = None
        self.lasso_alpha = lasso_alpha
        self.lasso_max_iter = lasso_max_iter
        self.lasso_convergence = None
        self.lasso_iterations = None

        # Community
        self.louvain_resolution = louvain_resolution

        # MDS search
        assert mds_method in ["hybrid", "precise", "greedy"], "Algorithm must be 'hybrid', 'precise' or 'greedy'."
        self.mds_method = mds_method
        if self.mds_method in ["hybrid", "greedy"]:
            assert mds_max_solutions > 0, "Greedy times must be a positive integer greater than 0."
            self.max_solutions = mds_max_solutions

        self.mds_high_degree_top_pctl = mds_high_degree_top_pctl
        self.rich_club_randomizations = rich_club_randomizations
        self.random_state = random_state

        # Placeholders
        self.sparse_matrix: np.ndarray | None = None
        self.abs_sparse_matrix: np.ndarray | None = None
        self.graph: nx.Graph | None = None
        self.graph_with_negative: nx.Graph | None = None
        self.bad_pairs: List[tuple] = []
        
        self.all_mds: list | None = None
        self.all_mds_strength: list | None = None
        self.all_mds_DCD: List[float] = []
        self.all_mds_OCA: List[float] = []

        self.louvain_communities: dict | None = None

        self.amcs_matrix_items: dict | None = None

    def build_network(self, domination_analysis: bool = True, module_mapping: dict = None, module_analysis: bool = True):
        """Builds the network and processes the analysis."""

        # Standardize data
        scaled_data = npn_transform(self.data, self.random_state)

        alphas, self.lasso_alpha_range = make_alpha_grid(scaled_data)
        # Build Graphical Lasso
        if self.lasso_cv:

            if self.lasso_cv_method == "ebic":
                selector = EBICSelector(gamma=0.5)
                best_alpha, best_model, ebic_grid = selector.fit(scaled_data, alphas=alphas)
                self.lasso_alpha = float(best_alpha)
                # 可选：把选择过程记录下来，便于后续分析/可视化
                self.lasso_ebic_grid_ = ebic_grid          # [(alpha, ebic), ...]
                self.lasso_selector_model_ = best_model    # 最优模型（可复用）
                logger.info(f"LASSO(EBIC) best alpha: {self.lasso_alpha}")
            elif self.lasso_cv_method == "cv":
                glcv = GraphicalLassoCV(alphas=alphas,max_iter=self.lasso_max_iter)
                glcv.fit(scaled_data)
                self.lasso_alpha = float(glcv.alpha_)
                # 记录 CV 轨迹信息
                self.lasso_cv_alphas_ = getattr(glcv, "cv_alphas_", None)
                self.lasso_grid_scores_ = getattr(glcv, "grid_scores_", None)
                logger.info(f"LASSO(CV) best alpha: {self.lasso_alpha}")
        
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always", ConvergenceWarning)
            estimator = GraphicalLasso(alpha=self.lasso_alpha, max_iter=self.lasso_max_iter)
            estimator.fit(scaled_data)
            self.lasso_convergence = len([wi for wi in w if issubclass(wi.category, ConvergenceWarning)]) == 0
            self.lasso_iterations = estimator.n_iter_
            logger.info(f"LASSO Convergence: {self.lasso_convergence}")
            logger.info(f"LASSO Iterations: {self.lasso_iterations}")

        # Create sparse matrix
        sqrt_diag = np.sqrt(np.diag(estimator.precision_))
        sparse_matrix = -estimator.precision_ / np.outer(sqrt_diag, sqrt_diag)
        np.fill_diagonal(sparse_matrix, 0)
        self.sparse_matrix = sparse_matrix
        abs_sparse_matrix = np.abs(sparse_matrix)
        self.abs_sparse_matrix = abs_sparse_matrix

        # Create graph
        self.graph = nx.Graph()
        self.graph_with_negative = nx.Graph()
        self.graph.add_nodes_from(self.data.columns)
        for i, j in zip(*np.triu_indices_from(abs_sparse_matrix, k=1)):
            if abs_sparse_matrix[i, j] != 0:
                self.graph.add_edge(self.data.columns[i], self.data.columns[j], weight=abs_sparse_matrix[i, j])
            if sparse_matrix[i, j] != 0:
                self.graph_with_negative.add_edge(self.data.columns[i], self.data.columns[j], weight=sparse_matrix[i, j])

        redundant = find_redundant_pairs(scaled_data, pair_threshold=0.5, sim_threshold=0.95, use_abs=True, method='cosine')
        # store only the variable name pairs
        self.bad_pairs = [(a, b) for a, b, _, _ in redundant]

        # Perform analysis
        self._network_analysis()
        
        if domination_analysis:
            self._dominating_sets_analysis()

        if module_analysis:
            self._community_analysis(module_mapping=module_mapping)
            self._module_controllabilities_analysis(with_mapping=bool(module_mapping))

        self._export_results(domination_analysis, module_analysis)

    def _network_analysis(self):
        """Performs basic node-level network analysis (adds node attributes)."""
        # 预计算中心性，避免在循环中重复计算
        all_nodes_deg_c = nx.degree_centrality(self.graph)
        all_nodes_close_c = nx.closeness_centrality(self.graph)
        all_nodes_betw_c = nx.betweenness_centrality(self.graph)
        all_nodes_eig_c = nx.eigenvector_centrality(self.graph, max_iter=1000)
        all_nodes_core_num = nx.core_number(self.graph)
        all_nodes_clustering = nx.clustering(self.graph)
        all_nodes_bridge_centrality = bridge_centrality(self.graph)

        for node in self.graph.nodes:
            # strength（加权度）
            node_strength = sum(abs(self.graph[node][nbr].get("weight", 1.0)) for nbr in self.graph.neighbors(node))
            node_expected_strength = sum(self.graph_with_negative[node][nbr].get("weight", 0.0) for nbr in self.graph_with_negative.neighbors(node))

            self.graph.nodes[node]["strength"] = float(node_strength)
            self.graph.nodes[node]["expected_strength"] = float(node_expected_strength)
            self.graph.nodes[node]['degree'] = int(self.graph.degree(node))
            self.graph.nodes[node]['average_strength'] = float(node_strength / self.graph.degree(node)) if self.graph.degree(node) > 0 else 0.0
            self.graph.nodes[node]["clustering"] = float(all_nodes_clustering.get(node, 0.0))
            self.graph.nodes[node]["closeness_centrality"] = float(all_nodes_close_c.get(node, 0.0))
            self.graph.nodes[node]["degree_centrality"] = float(all_nodes_deg_c.get(node, 0.0))
            self.graph.nodes[node]["betweenness_centrality"] = float(all_nodes_betw_c.get(node, 0.0))
            self.graph.nodes[node]["eigenvector_centrality"] = float(all_nodes_eig_c.get(node, 0.0))
            self.graph.nodes[node]["bridge_centrality"] = float(all_nodes_bridge_centrality.get(node, 0.0))
            self.graph.nodes[node]["k_core"] = int(all_nodes_core_num.get(node, 0))

        # Linear controllability analysis
        nodes = list(self.graph.nodes())
        idx = {n: i for i, n in enumerate(nodes)}
        A = np.zeros((len(nodes), len(nodes)), dtype=float)
        for u, v, data in self.graph.edges(data=True):
            w = float(data.get("weight", 1.0))
            A[idx[u], idx[v]] = abs(w)
            A[idx[v], idx[u]] = abs(w)

        # 归一化（谱半径 < 1）
        A = normalize_A_for_stability(A)

        # 可控性
        all_nodes_ac = average_controllability(A)
        all_nodes_mc = modal_controllability(A)

        # 写回节点属性
        for n, i in idx.items():
            self.graph.nodes[n]["average_controllability"] = float(all_nodes_ac[i])
            self.graph.nodes[n]["modal_controllability"] = float(all_nodes_mc[i])

        # Rich-Club 系数（未归一化与归一化）
        degrees = dict(self.graph.degree())
        max_k = max(degrees.values()) if degrees else 0
        k_values = list(range(0, int(max_k) + 1))
        
        rich_club_raw_curve = rich_club_curve(self.graph, k_values)
        rich_club_norm_curve = normalized_rich_club(
            self.graph, k_values, n_random=self.rich_club_randomizations, random_state=self.random_state
        )

        for node, deg in degrees.items():
            # 节点属于 k < deg 的所有rich_club，通常关联到 k=deg-1 的系数值
            k = deg - 1
            self.graph.nodes[node]["rich_club_raw"] = float(rich_club_raw_curve.get(k, 0.0))
            self.graph.nodes[node]["rich_club_norm"] = float(rich_club_norm_curve.get(k, 0.0))

    def _dominating_sets_analysis(self):
        """Finds dominating sets and calculates MDS-dependent node metrics."""
        if self.mds_method == "hybrid":
            self.all_mds, self.all_mds_strength = find_all_mds_hybrid(
                self.graph, exact=False, 
                max_solutions=self.max_solutions,
                random_state=self.random_state,
            )
        elif self.mds_method == "precise":
            self.all_mds, self.all_mds_strength = find_all_mds_bruteforce(
                self.graph,
            )
        elif self.mds_method == "greedy":
            self.all_mds, self.all_mds_strength = find_all_mds_gpu(
                self.graph, 
                max_solutions=self.max_solutions,
                random_state=self.random_state,
            )

        # 记录节点被选为 MDS 的频率
        all_nodes_control_frequency = {node: 0 for node in self.graph.nodes()}
        for dom_set in self.all_mds:
            for node in dom_set:
                all_nodes_control_frequency[node] += 1
        total = max(1, len(self.all_mds))
        all_nodes_control_frequency = {n: cnt / total for n, cnt in all_nodes_control_frequency.items()}

        # 按全图度数确定 top 百分位阈值
        degrees = dict(self.graph.degree())
        deg_vals = np.array(list(degrees.values()), dtype=float) if degrees else np.array([])
        cutoff = float(np.quantile(deg_vals, self.mds_high_degree_top_pctl)) if deg_vals.any() else 0.0

        nodes_list = list(self.graph.nodes())
        r_sum = {node: 0 for node in self.graph.nodes()}

        for dom_set in self.all_mds:
            dom_set = set(dom_set)
            # H：MDS 中度数 >= cutoff 的高阶节点
            H = {n for n in dom_set if degrees.get(n, 0.0) >= cutoff}
            L = dom_set - H

            # 覆盖集合
            def cover(S):
                covered = set()
                for u in S:
                    covered |= (set(self.graph.neighbors(u)) | {u})
                return covered

            UH = cover(H) if H else set()
            UL = cover(L) if L else set()
            # DC
            denom = max(1, len(UL))
            dc_val = len(UH) / denom if len(UH) > 0 else 0.0
            self.all_mds_DCD.append(dc_val)

            # OCA & r(v)
            r_this_set = {node: 0 for node in self.graph.nodes()}
            for md in dom_set:
                covered_by_md = set(self.graph.neighbors(md)) | {md}
                for v in covered_by_md:
                    r_this_set[v] += 1
            
            for v, rv in r_this_set.items():
                r_sum[v] += rv
            
            oca_val = sum(r_this_set.values()) / len(nodes_list) if nodes_list else 0.0
            self.all_mds_OCA.append(oca_val)

        all_nodes_average_dominating_overlap = {v: r_sum[v] / total for v in self.graph.nodes()}

        for node in self.graph.nodes():
            self.graph.nodes[node]["control_frequency"] = float(all_nodes_control_frequency.get(node, 0.0))
            self.graph.nodes[node]["average_dominating_overlap"] = float(all_nodes_average_dominating_overlap.get(node, 0.0))

    def _community_analysis(self, module_mapping):
        """Detects and assigns communities using Louvain, and computes PC / within-module z."""
        if module_mapping:
            self.louvain_communities = module_mapping
        else:
            # 使用绝对权重以更稳定地划分
            self.louvain_communities = louvain.best_partition(
                self.graph, random_state=self.random_state, resolution=self.louvain_resolution, weight="weight"
            )

        # 写入模块标签
        for node, community in self.louvain_communities.items():
            self.graph.nodes[node]["module"] = community

        # —— 依赖社团的节点级指标：PC、within-module z ——
        pc = participation_coefficient(self.graph, self.louvain_communities)
        z = within_module_z_score(self.graph, self.louvain_communities)

        for n in self.graph.nodes():
            self.graph.nodes[n]["participation_coefficient"] = float(pc.get(n, 0.0))
            self.graph.nodes[n]["within_module_z_score"] = float(z.get(n, 0.0))

    def _module_controllabilities_analysis(self, with_mapping: bool = False):
        """Calculates the average module control strength (AMCS) based on dominating sets and community structure."""
        modules = set(self.louvain_communities.values())

        module_nodes = {module: set() for module in modules}
        for node, module in self.louvain_communities.items():
            module_nodes[module].add(node)

        # Initialize the AMCS matrix items
        if with_mapping:
            amcs_df = pd.DataFrame([{"source": source, "target": target, "amcs": 0.0} for source in modules for target in modules])
        else:
            num_modules = max(self.louvain_communities.values()) + 1
            self.amcs_matrix_items = {f"{i}_{j}": 0 for i in range(num_modules) for j in range(num_modules)}

        # Traverse the minimum dominating set
        for dom_set in self.all_mds:
            control_areas = {module: set() for module in modules}

            # Calculate the control domain of the dominating node
            for dom_node in dom_set:
                neighbors = set(self.graph.neighbors(dom_node)) | {dom_node}
                for module_idx, nodes in module_nodes.items():
                    if dom_node in nodes:
                        control_areas[module_idx].update(neighbors)

            # Calculate module control strength
            for source in modules:
                for target in modules:
                    intersection = control_areas[source] & module_nodes[target]
                    strength = len(intersection) / len(module_nodes[target]) if module_nodes[target] else 0
                    if with_mapping:
                        amcs_df.loc[(amcs_df["source"] == source) & (amcs_df["target"] == target), "amcs"] += strength
                    else:
                        self.amcs_matrix_items[f"{source}_{target}"] += strength

        # Calculate AMCS
        if with_mapping:
            amcs_df["amcs"] /= len(self.all_mds)
            # store dataframe for later export
            self.amcs_df = amcs_df
            # AMCS without self-loops
            self.amcs_df_no_self_loops = amcs_df[amcs_df["source"] != amcs_df["target"]].copy()
        else:
            self.amcs_matrix_items = {key: value / len(self.all_mds) for key, value in self.amcs_matrix_items.items()}
            # Export module controllabilities analysis
            # store items for later export
            self.amcs_matrix_items = {key: value for key, value in self.amcs_matrix_items.items()}
            self.amcs_matrix_items_no_self_loops = {
                key: value for key, value in self.amcs_matrix_items.items() if key.split("_")[0] != key.split("_")[1]
            }

    def _export_results(self, domination_analysis: bool, module_analysis: bool):
        """Exports results to files."""
        # Export sparse matrix to txt
        np.savetxt(self.result_folder / "sparse_matrix.txt", self.abs_sparse_matrix)
        # Export network
        nx.write_gexf(self.graph, self.result_folder / "network.gexf")
        # Export network analysis and community analysis
        results = {node: data for node, data in self.graph.nodes(data=True)}
        pd.DataFrame.from_dict(results, orient="index").reset_index().to_csv(
            self.result_folder / "node_properties.csv", index=False
        )
        
        # Export summary
        summary = {
            "lasso_cv": self.lasso_cv,
            "lasso_alpha_range": self.lasso_alpha_range,
            "lasso_alpha": self.lasso_alpha,
            "lasso_convergence": self.lasso_convergence,
            "lasso_iterations": self.lasso_iterations,
            "nodes_num": self.graph.number_of_nodes(),
            "edges_num": self.graph.number_of_edges(),
            "average_degree": np.mean(list(dict(self.graph.degree(weight="weight")).values())),
            "degree_assortativity": nx.degree_assortativity_coefficient(self.graph, weight="weight"),
            "global_strength": global_strength(self.graph, normalize_by='nodes'),
            "global_efficiency": nx.global_efficiency(self.graph),
            "global_transitivity": nx.transitivity(self.graph),
            "density": nx.density(self.graph),
            "clustering_coefficient": nx.average_clustering(self.graph),
            "diameter": nx.diameter(self.graph) if nx.is_connected(self.graph) else -1,
            "average_shortest_path_length": nx.average_shortest_path_length(self.graph) if nx.is_connected(self.graph) else -1,
            "global_average_controllability": np.mean([data.get("average_controllability", 0.0) for _, data in self.graph.nodes(data=True)]),
            "global_modal_controllability": np.mean([data.get("modal_controllability", 0.0) for _, data in self.graph.nodes(data=True)]),
            "bad_pairs": self.bad_pairs,
        }
        if domination_analysis:
            summary.update({
                "mds_fraction": len(self.all_mds[0]) / self.graph.number_of_nodes() if self.graph.number_of_nodes() > 0 else 0.0,
                "mds_size": len(self.all_mds[0]),
                "mds_num": len(self.all_mds),
                "distribution_of_control_degree": np.mean(self.all_mds_DCD) if self.all_mds_DCD else 0.0,
                "overlap_of_control_area": np.mean(self.all_mds_OCA) if self.all_mds_OCA else 0.0,
            })

            # Export dominating sets analysis
            all_mds_to_str = [", ".join(sorted(dom_set)) for dom_set in self.all_mds]
            pd.DataFrame(
                zip(all_mds_to_str, self.all_mds_strength, self.all_mds_DCD, self.all_mds_OCA), 
                columns=["dominating_set", "strength", "distribution_of_control_degree", "overlap_of_control_area"]
            ).to_csv(self.result_folder / "all_minimum_dominating_sets.csv", index=False)

        if module_analysis:
            summary.update({
                "louvain_resolution": self.louvain_resolution,
                "modularity": louvain.modularity(self.louvain_communities, self.graph),
                "module_num": len(set(self.louvain_communities.values())),
            })
            # Export module controllabilities and mapped network/node properties if computed
            # Unmapped (numeric module ids) exports
            try:
                # If amcs_matrix_items exists, export numeric matrix
                if getattr(self, "amcs_matrix_items", None) is not None:
                    pd.DataFrame(self.amcs_matrix_items.items(), columns=["source_to_target", "amcs"]).to_csv(
                        self.result_folder / "module_controllabilities.csv", index=False
                    )

                if getattr(self, "amcs_matrix_items_no_self_loops", None) is not None:
                    pd.DataFrame(self.amcs_matrix_items_no_self_loops.items(), columns=["source_to_target", "amcs"]).to_csv(
                        self.result_folder / "module_controllabilities_no_self_loops.csv", index=False
                    )

                # If amcs_df (mapped labels) exists, export mapped DataFrames and mapped network/node properties
                if getattr(self, "amcs_df", None) is not None:
                    self.amcs_df.to_csv(self.result_folder / "module_controllabilities_mapped.csv", index=False)
                if getattr(self, "amcs_df_no_self_loops", None) is not None:
                    self.amcs_df_no_self_loops.to_csv(self.result_folder / "module_controllabilities_mapped_no_self_loops.csv", index=False)

                # Export mapped network and node properties only if nodes contain mapped 'module' names (strings)
                # Avoid overwriting files if they were already written by map_modules/_export_mapping
                node_modules = [data.get("module") for _, data in self.graph.nodes(data=True)]
                # If any module label is non-int (i.e., mapping applied), write mapped files
                if any(not isinstance(m, int) for m in node_modules if m is not None):
                    # Write mapped graph and node properties
                    nx.write_gexf(self.graph, self.result_folder / "network_mapped.gexf")
                    results_mapped = {node: data for node, data in self.graph.nodes(data=True)}
                    pd.DataFrame.from_dict(results_mapped, orient="index").reset_index().to_csv(
                        self.result_folder / "node_properties_mapped.csv", index=False
                    )
            except Exception as e:
                logger.exception(f"Error while exporting module controllabilities or mapped results: {e}")

        with open(self.result_folder / "summary.json", "w") as f:
            json.dump(summary, f, indent=4)

    def map_modules(self, community_mapping: dict = None):
        """
        Maps numeric module IDs to descriptive names from an enum.

        This method facilitates the interpretation of community detection results by
        assigning meaningful labels (e.g., 'Depression', 'Anxiety') to the
        automatically detected numeric module IDs.

        The mapping can be provided directly via the `community_mapping` dictionary
        or entered interactively by the user.

        Args:
            community_mapping (dict, optional): A dictionary mapping numeric
                                                community IDs (int) to module
                                                names (str). If provided,
                                                interactive input is skipped.
                                                Defaults to None.
        """
        if self.louvain_communities is None:
            logger.error("Louvain communities not found. Run community analysis first.")
            return

        communities = set(self.louvain_communities.values())
        
        # Print current communities for user context
        self._print_module_nodes(communities)

        if community_mapping is None:
            logger.info("No community mapping provided. Only displaying module nodes.")
            return
        
        logger.info("Using pre-defined community mapping.")
        # Apply the mapping and save all derived files
        self._export_mapping(community_mapping)

    def _print_module_nodes(self, communities: set):
        """Helper to print nodes in each community."""
        for idx, community in enumerate(communities):
            nodes_in_community = [
                node for node, data in self.graph.nodes(data=True) if data.get("module") == community
            ]
            logger.info(f"Community index {idx}: {', '.join(nodes_in_community)}")

    def _export_mapping(self, community_mapping: dict):
        """Applies the mapping to the graph and saves all related outputs."""
        if not community_mapping:
            logger.warning("Community mapping is empty. Skipping application and saving.")
            return

        # Apply mapping to graph nodes
        for node, data in self.graph.nodes(data=True):
            original_module_id = data.get("module")
            if original_module_id in community_mapping:
                data["module"] = community_mapping[original_module_id]
        
        logger.info("Applied module mapping to graph nodes.")

        # Save mapped graph and node properties
        nx.write_gexf(self.graph, self.result_folder / "network_mapped.gexf")
        
        node_community_mapping = {node: data['module'] for node, data in self.graph.nodes(data=True)}
        with open(self.result_folder / "node_community_mapping.json", "w") as f:
            json.dump(node_community_mapping, f, indent=4)

        results = {node: data for node, data in self.graph.nodes(data=True)}
        pd.DataFrame.from_dict(results, orient="index").reset_index().to_csv(
            self.result_folder / "node_properties_mapped.csv", index=False
        )

        # Remap and save module controllability matrices
        if self.amcs_matrix_items:
            amcs_mapped = [
                {
                    "source": community_mapping.get(int(s_t.split("_")[0])),
                    "target": community_mapping.get(int(s_t.split("_")[1])),
                    "amcs": amcs,
                }
                for s_t, amcs in self.amcs_matrix_items.items()
            ]
            pd.DataFrame(amcs_mapped).to_csv(
                self.result_folder / "module_controllabilities_mapped.csv", index=False
            )

        if self.amcs_matrix_items_no_self_loops:
            amcs_no_loops_mapped = [
                {
                    "source": community_mapping.get(int(s_t.split("_")[0])),
                    "target": community_mapping.get(int(s_t.split("_")[1])),
                    "amcs": amcs,
                }
                for s_t, amcs in self.amcs_matrix_items_no_self_loops.items()
            ]
            pd.DataFrame(amcs_no_loops_mapped).to_csv(
                self.result_folder / "module_controllabilities_mapped_no_self_loops.csv", index=False
            )
        
        logger.info("Saved all mapped results.")

