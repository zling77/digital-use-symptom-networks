from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Sequence
import warnings

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
import statsmodels.api as sm
from statsmodels.formula.api import ols

__all__ = [
    "statistical_info",
    "difference_test",
    "mark_topk_with_indices",
    "VarSpec",
    "demographic_summary",
]

def _cohens_d(group1, group2):
    diff = group1.mean() - group2.mean()
    pooled_sd = np.sqrt((group1.std() ** 2 + group2.std() ** 2) / 2)
    effect_size = diff / pooled_sd
    return effect_size

def _hedges_g(group1, group2):
    n1, n2 = len(group1), len(group2)
    diff = np.mean(group1) - np.mean(group2)
    pooled_sd = np.sqrt(((n1 - 1) * np.std(group1, ddof=1) ** 2 + (n2 - 1) * np.std(group2, ddof=1) ** 2) / (n1 + n2 - 2))
    correction = 1 - (3 / (4*(n1 + n2) - 9))
    effect_size = diff / pooled_sd * correction
    return effect_size

def statistical_info(df, columns=None):
    if columns is None:
        columns = df.columns

    # Initialize a list to collect summary data
    summary_data = []

    # Iterate over each scale type and scale
    for column_name in columns:
        # Calculate means and SDs
        group_mean = df[column_name].mean()
        group_sd = df[column_name].std()
        group_min = df[column_name].min()
        group_max = df[column_name].max()
        group_skew = df[column_name].skew()
        group_kurtosis = df[column_name].kurtosis()
        
        # Shapiro-Wilk test for normality
        shapiro_p = stats.shapiro(df[column_name])[1]

        significance = '***' if shapiro_p < 0.001 else '**' if shapiro_p < 0.01 else '*' if shapiro_p < 0.05 else ''
        
        # Collect summary data
        summary_data.append({
            'Variable': column_name,
            'Mean±SD': f'{str(round(group_mean, 2))}±{str(round(group_sd, 2))}',
            'Min/Max': f'{str(round(group_min, 2))}/{str(round(group_max, 2))}',
            'Skewness': round(group_skew, 3),
            'Kurtosis': round(group_kurtosis, 3),
            'Shapiro P': f'{round(shapiro_p, 3)} {significance}'
        })

    # Convert summary data to DataFrame for easier viewing
    summary_df = pd.DataFrame(summary_data)
    return summary_df

def difference_test(df_1: pd.DataFrame, df_2: pd.DataFrame, columns=None, paired=True):
    assert all(df_1.columns == df_2.columns), 'Columns in pre and post dataframes must match'
    
    for df in [df_1, df_2]:
        df.columns = df.columns.str.replace('-', '_')

    if columns is None:
        columns = df_1.columns
    else:
        columns = [_.replace('-', '_') for _ in columns]

    # Initialize a list to collect summary data
    summary_data = []

    # Iterate over each scale type and scale
    for column_name in columns:
        # Calculate means and SDs
        group_1_mean = df_1[column_name].mean()
        group_1_sd = df_1[column_name].std()
        group_1_min = df_1[column_name].min()
        group_1_max = df_1[column_name].max()
        group_1_skew = df_1[column_name].skew()
        group_1_kurtosis = df_1[column_name].kurtosis()
        group_2_mean = df_2[column_name].mean()
        group_2_sd = df_2[column_name].std()
        group_2_min = df_2[column_name].min()
        group_2_max = df_2[column_name].max()
        group_2_skew = df_2[column_name].skew()
        group_2_kurtosis = df_2[column_name].kurtosis()
        
        # Shapiro-Wilk test for normality
        shapiro_p_pre = stats.shapiro(df_1[column_name])[1]
        shapiro_p_post = stats.shapiro(df_2[column_name])[1]
        
        # Choose test based on paired or independent data
        if paired:
            t_test_stat, t_p_value = stats.ttest_rel(df_1[column_name], df_2[column_name])
            u_test_stat, u_p_value = stats.wilcoxon(df_1[column_name], df_2[column_name])
            # ANOVA for paired data (Type III)
            df_combined = pd.concat([df_1, df_2], keys=['pre', 'post']).reset_index(level=0).rename(columns={'level_0': 'Time'})
            model = ols(f'{column_name} ~ C(Time)', data=df_combined).fit()
            anova_table = sm.stats.anova_lm(model, typ=3)
        else:
            t_test_stat, t_p_value = stats.ttest_ind(df_1[column_name], df_2[column_name], equal_var=False)
            u_test_stat, u_p_value = stats.mannwhitneyu(df_1[column_name], df_2[column_name])
            # ANOVA for independent data (Type I)
            df_combined = pd.concat([df_1, df_2], keys=['pre', 'post']).reset_index(level=0).rename(columns={'level_0': 'Group'})
            model = ols(f'{column_name} ~ C(Group)', data=df_combined).fit()
            anova_table = sm.stats.anova_lm(model, typ=1)
        
        # Adjust p-values using FDR (Benjamini-Hochberg)
        t_p_adjusted = multipletests([t_p_value], method='fdr_bh')
        u_p_adjusted = multipletests([u_p_value], method='fdr_bh')
        anova_p_value = anova_table['PR(>F)'][0]
        anova_p_adjusted = multipletests([anova_p_value], method='fdr_bh')

        # effect size
        effect_d = _cohens_d(df_1[column_name], df_2[column_name])
        effect_g = _hedges_g(df_1[column_name], df_2[column_name])
        
        # Collect summary data
        # Determine significance markers
        t_significance = '***' if t_p_value < 0.001 else '**' if t_p_value < 0.01 else '*' if t_p_value < 0.05 else '/'
        u_significance = '***' if u_p_value < 0.001 else '**' if u_p_value < 0.01 else '*' if u_p_value < 0.05 else '/'
        anova_significance = '***' if anova_p_value < 0.001 else '**' if anova_p_value < 0.01 else '*' if anova_p_value < 0.05 else '/'

        summary_data.append({
            'Variable': column_name,
            'Group 1 (Mean±SD)': f'{str(round(group_1_mean, 2))}±{str(round(group_1_sd, 2))}',
            'Group 1 (Min/Max)': f'{str(round(group_1_min, 2))}/{str(round(group_1_max, 2))}',
            'Group 1 Skewness': round(group_1_skew, 3),
            'Group 1 Kurtosis': round(group_1_kurtosis, 3),
            'Group 1 Shapiro P': round(shapiro_p_pre, 3),
            'Group 2 (Mean±SD)': f'{str(round(group_2_mean, 2))}±{str(round(group_2_sd, 2))}',
            'Group 2 (Min/Max)': f'{str(round(group_2_min, 2))}/{str(round(group_2_max, 2))}',
            'Group 2 Skewness': round(group_2_skew, 3),
            'Group 2 Kurtosis': round(group_2_kurtosis, 3),
            'Group 2 Shapiro P': round(shapiro_p_post, 3),
            'T-Test Statistic': round(t_test_stat, 3),
            'T-Test P Value': round(t_p_value, 3),
            'T-Test Significance': t_significance,
            'T-Test P FDR Adjusted': round(t_p_adjusted[1][0], 3),
            'Cohens d': round(effect_d, 3),
            'Hedges g': round(effect_g, 3),
            'Nonparametric Statistic': round(u_test_stat, 3),
            'Nonparametric P Value': round(u_p_value, 3),
            'Nonparametric Significance': u_significance,
            'Nonparametric P FDR Adjusted': round(u_p_adjusted[1][0], 3),
            'ANOVA P Value': round(anova_p_value, 3),
            'ANOVA Significance': anova_significance,
            'ANOVA P FDR Adjusted': round(anova_p_adjusted[1][0], 3)
        })

    # Convert summary data to DataFrame for easier viewing
    summary_df = pd.DataFrame(summary_data)
    return summary_df


def mark_topk_with_indices(df, columns, topk, min_or_max, zscore=False, show_all=False):
    
    # Make a copy to avoid modifying the original DataFrame
    modified_df = round(df[columns], 3).copy()
    
    # Apply z-score transformation if zscore is True
    if zscore:
        modified_df = modified_df.apply(stats.zscore).round(3)
    
    # Define the marker based on the operation
    marker = '▼' if min_or_max == 'min' else '▲'
    
    # Store topk indices for each column, including ties
    topk_indices_dict = {}
    
    # Loop through numeric columns
    for col in modified_df.select_dtypes(include=['float64', 'int64']).columns:
        # Sort values and keep all that are within the topk range
        if min_or_max == 'min':
            sorted_values = modified_df[col].sort_values(ascending=True)
        else:
            sorted_values = modified_df[col].sort_values(ascending=False)
        
        # Get the actual threshold value for the kth position
        topk_value = sorted_values.iloc[topk-1] if topk <= len(sorted_values) else sorted_values.iloc[-1]
        
        # Identify all rows that meet the topk condition (including ties)
        top_indices = sorted_values[sorted_values <= topk_value if min_or_max == 'min' else sorted_values >= topk_value].index.tolist()
        
        # Store indices in the dictionary
        topk_indices_dict[col] = top_indices
        
        # Convert column to string type before appending the marker to avoid dtype issues
        modified_df[col] = modified_df[col].astype(str)
        # Append the marker to the values at top indices
        modified_df.loc[top_indices, col] = modified_df.loc[top_indices, col].apply(lambda x: f"{x}{marker}")
    
    if show_all:
        return modified_df, topk_indices_dict
    else:
        # Filter rows that contain at least one marker
        rows_with_markers = modified_df.apply(lambda col: col.map(lambda x: marker in str(x))).any(axis=1)
        filtered_df = modified_df[rows_with_markers]
        return filtered_df, topk_indices_dict

@dataclass
class VarSpec:
    col: str
    type: str  # "numeric" or "categorical"
    display_name: Optional[str] = None
    levels: Optional[Dict[Any, str]] = None
    unit: Optional[str] = None
    # for categoricals: "count_pct" (default) or "median_iqr" or "median_range"
    summary: Optional[str] = None
    note: Optional[str] = None

def _format_p(p: float) -> str:
    if p is None or (isinstance(p, float) and (np.isnan(p) or np.isinf(p))):
        return ""
    stars = ""
    if p < 0.001:
        stars = "***"
    elif p < 0.05:
        stars = "*"
    if p < 0.001:
        p_str = "<0.001"
    else:
        p_str = f"{p:.3f}"
    return f"{p_str}{stars}"

def _mean_sd(x: pd.Series) -> str:
    x = pd.to_numeric(x, errors="coerce").dropna()
    if len(x) == 0:
        return "NA"
    return f"{np.nanmean(x):.2f} ({np.nanstd(x, ddof=1):.2f})"

def _median_iqr(x: pd.Series) -> str:
    x = pd.to_numeric(x, errors="coerce").dropna()
    if len(x) == 0:
        return "NA"
    q1 = float(np.nanpercentile(x, 25))
    med = float(np.nanpercentile(x, 50))
    q3 = float(np.nanpercentile(x, 75))
    return f"{med:.2f} [{q1:.2f}, {q3:.2f}]"

def _median_range(x: pd.Series) -> str:
    x = pd.to_numeric(x, errors="coerce").dropna()
    if len(x) == 0:
        return "NA"
    return f"{np.nanmedian(x):.2f} [{np.nanmin(x):.2f}, {np.nanmax(x):.2f}]"

def _count_pct(series: pd.Series, level_mask: pd.Series, percent_decimals: int) -> str:
    n_all = series.notna().sum()
    n = int(level_mask.sum())
    pct = 0.0 if n_all == 0 else (100.0 * n / n_all)
    return f"{n} ({pct:.{percent_decimals}f}%)"

def _is_normal(x: pd.Series) -> Optional[bool]:
    x = pd.to_numeric(x, errors="coerce").dropna()
    n = len(x)
    if n < 3:
        return None
    try:
        if n > 5000:
            if n < 8:
                return None
            k2, p = stats.normaltest(x, nan_policy="omit")
            return p > 0.05
        else:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=UserWarning)
                p = stats.shapiro(x).pvalue
            return p > 0.05
    except Exception:
        return None

def _ttest_or_utest(x: pd.Series, g: pd.Series, group_levels: List[Any]) -> Dict[str, Any]:
    x = pd.to_numeric(x, errors="coerce")
    g = g.astype("object")
    mask0 = (g == group_levels[0]) & x.notna()
    mask1 = (g == group_levels[1]) & x.notna()
    a = x[mask0]
    b = x[mask1]
    norm_a = _is_normal(a)
    norm_b = _is_normal(b)
    use_t = (norm_a is True) and (norm_b is True) and (len(a) >= 2 and len(b) >= 2)
    if use_t:
        try:
            res = stats.ttest_ind(a, b, equal_var=False, nan_policy="omit")
            return {"test": "t", "p": float(res.pvalue)}
        except Exception:
            pass
    try:
        res = stats.mannwhitneyu(a, b, alternative="two-sided")
        return {"test": "U", "p": float(res.pvalue)}
    except Exception:
        return {"test": "U", "p": np.nan}

def _chi2_p(contingency: np.ndarray) -> float:
    try:
        chi2, p, dof, exp = stats.chi2_contingency(contingency)
        return float(p)
    except Exception:
        return float("nan")

def _binary_level_keys(series: pd.Series, levels_map: Optional[Dict[Any, str]]) -> Optional[List[Any]]:
    observed = list(pd.unique(series.dropna()))
    if len(observed) < 2:
        return None
    if len(observed) > 2:
        if levels_map:
            in_data = [k for k in levels_map.keys() if k in set(observed)]
            if len(in_data) == 2:
                return in_data
        return None
    if levels_map:
        ordered = [k for k in levels_map.keys() if k in set(observed)]
        if len(ordered) == 2:
            return ordered
    return observed[:2]

def demographic_summary(
    df: pd.DataFrame,
    specs: List[VarSpec],
    group_spec: Optional[VarSpec] = None,
    show_total: bool = True,
) -> pd.DataFrame:
    """
    Build the summary table with optional total column when grouped.
    """
    df_local = df.copy()
    total_n = int(df_local.shape[0])

    # Columns
    if group_spec is None:
        columns = ["Variable", f"Participants (N={total_n})"]
    else:
        parts = ["Variable"]
        if show_total:
            parts.append(f"Participants (N={total_n})")
        if group_spec.type != "categorical" or not group_spec.levels or len(group_spec.levels) != 2:
            raise ValueError("group_spec 必须是二分类的分类变量（levels 长度为 2）。")
        gcol = group_spec.col
        group_levels = list(group_spec.levels.keys())
        group_labels = [group_spec.levels[group_levels[0]], group_spec.levels[group_levels[1]]]
        n0 = int(df_local[gcol].eq(group_levels[0]).sum())
        n1 = int(df_local[gcol].eq(group_levels[1]).sum())
        parts.append(f"{group_labels[0]} (N={n0})")
        parts.append(f"{group_labels[1]} (N={n1})")
        parts.append("Statistics (p-value)")
        columns = parts

    rows: List[List[str]] = []

    # Resolve group context
    if group_spec is not None:
        gcol = group_spec.col
        group_levels = list(group_spec.levels.keys())

    # Start processing specs
    for spec in specs:
        name = spec.display_name or spec.col

        if spec.type == "numeric":
            var_text = f"{name}, mean (SD)"
            if spec.unit:
                var_text = f"{var_text}, {spec.unit}"

            if group_spec is None:
                overall = _mean_sd(df_local[spec.col])
                rows.append([var_text, overall])
            else:
                g = df_local[gcol]
                # prepare row
                row = [var_text]
                if show_total:
                    overall = _mean_sd(df_local[spec.col])
                    row.append(overall)
                g0 = _mean_sd(df_local.loc[g.eq(group_levels[0]), spec.col])
                g1 = _mean_sd(df_local.loc[g.eq(group_levels[1]), spec.col])
                res = _ttest_or_utest(df_local[spec.col], g, group_levels)
                p_fmt = _format_p(res["p"])
                row.extend([g0, g1, p_fmt])
                rows.append(row)

        elif spec.type in ("categorical", "discrete", "factor"):
            levels_map = spec.levels or {}
            series = df_local[spec.col]
            summary_mode = (spec.summary or "count_pct").lower()

            binary_keys = _binary_level_keys(series, levels_map)

            if summary_mode in ("median_iqr", "median_range"):
                # Variable label
                if summary_mode == "median_iqr":
                    var_text = f"{name}, median [Q1, Q3]"
                    agg_all = _median_iqr
                else:
                    var_text = f"{name}, median [min, max]"
                    agg_all = _median_range

                if group_spec is None:
                    rows.append([var_text, agg_all(pd.to_numeric(series, errors='coerce'))])
                else:
                    g = df_local[gcol]
                    row = [var_text]
                    if show_total:
                        overall_val = agg_all(pd.to_numeric(series, errors='coerce'))
                        row.append(overall_val)
                    g0_val = agg_all(pd.to_numeric(series[g.eq(group_levels[0])], errors="coerce"))
                    g1_val = agg_all(pd.to_numeric(series[g.eq(group_levels[1])], errors="coerce"))
                    try:
                        res = _ttest_or_utest(pd.to_numeric(series, errors="coerce"), g, group_levels)
                        p_fmt = _format_p(res["p"])
                    except Exception:
                        p_fmt = ""
                    row.extend([g0_val, g1_val, p_fmt])
                    rows.append(row)
                continue

            if binary_keys is not None:
                # Single-row counts "a / b"
                label_seq = [levels_map.get(k, str(k)) for k in binary_keys]
                var_text = f"{name} ({'/'.join(label_seq)})"

                if group_spec is None:
                    counts = [int(series.eq(k).sum()) for k in binary_keys]
                    rows.append([var_text, f"{counts[0]} / {counts[1]}"])
                else:
                    g = df_local[gcol]
                    row = [var_text]
                    if show_total:
                        total_counts = [int(series.eq(k).sum()) for k in binary_keys]
                        row.append(f"{total_counts[0]} / {total_counts[1]}")
                    cnt0_a = int(((series == binary_keys[0]) & (g == group_levels[0])).sum())
                    cnt0_b = int(((series == binary_keys[1]) & (g == group_levels[0])).sum())
                    cnt1_a = int(((series == binary_keys[0]) & (g == group_levels[1])).sum())
                    cnt1_b = int(((series == binary_keys[1]) & (g == group_levels[1])).sum())
                    cont = np.array([[cnt0_a, cnt1_a],
                                     [cnt0_b, cnt1_b]])
                    p = _chi2_p(cont)
                    p_fmt = _format_p(p) + " (X²)"
                    row.extend([f"{cnt0_a} / {cnt0_b}", f"{cnt1_a} / {cnt1_b}", p_fmt])
                    rows.append(row)

            else:
                # Multi-level categorials: p-value on NAME row
                level_keys = list(levels_map.keys()) if levels_map else list(pd.unique(series.dropna()))
                if group_spec is None:
                    rows.append([name, ""])
                else:
                    g = df_local[gcol]
                    cont = []
                    for k in level_keys:
                        cnt0 = int(((series == k) & (g == group_levels[0])).sum())
                        cnt1 = int(((series == k) & (g == group_levels[1])).sum())
                        cont.append([cnt0, cnt1])
                    p = _chi2_p(np.array(cont).T)
                    p_fmt = _format_p(p) + " (X²)"
                    if show_total:
                        rows.append([name, "", "", "", p_fmt])
                    else:
                        rows.append([name, "", "", p_fmt])

                # Then add level rows with "Label, no. (%)"
                if group_spec is None:
                    for k in level_keys:
                        label = levels_map.get(k, str(k))
                        val = _count_pct(series, series.eq(k), 1)
                        rows.append([f"  {label}, no. (%)", val])
                else:
                    g = df_local[gcol]
                    for k in level_keys:
                        label = levels_map.get(k, str(k))
                        mask = series.eq(k)
                        val0 = _count_pct(series[g.eq(group_levels[0])], mask & g.eq(group_levels[0]), 1)
                        val1 = _count_pct(series[g.eq(group_levels[1])], mask & g.eq(group_levels[1]), 1)
                        if show_total:
                            total_val = _count_pct(series, mask, 1)
                            rows.append([f"  {label}, no. (%)", total_val, val0, val1, ""])
                        else:
                            rows.append([f"  {label}, no. (%)", val0, val1, ""])

        else:
            raise ValueError(f"未知变量类型: {spec.type}")

    out = pd.DataFrame(rows, columns=columns)
    return out
