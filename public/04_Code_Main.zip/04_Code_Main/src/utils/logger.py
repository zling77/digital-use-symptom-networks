import logging

from src.config import LOGGING_LEVEL

__all__ = ["setup_logger"]


def setup_logger(name):
    """Create a logger with the specified name."""
    # Create a logger
    logger = logging.getLogger(name)
    logger.setLevel(LOGGING_LEVEL)  # Set the minimum logging level

    # Create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(LOGGING_LEVEL)

    # Create formatter
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )

    # Add formatter to ch
    ch.setFormatter(formatter)

    # Add ch to logger
    logger.addHandler(ch)

    return logger
