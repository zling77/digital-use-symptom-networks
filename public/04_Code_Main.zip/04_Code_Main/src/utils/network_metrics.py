"""
This module provides functions for calculating various network metrics.
"""
import random
import numpy as np
import networkx as nx
from scipy.linalg import solve_discrete_lyapunov

__all__ = [
    "participation_coefficient",
    "within_module_z_score",
    "normalize_A_for_stability",
    "average_controllability",
    "modal_controllability",
    "rich_club_curve",
    "normalized_rich_club",
    "global_strength",
    "bridge_centrality",
    "make_alpha_grid",
    "find_redundant_pairs",
]

def safe_degree_dict(G: nx.Graph, weight: str | None = None) -> dict:
    """
    Calculates the degree of each node in a graph and returns it as a dictionary
    with float values. This is a helper function to ensure degrees are in a
    consistent format.

    Args:
        G: The input graph (a networkx.Graph object).
        weight: The edge attribute to use for degree calculation. If None,
                the unweighted degree is calculated.

    Returns:
        A dictionary mapping each node to its degree as a float.
    """
    return {n: float(d) for n, d in dict(G.degree(weight=weight)).items()}

def participation_coefficient(G: nx.Graph, communities: dict[str, int]) -> dict:
    """
    Calculates the participation coefficient for each node in a graph, based on
    the definition by Guimerà & Amaral. The participation coefficient measures
    how a node's edges are distributed among different communities. A node with
    a high participation coefficient is connected to many different communities.

    Args:
        G: The input graph.
        communities: A dictionary mapping each node to its community ID.

    Returns:
        A dictionary mapping each node to its participation coefficient (a float
        between 0 and 1).
    """
    deg = safe_degree_dict(G, weight=None)
    
    # Group nodes by community
    module_nodes: dict[int, set] = {}
    for node, c in communities.items():
        module_nodes.setdefault(c, set()).add(node)

    pc = {}
    for i in G.nodes():
        k_i = deg.get(i, 0.0)
        if k_i == 0:
            pc[i] = 0.0
            continue
        
        sum_frac_sq = 0.0
        for m, nodes in module_nodes.items():
            # Count the number of edges from node i to module m
            k_im = 0.0
            for nbr in G.neighbors(i):
                if nbr in nodes:
                    k_im += 1.0  # Unweighted definition as commonly used
            sum_frac_sq += (k_im / k_i) ** 2
            
        pc[i] = 1.0 - sum_frac_sq
    return pc

def within_module_z_score(G: nx.Graph, communities: dict[str, int]) -> dict:
    """
    Calculates the within-module degree z-score for each node. This metric
    quantifies how well-connected a node is to other nodes within its own
    community, compared to the average connectivity of nodes in that community.

    Args:
        G: The input graph.
        communities: A dictionary mapping each node to its community ID.

    Returns:
        A dictionary mapping each node to its within-module degree z-score.
    """
    deg = safe_degree_dict(G, weight=None)
    
    # Group nodes by community
    module_nodes: dict[int, list[str]] = {}
    for node, c in communities.items():
        module_nodes.setdefault(c, []).append(node)

    z = {}
    for c, nodes in module_nodes.items():
        ks = np.array([deg.get(n, 0.0) for n in nodes], dtype=float)
        mu, sigma = ks.mean(), ks.std(ddof=1) if len(ks) > 1 else 0.0
        
        for n, k in zip(nodes, ks):
            if sigma > 0:
                z[n] = (k - mu) / sigma
            else:
                z[n] = 0.0
    return z

def normalize_A_for_stability(A: np.ndarray, spectral_radius: float | None = None) -> np.ndarray:
    """
    Scales the adjacency matrix A to ensure its spectral radius is less than 1.
    This is a necessary condition for the stability of discrete-time linear
    systems and for the convergence of the Lyapunov equation solution.

    Args:
        A: The adjacency matrix.
        spectral_radius: The pre-computed spectral radius of A. If None, it will
                         be calculated.

    Returns:
        The scaled adjacency matrix.
    """
    if spectral_radius is None:
        # Use the largest eigenvalue magnitude (assuming a symmetric matrix)
        vals = np.linalg.eigvals(A)
        rho = max(abs(vals))
    else:
        rho = spectral_radius
        
    if rho == 0:
        return A.copy()
        
    return (0.99 / rho) * A

def average_controllability(A: np.ndarray) -> np.ndarray:
    """
    Calculates the average controllability for each node. Average controllability
    is defined as the trace of the controllability Gramian, which measures the
    energy required to steer the system to any state.

    Args:
        A: The (stabilized) adjacency matrix of the network.

    Returns:
        An array containing the average controllability for each node.
    """
    n = A.shape[0]
    out = np.zeros(n, dtype=float)
    for i in range(n):
        b = np.zeros((n, 1))
        b[i, 0] = 1.0
        # Solve the discrete Lyapunov equation: W = A W A^T + B B^T
        W = solve_discrete_lyapunov(A, (b @ b.T))
        out[i] = float(np.trace(W))
    return out

def modal_controllability(A: np.ndarray) -> np.ndarray:
    """
    Calculates the modal controllability for each node. Modal controllability
    measures the ability of a node to control the different modes of the network
    dynamics.

    Args:
        A: The (stabilized) adjacency matrix of the network.

    Returns:
        An array containing the modal controllability for each node.
    """
    # Use eigendecomposition. For symmetric A, use eigh for stability.
    try:
        vals, vecs = np.linalg.eigh(A)
    except np.linalg.LinAlgError:
        vals, vecs = np.linalg.eig(A)
        
    n = A.shape[0]
    out = np.zeros(n, dtype=float)
    for i in range(n):
        # Element-wise square of the i-th row of the eigenvector matrix
        v2 = vecs[i, :] ** 2
        out[i] = np.sum((1.0 - (np.abs(vals) ** 2)) * v2)
    return out

def rich_club_curve(G: nx.Graph, k_values: list[int]) -> dict[int, float]:
    """
    Calculates the unnormalized rich-club coefficient (phi) for a range of
    degree values (k). The rich-club coefficient measures the tendency of
    high-degree nodes to be more connected to each other than to low-degree nodes.

    Args:
        G: The input graph.
        k_values: A list of degree thresholds for which to calculate the
                  rich-club coefficient.

    Returns:
        A dictionary mapping each degree threshold k to its rich-club coefficient.
    """
    rc = {}
    for k in k_values:
        nodes_high = [n for n, deg in G.degree() if deg > k]
        sub = G.subgraph(nodes_high).copy()
        n = sub.number_of_nodes()
        
        if n <= 1:
            rc[k] = 0.0
            continue
            
        e = sub.number_of_edges()
        rc[k] = (2.0 * e) / (n * (n - 1))
    return rc

def normalized_rich_club(G: nx.Graph, k_values: list[int], n_random: int = 20, random_state: int = 1) -> dict[int, float]:
    """
    Calculates the normalized rich-club coefficient. This is done by comparing
    the rich-club coefficient of the original graph to the average rich-club
    coefficient of a set of random graphs with the same degree sequence.

    Args:
        G: The input graph.
        k_values: A list of degree thresholds.
        n_random: The number of random graphs to generate for normalization.
        random_state: A seed for the random number generator for reproducibility.

    Returns:
        A dictionary mapping each degree threshold k to its normalized
        rich-club coefficient.
    """
    rng = random.Random(random_state)
    base = rich_club_curve(G, k_values)
    
    # Generate random degree-preserving graphs
    norms = {k: [] for k in k_values}
    deg_seq = [d for n, d in G.degree()]
    
    for _ in range(n_random):
        # Use the configuration model to generate a random graph
        CM = nx.configuration_model(deg_seq, seed=rng.randint(1, 1_000_000))
        # Convert to a simple undirected graph
        H = nx.Graph(CM)
        H.remove_edges_from(nx.selfloop_edges(H))
        
        norms_k = rich_club_curve(H, k_values)
        for k in k_values:
            norms[k].append(norms_k[k])
            
    rc_norm = {}
    for k in k_values:
        denom = np.mean(norms[k]) if norms[k] else 1.0
        rc_norm[k] = base[k] / denom if denom > 0 else 0.0
        
    return rc_norm

def global_strength(graph: nx.Graph, normalize_by='nodes'):
    """
    Calculates the global strength of a weighted network. Global strength is the
    sum of all edge weights, optionally normalized by the number of nodes or edges.

    Args:
        graph: The input weighted graph.
        normalize_by: The normalization method ('nodes' or 'edges').

    Returns:
        The calculated global strength.
        
    Raises:
        ValueError: If the graph is not weighted or if an invalid
                    normalization method is provided.
    """
    if not nx.is_weighted(graph):
        raise ValueError("The graph is not weighted. Please ensure edges have weights.")
    
    # Sum of all edge weights
    total_weight = sum(data.get('weight', 1) for _, _, data in graph.edges(data=True))
    
    # Normalize the global strength
    if normalize_by == 'nodes':
        return total_weight / graph.number_of_nodes()
    elif normalize_by == 'edges':
        return total_weight / graph.number_of_edges()
    else:
        raise ValueError("Invalid normalize_by value. Use 'nodes' or 'edges'.")

def bridge_centrality(G: nx.Graph, normalized: bool = True, weight: str | None = "weight") -> dict:
    """
    Calculates the bridge centrality for each node in the graph.

    Bridge centrality is defined here as the fraction of a node's incident
    edges that are bridges (edges whose removal increases the number of
    connected components). If `weight` is provided, the metric becomes the
    fraction of the node's incident strength (sum of weights) that is
    contributed by bridge edges. This follows `networkx` conventions for
    weighted measures (e.g. `degree` vs `degree(weight=...)`). The function's
    input/output style mirrors `nx.degree_centrality`.

    Args:
        G: Input NetworkX graph (directed graphs are converted to undirected
           for bridge detection). Multigraphs are treated as simple graphs.
        normalized: If True, return the fraction in [0, 1]; if False,
            return the raw count of bridge edges incident on the node.

    Returns:
        A dictionary mapping each node to its bridge centrality (float).
    """
    # For bridge detection we need a simple undirected graph
    if G.is_multigraph():
        H = nx.Graph(G)  # collapse parallel edges
    else:
        H = G

    if H.is_directed():
        H = H.to_undirected()

    # Get set of bridge edges (tuples) on the simple undirected version H
    try:
        bridge_edges = set(nx.bridges(H))
    except Exception:
        bridge_edges = set()

    # If weight is provided and the graph has weights, compute node strength
    # and bridge-weight sums. Otherwise fall back to degree/count behavior.
    if weight is not None and nx.is_weighted(G, weight=weight):
        # Compute strength (sum of weights) per node
        strength = {n: 0.0 for n in G.nodes()}
        for u, v, data in G.edges(data=True):
            w = data.get(weight, 1.0)
            # For undirected graphs, add weight to both endpoints
            strength[u] += float(w)
            strength[v] += float(w)

        bridge_weight_sum = {n: 0.0 for n in G.nodes()}
        for u, v, data in H.edges(data=True):
            # Use weight from original graph G if present, otherwise from H
            w = None
            if G.has_edge(u, v):
                # For MultiGraph, access the first edge data if necessary
                try:
                    w = G[u][v].get(weight, None) if not G.is_multigraph() else list(G[u][v].values())[0].get(weight, None)
                except Exception:
                    # fallback
                    w = None

            if w is None:
                w = data.get(weight, 1.0)

            w = float(w)
            if (u, v) in bridge_edges or (v, u) in bridge_edges:
                bridge_weight_sum[u] += w
                bridge_weight_sum[v] += w

        bc = {}
        for n in G.nodes():
            s = strength.get(n, 0.0)
            if s == 0.0:
                bc[n] = 0.0
            else:
                bc[n] = (bridge_weight_sum.get(n, 0.0) / s) if normalized else float(bridge_weight_sum.get(n, 0.0))

        return bc
    else:
        # Unweighted / fallback: use counts (as before)
        deg = safe_degree_dict(G, weight=None)

        bc = {}
        for node in G.nodes():
            k = deg.get(node, 0.0)
            if k == 0.0:
                bc[node] = 0.0
                continue

            count = 0
            for nbr in G.neighbors(node):
                e = (node, nbr)
                if e in bridge_edges or (nbr, node) in bridge_edges:
                    count += 1

            bc[node] = (count / k) if normalized else float(count)

        return bc

def make_alpha_grid(X, ratio=1e-2, n_alphas=100, use_corr=True):
    """
    Generates a grid of alpha values for regularization.

    Args:
        X (np.ndarray): The data matrix, shape (n_samples, n_features).
        ratio (float): The ratio of the minimum alpha to alpha_max, e.g., 1e-2.
        n_alphas (int): The number of alpha values in the grid.
        use_corr (bool): If True, use the correlation matrix; otherwise, use the
                         covariance matrix.

    Returns:
        np.ndarray: An array of alpha values.
    """
    S = np.corrcoef(X, rowvar=False) if use_corr else np.cov(X, rowvar=False)

    # Set alpha_max to the largest absolute off-diagonal element of the sample matrix
    off = S - np.diag(np.diag(S))
    alpha_max = np.abs(off).max()

    alpha_min = max(alpha_max * ratio, np.finfo(float).tiny)  # Ensure it's > 0
    # Generate a geometric sequence from largest to smallest, which is more
    # suitable for the L1 path.
    alphas = np.geomspace(alpha_max, alpha_min, num=n_alphas)
    alphas_range = f"{alpha_max:.4e} ~ {alpha_min:.4e}"
    return alphas, alphas_range


def find_redundant_pairs(X, pair_threshold: float = 0.5, sim_threshold: float = 0.95, use_abs: bool = True, method: str = "cosine") -> list:
    """
    Identify redundant ("bad") variable pairs by comparing each pair's
    correlation pattern with the rest of variables in the dataset.

    Procedure:
    - Compute the sample correlation matrix among variables.
    - For each pair (i, j) with |corr(i, j)| >= pair_threshold (or corr if
      use_abs=False), build two vectors: correlations of i to all variables
      excluding i and j, and correlations of j to all variables excluding i and j.
    - Compute similarity between these two vectors (cosine similarity or
      Pearson correlation). If similarity >= sim_threshold, mark the pair as
      redundant.

    Args:
        X: 2D numpy array or pandas DataFrame with shape (n_samples, n_features).
        pair_threshold: minimum absolute pairwise correlation to consider a pair.
        sim_threshold: similarity threshold to flag redundancy between patterns.
        use_abs: if True compare absolute correlations; else use signed correlations.
        method: similarity method, either 'cosine' or 'pearson'.

    Returns:
        A list of tuples (var_i, var_j, pair_corr, pattern_similarity).
        If `X` is a numpy array, var_i/var_j are integer column indices; if a
        DataFrame, they are column names.
    """
    # Accept pandas DataFrame or numpy array
    is_pandas = False
    try:
        import pandas as _pd  # local import to avoid a hard dependency at top
        if isinstance(X, _pd.DataFrame):
            is_pandas = True
            cols = list(X.columns)
            S = X.corr().to_numpy(dtype=float)
        else:
            arr = np.asarray(X)
            if arr.ndim != 2:
                raise ValueError("X must be 2D array or DataFrame")
            cols = list(range(arr.shape[1]))
            S = np.corrcoef(arr, rowvar=False)
    except Exception:
        # Fallback: treat as numpy array
        arr = np.asarray(X)
        if arr.ndim != 2:
            raise ValueError("X must be 2D array or DataFrame")
        cols = list(range(arr.shape[1]))
        S = np.corrcoef(arr, rowvar=False)

    # Replace NaNs with 0 (e.g., constant columns)
    S = np.nan_to_num(S, nan=0.0)

    if use_abs:
        S_used = np.abs(S)
    else:
        S_used = S

    n = S_used.shape[0]
    redundant = []

    # Precompute indices for faster vector extraction
    for i in range(n):
        for j in range(i + 1, n):
            pair_corr = float(S_used[i, j])
            if pair_corr < pair_threshold:
                continue

            # Build pattern vectors excluding indices i and j
            idx = [k for k in range(n) if k not in (i, j)]
            vi = S_used[i, idx]
            vj = S_used[j, idx]

            # Compute similarity
            sim = 0.0
            if method == "cosine":
                num = float(np.dot(vi, vj))
                denom = float(np.linalg.norm(vi) * np.linalg.norm(vj))
                if denom > 0:
                    sim = num / denom
                else:
                    sim = 0.0
            elif method == "pearson":
                # If constant vectors, corrcoef yields nan
                try:
                    sim = float(np.corrcoef(vi, vj)[0, 1])
                    if np.isnan(sim):
                        sim = 0.0
                except Exception:
                    sim = 0.0
            else:
                raise ValueError("Unsupported method. Use 'cosine' or 'pearson'.")

            if sim >= sim_threshold:
                redundant.append((cols[i], cols[j], float(S[i, j]), float(sim)))

    # Sort by descending similarity then descending pair correlation
    redundant.sort(key=lambda x: (x[3], abs(x[2])), reverse=True)
    return redundant
