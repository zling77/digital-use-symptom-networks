"""
This module provides functions for finding Minimum Dominating Sets (MDS) in a graph.
It includes several algorithms: a brute-force exact solver, an Integer Linear
Programming (ILP) solver using OR-Tools, a GPU-accelerated greedy heuristic,
and a hybrid approach that combines these methods.
"""
import itertools
import random
import time
import math
from typing import List, Set, Tuple, Iterable, Dict, Any, Optional

import numpy as np
import networkx as nx
try:
    import cupy as cp
    from cupyx.scipy.sparse import csr_matrix as cu_csr
    _HAS_CUDA = True
except Exception:
    _HAS_CUDA = False

try:
    from ortools.sat.python import cp_model
    _HAS_CP = True
except Exception:
    _HAS_CP = False

__all__ = [
    "find_all_mds_bruteforce",
    "find_all_mds_ilp",
    "find_all_mds_gpu",
    "find_all_mds_hybrid",
]

def find_all_mds_bruteforce(graph: nx.Graph):
    """
    Finds all minimum dominating sets (MDS) using a brute-force approach.
    This method iterates through all possible subsets of nodes, checking for
    dominating sets, and is only feasible for very small graphs.

    Args:
        graph: The input graph.

    Returns:
        A tuple containing:
        - A list of all minimum dominating sets found.
        - A list of the corresponding strengths of these MDS.
    """
    size_mds = graph.number_of_nodes()
    all_mds = []
    all_mds_strength = []

    for i in range(1, graph.number_of_nodes() + 1):
        for temp_set in itertools.combinations(graph.nodes, i):
            if nx.is_dominating_set(graph, temp_set):
                size_mds = i
                all_mds.append(temp_set)
                strength = sum(graph.degree(node, weight="weight") for node in temp_set)
                all_mds_strength.append(strength)
        if i >= size_mds:
            break

    return all_mds, all_mds_strength

def find_all_mds_ilp(graph: nx.Graph, max_solutions: int = float("inf")):
    """
    Finds all minimum dominating sets using an Integer Linear Programming (ILP)
    approach with the OR-Tools CP-SAT solver. This method first finds the size
    of the minimum dominating set and then enumerates all dominating sets of
    that size.

    Args:
        graph: The input graph.
        max_solutions: The maximum number of solutions to find.

    Returns:
        A tuple containing:
        - A list of all minimum dominating sets found.
        - A list of the corresponding strengths of these MDS.
    """
    nodes = list(graph.nodes())
    idx = {n: i for i, n in enumerate(nodes)}
    n = len(nodes)
    closed_nb = {i: set([i]) | set(idx[v] for v in graph.neighbors(nodes[i])) for i in range(n)}

    # First, find the optimal size k*
    model = cp_model.CpModel()
    x = [model.NewBoolVar(f"x_{i}") for i in range(n)]
    for i in range(n):
        model.Add(sum(x[j] for j in closed_nb[i]) >= 1)
    model.Minimize(sum(x))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 60.0
    solver.parameters.num_search_workers = 8

    status = solver.Solve(model)
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return [], []

    k_star = int(sum(solver.Value(x[i]) for i in range(n)))

    # Enumerate all optimal solutions of size k*
    all_mds, all_strength = [], []
    exclusion_sets = []  # Store found solutions to exclude them later

    while len(all_mds) < max_solutions:
        enum_model = cp_model.CpModel()
        y = [enum_model.NewBoolVar(f"x_{i}") for i in range(n)]
        for i in range(n):
            enum_model.Add(sum(y[j] for j in closed_nb[i]) >= 1)
        
        # Fix the size to k*
        enum_model.Add(sum(y) == k_star)
        
        # Exclude previous solutions
        for S_idx in exclusion_sets:
            enum_model.Add(sum(y[i] for i in S_idx) <= k_star - 1)

        solver2 = cp_model.CpSolver()
        solver2.parameters.max_time_in_seconds = 60.0
        solver2.parameters.num_search_workers = 8
        status2 = solver2.Solve(enum_model)

        if status2 not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            break  # No more optimal solutions

        sol_idx = [i for i in range(n) if solver2.Value(y[i]) == 1]
        exclusion_sets.append(sol_idx)
        sol = {nodes[i] for i in sol_idx}
        all_mds.append(sol)
        all_strength.append(float(sum(graph.degree(v, weight="weight") for v in sol)))

    return all_mds, all_strength

def find_all_mds_gpu(graph: nx.Graph, max_solutions: int, random_state: int):
    """
    Finds minimum dominating sets using a GPU-accelerated greedy heuristic with
    pruning. This is an approximate method that is much faster for large graphs.

    Args:
        graph: The input graph.
        times: The number of times to run the greedy algorithm with random tie-breaking.
        random_state: Seed for the random number generator.

    Returns:
        A tuple containing:
        - A list of the best (smallest) dominating sets found.
        - A list of the corresponding strengths of these MDS.
    """
    nodes = list(graph.nodes())
    n = len(nodes)
    idx_of = {n_: i for i, n_ in enumerate(nodes)}

    # Build the closed neighborhood CSR matrix on the GPU
    indptr_host = np.zeros(n + 1, dtype=np.int32)
    indices_host = []
    for i in range(n):
        neigh = [idx_of[v] for v in graph.neighbors(nodes[i])]
        neigh = sorted(set(neigh + [i]))
        indices_host.extend(neigh)
        indptr_host[i + 1] = indptr_host[i] + len(neigh)

    indptr_gpu = cp.asarray(indptr_host, dtype=cp.int32)
    indices_gpu = cp.asarray(indices_host, dtype=cp.int32)
    data_gpu = cp.ones(len(indices_host), dtype=cp.float32)
    A = cu_csr((data_gpu, indices_gpu, indptr_gpu), shape=(n, n))
    AT = A.transpose().tocsr()

    rng = random.Random(random_state)
    best_size = n + 1
    best_sets_frozen = set()

    for _ in range(max_solutions):
        covered = cp.zeros(n, dtype=cp.bool_)
        dom = cp.zeros(n, dtype=cp.bool_)

        # Greedy phase
        while not bool(covered.all()):
            uncovered = (~covered).astype(cp.float32)
            gain = A.dot(uncovered)
            mx = float(gain.max())
            cand_gpu = cp.where(gain == mx)[0]
            v = int(cand_gpu[int(rng.randrange(int(cand_gpu.shape[0])))])

            dom[v] = True
            start, end = A.indptr[v], A.indptr[v + 1]
            covered[A.indices[start:end]] = True

        # Pruning phase
        dom_idx = cp.where(dom)[0]
        for v in cp.asnumpy(dom_idx[::-1]):
            v = int(v)
            dom[v] = False
            x = dom.astype(cp.float32).reshape(-1, 1)
            if not bool((AT.dot(x) > 0).all()):
                dom[v] = True

        size = int(dom.sum())
        dom_set_idx = frozenset(cp.asnumpy(cp.where(dom)[0]).tolist())

        if size < best_size:
            best_size = size
            best_sets_frozen = {dom_set_idx}
        elif size == best_size:
            best_sets_frozen.add(dom_set_idx)

    # Map indices back to original node labels and calculate strength
    all_mds = []
    all_mds_strength = []
    for fs in sorted(best_sets_frozen, key=lambda s: (len(s), tuple(sorted(s)))):
        label_set = {nodes[i] for i in fs}
        all_mds.append(label_set)
        strength = float(sum(graph.degree(node, weight="weight") for node in label_set))
        all_mds_strength.append(strength)

    if not all_mds:
        all_mds = [set()]
        all_mds_strength = [0.0]

    return all_mds, all_mds_strength

# --------- 基础工具 ---------
def _greedy_ds_upper_bound(G: nx.Graph) -> Tuple[Set, int]:
    """标准支配贪心：每次选能覆盖最多未覆盖的点。返回解与上界大小。"""
    covered = set()
    dom = set()
    # 预构邻接闭包
    Nclosed = {v: set([v]) | set(G.neighbors(v)) for v in G.nodes}
    while len(covered) < G.number_of_nodes():
        # 选覆盖增益最大的点
        v = max(G.nodes, key=lambda x: len(Nclosed[x] - covered))
        dom.add(v)
        covered |= Nclosed[v]
    return dom, len(dom)

def _lower_bound_by_delta(n: int, delta_max: int) -> int:
    """下界 ceil(n/(Δ+1))"""
    return int(math.ceil(n / (delta_max + 1))) if delta_max >= 0 else 0

def _connected_components(G: nx.Graph) -> List[nx.Graph]:
    return [G.subgraph(c).copy() for c in nx.connected_components(G)]

def _leaf_reduction(G: nx.Graph) -> Tuple[nx.Graph, Set]:
    """
    轻量规约：反复处理叶子 (deg=1) => 必选其邻居；删除其闭邻域。
    仅做一次到收敛；返回规约后的图与强制选择集合 forced。
    """
    G = G.copy()
    forced = set()
    changed = True
    while changed:
        changed = False
        leaves = [v for v, d in G.degree() if d == 1]
        if not leaves:
            break
        for u in leaves:
            if u not in G:
                continue
            # 必选邻居 v
            nbrs = list(G.neighbors(u))
            if not nbrs:
                continue
            v = nbrs[0]
            if v not in G:
                continue
            forced.add(v)
            # 删除 N[v]
            Nv = set([v]) | set(G.neighbors(v))
            G.remove_nodes_from(Nv)
            changed = True
    return G, forced

# --------- 暴力（保留为小图/低密+短时尝试） ---------
def _bruteforce_with_timeout(G: nx.Graph, tlimit: float) -> Tuple[List[Set], List[float], bool]:
    start = time.time()
    all_mds, all_strength = [], []
    n = G.number_of_nodes()
    nodes = list(G.nodes())
    best_sz = n + 1
    for sz in range(1, n + 1):
        if time.time() - start > tlimit:
            return all_mds, all_strength, True
        for comb in itertools.combinations(nodes, sz):
            if time.time() - start > tlimit:
                return all_mds, all_strength, True
            if nx.is_dominating_set(G, comb):
                if sz < best_sz:
                    best_sz = sz
                    all_mds.clear()
                    all_strength.clear()
                if sz == best_sz:
                    S = set(comb)
                    all_mds.append(S)
                    all_strength.append(float(sum(G.degree(v, weight="weight") for v in S)))
        if sz >= best_sz:
            break
    return all_mds, all_strength, False

# --------- ILP（CP-SAT）暖启动：短时求可行上界/近最优 ---------
def _ilp_min_domset_quick(G: nx.Graph, warm_start: Optional[Set] = None,
                          tlimit: float = 3.0, workers: int = 8) -> Tuple[int, Set, str]:
    """
    短时 ILP：主要用于估计 k* 与提供一个高质量解。
    返回 (k_est, solution, status)；status ∈ {"OPT","FEAS","INFEAS","UNKNOWN"}。
    """
    if not _HAS_CP:
        # 兜底：用贪心上界
        dom, k = _greedy_ds_upper_bound(G)
        return k, dom, "FEAS"

    nodes = list(G.nodes())
    n = len(nodes)
    idx_of = {v: i for i, v in enumerate(nodes)}
    closed = {i: set([i]) | set(idx_of[u] for u in G.neighbors(nodes[i])) for i in range(n)}

    # 真孪生分组（用闭邻域签名）
    sig: Dict[Tuple[int, ...], List[int]] = {}
    for i in range(n):
        key = tuple(sorted(closed[i]))
        sig.setdefault(key, []).append(i)
    twin_groups = [g for g in sig.values() if len(g) > 1]

    model = cp_model.CpModel()
    x = [model.NewBoolVar(f"x_{i}") for i in range(n)]
    # 支配约束
    for i in range(n):
        model.Add(sum(x[j] for j in closed[i]) >= 1)
    # 轻度对称性破坏：链式单调
    for g in twin_groups:
        g = sorted(g)
        for a, b in zip(g, g[1:]):
            model.Add(x[a] >= x[b])

    # 目标
    model.Minimize(sum(x))

    # 暖启动
    if warm_start:
        # 给 Hint 不加硬上界，避免求解器花时间“证明更小”
        for i in range(n):
            model.AddHint(x[i], 1 if nodes[i] in warm_start else 0)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = float(tlimit)
    solver.parameters.num_search_workers = int(workers)
    status = solver.Solve(model)

    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        sol_idx = [i for i in range(n) if solver.Value(x[i]) == 1]
        sol = {nodes[i] for i in sol_idx}
        k_est = len(sol_idx)
        return k_est, sol, "OPT" if status == cp_model.OPTIMAL else "FEAS"
    elif status == cp_model.INFEASIBLE:
        return n, set(), "INFEAS"
    else:
        # UNKNOWN 超时等：回退贪心
        dom, k = _greedy_ds_upper_bound(G)
        return k, dom, "UNKNOWN"

# --------- GPU 向量化贪心 + shrink-to-k 的改良 ---------
def _gpu_enumerate_at_k_vectorized(
    G: nx.Graph,
    nodes: List,
    k_star: int,
    *,
    warm_start: Optional[Set],
    times: int,
    topk: int,
    do_1swap_local_search: bool,
    max_solutions: int,
    random_state: int
) -> Tuple[List[Set], List[float]]:
    """
    更偏向向量化的 GPU 贪心：用稀疏乘法一次性计算覆盖增益；
    尽量避免 .item()/asnumpy，同步点集中到收尾。
    """
    if not _HAS_CUDA:
        # 没有 GPU 时回退：用 CPU 贪心近似多次扰动
        rng = np.random.RandomState(random_state)
        best_sets = set()
        all_mds, all_strength = [], []
        Nclosed = {v: set([v]) | set(G.neighbors(v)) for v in nodes}
        n = len(nodes)
        idx_of = {v: i for i, v in enumerate(nodes)}
        for _ in range(times):
            covered = set()
            dom = set()
            # 随机打破平局
            order = nodes.copy()
            rng.shuffle(order)
            while len(covered) < n:
                # 计算增益（CPU 版本）
                gains = [(v, len(Nclosed[v] - covered)) for v in nodes if v not in dom]
                gains.sort(key=lambda x: x[1], reverse=True)
                cand = [v for v, _ in gains[:max(1, min(topk, len(gains)))]]
                v = cand[int(rng.randint(0, len(cand)))]
                dom.add(v)
                covered |= Nclosed[v]
            if len(dom) != k_star:
                # 简易 shrink：随机删除可删点
                dom = set(list(dom)[:k_star])
            if len(dom) == k_star:
                sol_idx = tuple(sorted(idx_of[v] for v in dom))
                if sol_idx in best_sets:
                    continue
                best_sets.add(sol_idx)
                all_mds.append(set(dom))
                all_strength.append(float(sum(G.degree(v, weight="weight") for v in dom)))
                if len(all_mds) >= max_solutions:
                    break
        return all_mds, all_strength

    # --- GPU 构图（一次） ---
    n = len(nodes)
    idx_of = {v: i for i, v in enumerate(nodes)}
    indptr_h = np.zeros(n + 1, dtype=np.int32)
    indices_h: List[int] = []
    for i in range(n):
        neigh = [idx_of[v] for v in G.neighbors(nodes[i])]
        # 闭邻域
        neigh = sorted(set(neigh + [i]))
        indices_h.extend(neigh)
        indptr_h[i + 1] = indptr_h[i] + len(neigh)
    indptr = cp.asarray(indptr_h, dtype=cp.int32)
    indices = cp.asarray(indices_h, dtype=cp.int32)
    data = cp.ones(len(indices_h), dtype=cp.float32)
    A = cu_csr((data, indices, indptr), shape=(n, n))  # 闭邻域稀疏矩阵

    rng = cp.random.RandomState(random_state)
    best_sets = set()
    all_mds, all_strength = [], []

    def _shrink_to_k(dom_b: cp.ndarray, r_cov: cp.ndarray, k_target: int):
        """GPU 上把支配集缩到 k_target，尽量不破坏覆盖（与原逻辑一致，但减少同步）。"""
        # 先尝试移除冗余点（r_cov[N(v)] > 1）
        # 取出候选顺序（尽量简单，倒序索引）
        dom_idx = cp.where(dom_b)[0]
        # 尽量批量评估“是否可删除”
        for _ in range(2):  # 两轮快速清洗
            if int(dom_b.sum()) <= k_target:
                break
            # 随机采样一批待测
            if dom_idx.size == 0:
                break
            take = min(int(dom_idx.size), 1024)
            sample = dom_idx[rng.choice(dom_idx.size, size=take, replace=False)]
            for v in sample.tolist():
                if int(dom_b.sum()) <= k_target:
                    break
                Nv = A.indices[A.indptr[v]:A.indptr[v + 1]]
                # 检查是否有 r_cov <= 1
                if not bool((r_cov[Nv] <= 1).any()):
                    dom_b[v] = False
                    r_cov[Nv] -= 1
            dom_idx = cp.where(dom_b)[0]

        if do_1swap_local_search and int(dom_b.sum()) > k_target:
            # 简化版 1-swap：随机尝试少量交换
            tries = 0
            while int(dom_b.sum()) > k_target and tries < 64:
                tries += 1
                non_dom = cp.where(~dom_b)[0]
                if non_dom.size == 0:
                    break
                w = int(non_dom[int(rng.randint(0, non_dom.size))])
                Nw = A.indices[A.indptr[w]:A.indptr[w + 1]]

                cand_u = cp.where(dom_b)[0]
                if cand_u.size < 2:
                    break
                # 取两位尝试
                u1 = int(cand_u[int(rng.randint(0, cand_u.size))])
                u2 = int(cand_u[int(rng.randint(0, cand_u.size))])
                if u1 == u2:
                    continue
                Nu1 = A.indices[A.indptr[u1]:A.indptr[u1 + 1]]
                Nu2 = A.indices[A.indptr[u2]:A.indptr[u2 + 1]]
                # 试做
                r_cov[Nu1] -= 1
                r_cov[Nu2] -= 1
                r_cov[Nw] += 1
                feasible = not bool((r_cov < 1).any())
                if feasible:
                    dom_b[u1] = False
                    dom_b[u2] = False
                    dom_b[w] = True
                else:
                    r_cov[Nw] -= 1
                    r_cov[Nu1] += 1
                    r_cov[Nu2] += 1

            # 再做一次冗余清洗
            dom_idx = cp.where(dom_b)[0]
            for v in dom_idx.tolist()[::-1]:
                if int(dom_b.sum()) <= k_target:
                    break
                Nv = A.indices[A.indptr[v]:A.indptr[v + 1]]
                if not bool((r_cov[Nv] <= 1).any()):
                    dom_b[v] = False
                    r_cov[Nv] -= 1

        return dom_b, r_cov

    # warm_start：尽量就地缩 k
    if warm_start:
        dom_b = cp.zeros(n, dtype=cp.bool_)
        r_cov = cp.zeros(n, dtype=cp.int16)
        ws_idx = cp.asarray(sorted(idx_of[v] for v in warm_start), dtype=cp.int32)
        dom_b[ws_idx] = True
        # r_cov = A * dom_b （按闭邻域计数）
        r_cov = (A @ dom_b.astype(cp.int16))
        dom_b, r_cov = _shrink_to_k(dom_b, r_cov, k_star)
        if int(dom_b.sum()) == k_star:
            sol_idx = tuple(sorted(cp.asnumpy(cp.where(dom_b)[0]).tolist()))
            best_sets.add(sol_idx)
            sol = {nodes[i] for i in sol_idx}
            all_mds.append(sol)
            all_strength.append(float(sum(G.degree(v, weight="weight") for v in sol)))

    # 外层随机扰动迭代
    for _ in range(times):
        covered = cp.zeros(n, dtype=cp.bool_)
        dom_b = cp.zeros(n, dtype=cp.bool_)
        r_cov = cp.zeros(n, dtype=cp.int16)

        # 用稀疏乘法计算每个点的“未覆盖增益”：gain = |N[v] ∩ (~covered)|
        # 开始时 covered=False => gain 为闭邻域大小
        not_cov = (~covered).astype(cp.int8)
        gain = (A @ not_cov).astype(cp.int32)

        uncovered_cnt = n
        while uncovered_cnt > 0:
            # 屏蔽已在 dom 中的点
            gmask = gain.copy()
            gmask[dom_b] = -1

            # 取 top-k 的索引
            num_cand = int((gmask >= 0).sum())
            if num_cand <= 0:
                break
            k = 1 if num_cand <= 0 else min(topk, num_cand)
            top_idx = cp.argpartition(gmask, -k)[-k:]
            v = int(top_idx[int(rng.randint(0, k))])

            if bool(dom_b[v]):
                gain[v] = -1
                continue

            dom_b[v] = True
            Nv = A.indices[A.indptr[v]:A.indptr[v + 1]]
            # 更新覆盖计数与 covered
            newly = Nv[~covered[Nv]]
            if newly.size > 0:
                covered[newly] = True
                r_cov[Nv] += 1
                uncovered_cnt -= int(newly.size)
            else:
                r_cov[Nv] += 1

            # 增量更新 gain：只需对受影响的点重算或用 A^T*delta 的等价形式
            # 这里做简单处理：用一次性稀疏乘法重新计算（在 GPU 上仍然很快）
            not_cov = (~covered).astype(cp.int8)
            gain = (A @ not_cov).astype(cp.int32)

        # 收缩到 k*
        dom_b, r_cov = _shrink_to_k(dom_b, r_cov, k_star)
        if int(dom_b.sum()) != k_star:
            continue
        sol_idx = tuple(sorted(cp.asnumpy(cp.where(dom_b)[0]).tolist()))
        if sol_idx in best_sets:
            continue
        best_sets.add(sol_idx)
        sol = {nodes[i] for i in sol_idx}
        all_mds.append(sol)
        all_strength.append(float(sum(G.degree(v, weight="weight") for v in sol)))
        if len(all_mds) >= max_solutions:
            break

    if not all_mds:
        return [set()], [0.0]
    return all_mds, all_strength

# --------- 主函数：自适应调度 + 组件化 + 规约 ---------
def find_all_mds_hybrid(
    graph: nx.Graph,
    *,
    exact: bool = False,
    timeout_warning: float = 10.0,
    times: int = 256,
    ilp_time_limit: float = 20.0,
    ilp_workers: int = 8,
    topk: int = 64,
    do_1swap_local_search: bool = True,
    max_solutions: int = 1000,
    random_state: int
):
    """
    自适应混合 MDS 求解：
    - 先做轻量规约与组件分解；
    - 用 Δ、LB/UB、组件规模与密度信号决定是否跑暴力/ILP/GPU；
    - ILP 改为短时暖启动（3~5s），仅必要时拉高时限；
    - GPU 路径改为稀疏乘法 + 尽量少的 CPU↔GPU 同步；
    - “找全解”默认保守，避免在大图/大 k 时爆炸。
    """
    G0 = graph
    nodes0 = list(G0.nodes())
    n0 = len(nodes0)
    if n0 == 0:
        return [set()], [0.0]

    # 组件分解 + 叶子规约
    components = _connected_components(G0)
    per_comp_solutions: List[List[Set]] = []
    per_comp_strengths: List[List[float]] = []

    rng_seed = int(random_state)

    for Gi in components:
        # 叶子规约
        Greduced, forced = _leaf_reduction(Gi)
        ni = Greduced.number_of_nodes()
        if ni == 0:
            # 该分量已由 forced 支配
            per_comp_solutions.append([set(forced)])
            per_comp_strengths.append([float(sum(Gi.degree(v, weight="weight") for v in forced))])
            continue

        density = nx.density(Greduced)
        degrees = [d for _, d in Greduced.degree()]
        Delta = max(degrees) if degrees else 0
        LB = _lower_bound_by_delta(ni, Delta)
        greedy_dom, UB = _greedy_ds_upper_bound(Greduced)

        # ---- 自适应分流 ----
        # 小图/稀疏且上界很小：尝试短时暴力（避免误伤星形等结构）
        BF_N_MAX = 40
        BF_DENS_MAX = 0.45
        try_bf = (ni <= BF_N_MAX) and (density <= BF_DENS_MAX) and (UB <= 0.12 * ni)

        # 强 hub 或 UB 很小：轻量路径（直接接受贪心或少量改良）
        strong_hub = (Delta >= 0.5 * ni)
        lightweight_ok = strong_hub or (UB <= 0.05 * ni)

        # UB 较大而无强 hub：关掉“找全解”、缩小 GPU 迭代
        big_k = (UB >= 0.2 * ni) and (Delta < 0.2 * ni)

        # exact=true：只允许暴力（你原来的语义）
        if exact:
            all_mds, all_strength, timed_out = _bruteforce_with_timeout(Greduced, timeout_warning)
            # 回填 forced
            all_mds = [S | forced for S in all_mds]
            all_strength = [float(sum(Gi.degree(v, weight="weight") for v in S)) for S in all_mds]
            per_comp_solutions.append(all_mds if all_mds else [set(forced)])
            per_comp_strengths.append(all_strength if all_strength else [float(sum(Gi.degree(v, weight="weight") for v in forced))])
            continue

        # 1) 轻量路径
        if lightweight_ok:
            # 可选：做一次极简 shrink（按闭邻域冗余删除）
            S = set(greedy_dom)
            # 简单冗余删除
            Nclosed = {v: set([v]) | set(Greduced.neighbors(v)) for v in Greduced.nodes()}
            covered_cnt = {u: 0 for u in Greduced.nodes()}
            for v in S:
                for u in Nclosed[v]:
                    covered_cnt[u] += 1
            changed = True
            while changed:
                changed = False
                for v in list(S):
                    # 如果去掉 v 仍覆盖
                    if all(covered_cnt[u] - (1 if u in Nclosed[v] else 0) >= 1 for u in Nclosed[v]):
                        for u in Nclosed[v]:
                            covered_cnt[u] -= 1
                        S.remove(v)
                        changed = True

            sol = S | forced
            per_comp_solutions.append([sol])
            per_comp_strengths.append([float(sum(Gi.degree(v, weight="weight") for v in sol))])
            continue

        # 2) 小图短时暴力（若设为可尝试）
        if try_bf:
            all_mds, all_strength, timed_out = _bruteforce_with_timeout(Greduced, timeout_warning)
            if all_mds:
                # 回填 forced
                all_mds = [S | forced for S in all_mds]
                all_strength = [float(sum(Gi.degree(v, weight="weight") for v in S)) for S in all_mds]
                per_comp_solutions.append(all_mds)
                per_comp_strengths.append(all_strength)
                continue
            # 否则跌入后续流程

        # 3) ILP 短时暖启动（3-5s）
        k_quick, sol_quick, st = _ilp_min_domset_quick(
            Greduced,
            warm_start=greedy_dom,
            tlimit=min(5.0, max(3.0, ilp_time_limit * 0.25)),
            workers=ilp_workers
        )

        # 如果已经 OPT，且不需要“找全解”，可以直接返回
        if st == "OPT" and big_k:
            sol = sol_quick | forced
            per_comp_solutions.append([sol])
            per_comp_strengths.append([float(sum(Gi.degree(v, weight="weight") for v in sol))])
            continue

        # 4) GPU 向量化贪心枚举 at k*
        #    times 自适应：大 k 时显著减小迭代
        if big_k:
            times_i = max(16, min(64, times // 4))
            one_swap = False
            topk_i = min(16, topk)
            max_solutions_i = min(max_solutions, 64)
        else:
            # 中等规模：适度减小
            times_i = max(32, min(128, times // 2))
            one_swap = do_1swap_local_search
            topk_i = min(32, topk)
            max_solutions_i = min(max_solutions, 256)

        k_star = k_quick  # 用 ILP/贪心给的 k 作为目标
        nodes_i = list(Greduced.nodes())

        all_mds_gpu, all_strength_gpu = _gpu_enumerate_at_k_vectorized(
            Greduced,
            nodes_i,
            k_star,
            warm_start=sol_quick if sol_quick else None,
            times=times_i,
            topk=topk_i,
            do_1swap_local_search=one_swap,
            max_solutions=max_solutions_i,
            random_state=rng_seed
        )

        if not all_mds_gpu or (len(all_mds_gpu) == 1 and big_k):
            # 没啥可枚举或大 k：直接接受最好的一个
            base = sol_quick if sol_quick else greedy_dom
            sol = base | forced
            per_comp_solutions.append([sol])
            per_comp_strengths.append([float(sum(Gi.degree(v, weight="weight") for v in sol))])
        else:
            # 回填 forced
            sols = [S | forced for S in all_mds_gpu]
            strengths = [float(sum(Gi.degree(v, weight="weight") for v in S)) for S in sols]
            per_comp_solutions.append(sols)
            per_comp_strengths.append(strengths)

    # ---- 汇总各分量（笛卡尔积合并） ----
    # 为避免“找全解”爆炸：逐步合并并截断到 max_solutions
    merged_solutions = [set()]
    merged_strengths = [0.0]
    for sols, strs_ in zip(per_comp_solutions, per_comp_strengths):
        new_solutions = []
        new_strengths = []
        for S_prev, w_prev in zip(merged_solutions, merged_strengths):
            for S_i, w_i in zip(sols, strs_):
                new_solutions.append(S_prev | S_i)
                new_strengths.append(w_prev + w_i)
                if len(new_solutions) >= max_solutions:
                    break
            if len(new_solutions) >= max_solutions:
                break
        merged_solutions = new_solutions
        merged_strengths = new_strengths
        if not merged_solutions:
            break

    if not merged_solutions:
        return [set()], [0.0]
    return merged_solutions, merged_strengths
