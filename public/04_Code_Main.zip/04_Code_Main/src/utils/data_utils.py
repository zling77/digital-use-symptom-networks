"""
This module provides utility functions and classes for data processing and
model selection, particularly for graphical models.
"""
import numpy as np
import pandas as pd
from sklearn.covariance import GraphicalLasso
from sklearn.preprocessing import QuantileTransformer

__all__ = [
    "EBICSelector",
    "npn_transform",
]

class EBICSelector:
    """
    A class for selecting the optimal regularization parameter (alpha) for
    GraphicalLasso using the Extended Bayesian Information Criterion (EBIC).
    This is useful for estimating sparse inverse covariance matrices from data.

    Args:
        gamma (float): The EBIC hyperparameter that tunes the penalty on the
                       number of edges. A higher gamma results in a sparser graph.
        tol (float): The tolerance for determining whether an element in the
                     precision matrix is non-zero.
        max_iter (int): The maximum number of iterations for the GraphicalLasso solver.
        warm_start (bool): Whether to use the solution of the previous alpha as a
                           starting point for the next one. This can speed up computation.
    """
    def __init__(self, gamma=0.5, tol=1e-8, max_iter=1000, warm_start=True):
        self.gamma = gamma
        self.tol = tol
        self.max_iter = max_iter
        self.warm_start = warm_start

    def _num_edges(self, precision: np.ndarray) -> int:
        """
        Counts the number of "significant" non-zero elements in the upper
        triangle of the precision matrix, which corresponds to the number of
        edges in the graph.

        Args:
            precision: The precision matrix.

        Returns:
            The number of edges.
        """
        p = precision.shape[0]
        upper = np.triu(precision, k=1)
        nz = np.sum(np.abs(upper) > self.tol)
        return int(nz)

    def compute_ebic(self, model: GraphicalLasso, data: np.ndarray) -> float:
        """
        Computes the Extended Bayesian Information Criterion (EBIC) for a given model.

        Args:
            model: A fitted GraphicalLasso model.
            data: The input data.

        Returns:
            The EBIC score.
        """
        n_samples, n_features = data.shape
        log_lik_total = n_samples * model.score(data)  # Total log-likelihood
        k = self._num_edges(model.precision_)          # Number of edges
        
        ebic = (
            -2.0 * log_lik_total
            + k * np.log(n_samples)
            + 4.0 * self.gamma * k * np.log(n_features)
        )
        return ebic

    def fit(self, data: np.ndarray, alphas: np.ndarray) -> tuple:
        """
        Fits the GraphicalLasso model for a range of alpha values and selects
        the best alpha based on the EBIC score.

        Args:
            data: The input data.
            alphas: An array of alpha values to test. It's recommended to sort
                    them in descending order for warm starts.

        Returns:
            A tuple containing:
            - The best alpha value found.
            - The best fitted GraphicalLasso model.
            - A list of (alpha, ebic) tuples for all tested alphas.
        """
        alphas = np.array(sorted(alphas, reverse=True))
        best_alpha = None
        best_ebic = float("inf")
        best_model = None
        ebic_grid = []

        model = GraphicalLasso(alpha=alphas[0], max_iter=self.max_iter)
        model.fit(data)
        ebic = self.compute_ebic(model, data)
        ebic_grid.append((alphas[0], ebic))
        best_alpha, best_ebic, best_model = alphas[0], ebic, model

        for alpha in alphas[1:]:
            model.alpha = alpha
            model.fit(data)
            ebic = self.compute_ebic(model, data)
            ebic_grid.append((alpha, ebic))
            
            if ebic < best_ebic:
                best_alpha = alpha
                best_ebic = ebic
                best_model = GraphicalLasso(alpha=alpha, max_iter=self.max_iter)
                best_model.precision_ = model.precision_.copy()
                best_model.covariance_ = model.covariance_.copy()
                best_model.location_ = getattr(model, "location_", None)

        return best_alpha, best_model, ebic_grid

def npn_transform(df: pd.DataFrame, random_state: int) -> np.ndarray:
    """
    Performs a non-paranormal transformation on the data using sklearn's
    QuantileTransformer. This transforms the data to follow a standard
    normal distribution.

    Args:
        df: The input data as a pandas DataFrame.
        random_state: A seed for the random number generator for reproducibility.

    Returns:
        The transformed data as a numpy array.
    """
    qt = QuantileTransformer(
        output_distribution="normal",
        random_state=random_state,
        subsample=int(1e9),  # Disable subsampling
        copy=True
    )
    X_npn = qt.fit_transform(df.to_numpy(dtype=float))
    return X_npn
