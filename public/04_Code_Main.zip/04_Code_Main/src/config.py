from enum import Enum
import logging
import matplotlib.pyplot as plt

# 设置全局字体为 Arial（需系统已安装 Arial 字体）
# 如果未安装，请先在系统中安装 Microsoft TrueType 字体（例如 ttf-mscorefonts-installer），
# 或将 arial.ttf 放入 matplotlib 可检索的字体目录后再运行代码。
plt.rcParams['font.family'] = 'Arial'
plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['mathtext.fontset'] = 'stix'  # 数学公式仍使用 STIX 风格，与 Arial 视觉兼容
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

LOGGING_LEVEL = logging.DEBUG



TITLE_FONTSIZE = 32
LABEL_FONTSIZE = 20
TICK_FONTSIZE = 18
LEGEND_FONTSIZE = 14
FONTWEIGHT = "bold"
DPI = 300
SHAPES = ["o", "s", "v", "^", "D", "P", "X", "H", "d", "p", "*", "8"]

RANDOM_STATE = 42
