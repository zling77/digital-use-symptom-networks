# External validation code: GMP and MCS

This supplementary code archive contains the Global Mind Project (GMP/MHQ)
cross-sectional analysis and the Millennium Cohort Study (MCS) longitudinal
analysis. Raw third-party data are not redistributed.

## Configuration

Set one or both environment variables:

```text
PSUNET_GMP_DATA_FILE   path to the licensed GMP CSV snapshot
PSUNET_MCS_DATA_DIR    directory containing UKDA-8156-tab and UKDA-8682-tab
```

Run GMP in this order:

1. `analyses/run_mhq_external.py`
2. `analyses/mhq_network_bootstrap.py`
3. `analyses/mhq_subsample_stability.py`

Run MCS in this order:

1. `analyses/mcs_external_replication.py`
2. `analyses/mcs_reframing.py`
3. `figures/figure2_mcs_longitudinal.py` to regenerate the MCS analysis shown in main Figure 2

The `data/derived/` directory contains only small, non-identifying aggregate
outputs. Participant-level intermediate files are written to `data/checkpoints/`
and figure files to `outputs/`; neither location depends on the current working
directory. Obtain raw GMP data from Sapien Labs and MCS Sweeps 6/7 from the UK
Data Service (study numbers 8156 and 8682).

`FILE_MANIFEST.tsv` lists every distributed file with its byte size and SHA-256
digest; it can be used to verify the archive after extraction.
