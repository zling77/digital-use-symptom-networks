# External validation code: GMP and MCS

This supplementary code archive contains the Global Mind Project (GMP/MHQ)
cross-sectional analysis and the Millennium Cohort Study (MCS) longitudinal
analysis. Raw third-party data are not redistributed.

Companion manuscript: **Emotional distress predicts change in adolescent
problematic digital use and related symptoms**.

The archive contains code and non-identifying aggregate results, not an
individual-level dataset. Raw analysis steps require separately authorised
GMP or MCS data. With the supplied aggregate tables, the MCS summary and figure
can be generated without participant data:

```bash
python -m pip install -r requirements.txt
python analyses/mcs_reframing.py
python figures/figure2_mcs_longitudinal.py
```

## Configuration

Set one or both environment variables:

```text
PSUNET_GMP_DATA_FILE   path to the licensed GMP CSV snapshot
PSUNET_MCS_DATA_DIR    directory containing UKDA-8156-tab and UKDA-8682-tab
```

Run GMP in this order:

1. `analyses/run_mhq_external.py`
2. `analyses/mhq_network_bootstrap.py`
3. `analyses/mhq_subsample_stability.py`

Run MCS in this order:

1. `analyses/mcs_external_replication.py`
2. `analyses/mcs_reframing.py`
3. `figures/figure2_mcs_longitudinal.py` to plot the MCS results and SEARCH comparison

The external figure script is an auxiliary plot. The main code archive's
`00_rebuild_collection_main_figures.py` assembles the final main Figure 2 layout.
The two-row `search_directional_anchors.csv` contains the SEARCH DASS and CIAS
net directionality estimates copied from the main code archive's
`reference_results/clpn_directionality.csv`. CIAS represents problematic digital
use; ACT represents physical activity and is not used as the digital-use anchor.

The `data/derived/` directory contains only small, non-identifying aggregate
outputs. Participant-level intermediate files are written to `data/checkpoints/`
and figure files to `outputs/`; neither location depends on the current working
directory. Obtain raw GMP data from Sapien Labs and MCS Sweeps 6/7 from the UK
Data Service (study numbers 8156 and 8682).

`FILE_MANIFEST.tsv` lists every distributed file with its byte size and SHA-256
digest; it can be used to verify the archive after extraction.
The manifest itself is excluded from that list.

Do not redistribute `private_data/`, `data/checkpoints/`, downloaded third-party
files, or participant-level intermediate records. Review newly generated files
before any future release; do not upload an entire working directory.
