# Data access and non-redistribution

## Global Mind Project / MHQ

The raw GMP snapshot is licensed third-party data and is not included. Request
access from Sapien Labs and set `PSUNET_GMP_DATA_FILE`.

## Millennium Cohort Study

MCS data are not redistributed. Registered UK Data Service users can obtain
Sweep 6 (SN 8156) and Sweep 7 (SN 8682) under the applicable End User Licence.
Set `PSUNET_MCS_DATA_DIR` to the directory containing both study exports.
