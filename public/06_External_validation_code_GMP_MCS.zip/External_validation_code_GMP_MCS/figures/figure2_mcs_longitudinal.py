import sys as _portable_sys
from pathlib import Path as _PortablePath
_portable_root = next(
    p for p in [_PortablePath(__file__).resolve().parent, *_PortablePath(__file__).resolve().parents]
    if (p / "path_config.py").exists()
)
if str(_portable_root) not in _portable_sys.path:
    _portable_sys.path.insert(0, str(_portable_root))
from path_config import (
    OUTPUT_DIR, resolve_input
)

"""
MCS external longitudinal analysis (net directionality, directed network, SEARCH vs MCS)

Produces : outputs/Figure_2_MCS_validation.png

Auxiliary plot from aggregate CSV tables in data/derived/; no participant data
are required. The main code package assembles the final submission Figure 2.
"""

import numpy as np
import pandas as pd
import networkx as nx
import matplotlib as mpl
import matplotlib.pyplot as plt

META_GREY = "#888888"


def apply_figure_style(*, frame="open", font=None, sizes=(8, 7, 6), grid=False):
    import matplotlib as mpl
    if frame not in ("open", "boxed", "none"):
        raise ValueError(f"frame must be 'open'|'boxed'|'none', got {frame!r}")
    try:
        import os, sys, glob, matplotlib.font_manager as fm
        fdir = os.path.join(os.environ.get("CONDA_PREFIX") or sys.prefix, "fonts")
        if os.path.isdir(fdir):
            known = {f.fname for f in fm.fontManager.ttflist}
            for f in glob.glob(os.path.join(fdir, "*.ttf")):
                if f not in known:
                    fm.fontManager.addfont(f)
    except Exception:
        pass
    base, secondary, tick = sizes
    boxed = (frame == "boxed")
    rc = {
        "font.family": "sans-serif",
        "font.size": base,
        "axes.labelsize": base,
        "axes.titlesize": base,
        "legend.fontsize": secondary,
        "xtick.labelsize": tick,
        "ytick.labelsize": tick,
        "axes.linewidth": 0.6,
        "xtick.direction": "out", "ytick.direction": "out",
        "xtick.major.size": 3, "ytick.major.size": 3,
        "xtick.major.width": 0.6, "ytick.major.width": 0.6,
        "axes.spines.top": boxed, "axes.spines.right": boxed,
        "axes.spines.left": frame != "none", "axes.spines.bottom": frame != "none",
        "axes.grid": bool(grid),
        "legend.frameon": False,
        "figure.dpi": 200,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.titleweight": "normal",
        "axes.titlelocation": "left",
        "axes.labelweight": "normal",
        "lines.linewidth": 1.2,
        "patch.linewidth": 0.6,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    }
    if font:
        rc["font.sans-serif"] = [font] + ["DejaVu Sans", "Arial", "Helvetica"]
    mpl.rcParams.update(rc)


def panel_letter(ax, letter, *, x=-0.13, y=1.05, case="upper", fontsize=9):
    label = letter.upper() if case == "upper" else letter.lower()
    ax.text(x, y, label, transform=ax.transAxes, fontsize=fontsize,
            fontweight="bold", va="top", ha="left")


apply_figure_style(sizes=(8, 7, 6))

mcs_nd = pd.read_csv(resolve_input("mcs_clpn_directionality.csv"), index_col=0)
B = pd.read_csv(resolve_input("mcs_clpn_coefficients.csv"), index_col=0)
search_anchors = pd.read_csv(
    resolve_input("search_directional_anchors.csv"), index_col="construct"
)["net"]
nodes2 = list(B.index)

ncol = {"Internalizing": "#c0392b", "Conduct": "#e08e0b", "Hyperactivity": "#e08e0b", "Peer": "#e08e0b",
        "SocialMedia": "#2c5f8a", "Gaming": "#2c5f8a"}
short = {"Internalizing": "Intern", "Conduct": "Conduct", "Hyperactivity": "Hyper", "Peer": "Peer",
         "SocialMedia": "SocMedia", "Gaming": "Gaming"}

fig = plt.figure(figsize=(7.2, 2.9))
gs = fig.add_gridspec(1, 3, width_ratios=[1, 1, 1.05], wspace=0.5)

# (a) net directionality with CI
axa = fig.add_subplot(gs[0, 0])
order = mcs_nd.sort_values("net", ascending=True)
ypos = np.arange(len(order))
for k, d in enumerate(order.index):
    axa.barh(k, order["net"][d], color=ncol[d], edgecolor="black", lw=0.5)
    lo, hi = order["ci_lo"][d], order["ci_hi"][d]
    axa.plot([lo, hi], [k, k], color="black", lw=1.1)
    axa.plot([lo, lo], [k - 0.15, k + 0.15], color="black", lw=1.1)
    axa.plot([hi, hi], [k - 0.15, k + 0.15], color="black", lw=1.1)
axa.set_yticks(ypos)
axa.set_yticklabels(order.index, fontsize=6.5)
axa.axvline(0, color="0.4", lw=0.7)
axa.set_xlabel("Net directionality (out − in)", fontsize=7)
axa.set_title("MCS age 14→17 directionality", fontsize=8)
axa.margins(y=0.06)

# (b) directed temporal network
axb = fig.add_subplot(gs[0, 1])
Bo = B.copy().values.astype(float)
np.fill_diagonal(Bo, np.nan)
Gd = nx.DiGraph()
for ndname in nodes2:
    Gd.add_node(ndname)
for i, si in enumerate(nodes2):
    for j, tj in enumerate(nodes2):
        if i != j and abs(Bo[i, j]) >= 0.05:
            Gd.add_edge(si, tj, w=Bo[i, j])
pos = nx.circular_layout(nodes2)
nx.draw_networkx_nodes(Gd, pos, ax=axb, node_size=560,
                       node_color=[ncol[n] for n in Gd.nodes()],
                       edgecolors="black", linewidths=0.8)
nx.draw_networkx_labels(Gd, pos, {n: short[n] for n in nodes2}, ax=axb,
                        font_size=5, font_weight="bold", font_color="white")
ews = [Gd[u][v]["w"] for u, v in Gd.edges()]
ecols = ["#b0392b" if w > 0 else "#3b6bb2" for w in ews]
nx.draw_networkx_edges(Gd, pos, ax=axb, width=[abs(w) * 9 for w in ews],
                       edge_color=ecols, arrowsize=8, arrowstyle="-|>",
                       connectionstyle="arc3,rad=0.13", node_size=560, alpha=0.72)
axb.set_xlim(-1.35, 1.35)
# FIX: widen the lower margin so the (enlarged) caption clears the bottom nodes
axb.set_ylim(-1.62, 1.35)
axb.set_title("Directed temporal network", fontsize=8)
axb.axis("off")
# FIX: caption was fontsize=5 (too small); enlarge to 7 and drop it below the network
axb.text(0.5, -0.10, "edges: |β| ≥ 0.05; red +, blue −",
         transform=axb.transAxes, ha="center", va="top", fontsize=7, color="0.35")

# (c) descriptive cross-cohort comparison
axc = fig.add_subplot(gs[0, 2])
comp = pd.DataFrame({
    "SEARCH": [
        search_anchors.loc["Emotion"], search_anchors.loc["Problematic_digital_use"]
    ],
    "MCS": [
        mcs_nd.loc["Internalizing", "net"], mcs_nd.loc["SocialMedia", "net"]
    ],
},
                    index=["Emotion /\ninternalising", "Problematic digital use /\nsocial media use"])
x = np.arange(2)
w = 0.36
axc.bar(x - w / 2, comp["SEARCH"], w, color="#c0392b", edgecolor="black", lw=0.5,
        label="SEARCH")
axc.bar(x + w / 2, comp["MCS"], w, color="#2c5f8a", edgecolor="black", lw=0.5,
        label="MCS")
axc.axhline(0, color="0.4", lw=0.7)
axc.set_xticks(x)
axc.set_xticklabels(["Emotion /\ninternalising", "Problematic digital use /\nsocial media use"], fontsize=5.5)
axc.set_ylabel("Net directionality", fontsize=7)
axc.set_title("Cross-cohort comparison", fontsize=8)
axc.legend(fontsize=5.6, loc="lower left", frameon=False)

for ax, l in [(axa, 'a'), (axb, 'b'), (axc, 'c')]:
    panel_letter(ax, l, case="lower")

output = OUTPUT_DIR / "Figure_2_MCS_validation.png"
fig.savefig(output, dpi=300, bbox_inches="tight", facecolor="white")
plt.close(fig)
print(f"saved {output}")
