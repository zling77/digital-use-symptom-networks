"""Portable path configuration for the submission code package."""
from __future__ import annotations

import os
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
DERIVED_DATA_DIR = PROJECT_ROOT / "data" / "derived"
CHECKPOINT_DIR = PROJECT_ROOT / "data" / "checkpoints"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
PRIVATE_DATA_ROOT = Path(os.environ.get("PSUNET_PRIVATE_DATA_ROOT", PROJECT_ROOT / "private_data"))
SEARCH_DATA_DIR = Path(os.environ.get("PSUNET_SEARCH_DATA_DIR", PRIVATE_DATA_ROOT / "SEARCH"))
GMP_DATA_FILE = Path(os.environ.get("PSUNET_GMP_DATA_FILE", PRIVATE_DATA_ROOT / "GMP" / "gmp_data.csv"))
MCS_DATA_DIR = Path(os.environ.get("PSUNET_MCS_DATA_DIR", PRIVATE_DATA_ROOT / "MCS"))
GLPK_CMD = os.environ.get("PSUNET_GLPK_CMD", "glpsol")

for directory in (DERIVED_DATA_DIR, CHECKPOINT_DIR, OUTPUT_DIR):
    directory.mkdir(parents=True, exist_ok=True)

def _unversioned(name: str) -> str:
    return re.sub(r"^v[0-9a-f]{8}_", "", Path(name).name, flags=re.I)

def resolve_input(name: str) -> Path:
    """Resolve a derived/checkpoint/private input without machine-specific paths."""
    clean = _unversioned(name)
    candidates = [
        DERIVED_DATA_DIR / clean,
        CHECKPOINT_DIR / clean,
        PROJECT_ROOT / "pipeline" / clean,
        PRIVATE_DATA_ROOT / clean,
        PROJECT_ROOT / clean,
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    for base in (PRIVATE_DATA_ROOT, DERIVED_DATA_DIR, CHECKPOINT_DIR):
        if base.exists():
            matches = list(base.rglob(clean))
            if matches:
                return matches[0]
    raise FileNotFoundError(
        f"Input {clean!r} was not found. Set PSUNET_PRIVATE_DATA_ROOT or the "
        "dataset-specific environment variable described in DATA_ACCESS.md."
    )
