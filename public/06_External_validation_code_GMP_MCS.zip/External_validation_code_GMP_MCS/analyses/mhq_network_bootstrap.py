"""Estimate the GMP six-domain GGM and 300-sample strength bootstrap."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.covariance import GraphicalLassoCV
from sklearn.preprocessing import QuantileTransformer

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from path_config import CHECKPOINT_DIR, DERIVED_DATA_DIR
from analyses.mhq_common import DOMAIN_ORDER, load_young_adult_domains


def partial_correlations(precision: np.ndarray) -> np.ndarray:
    scale = np.sqrt(np.diag(precision))
    matrix = -precision / np.outer(scale, scale)
    np.fill_diagonal(matrix, 0)
    return matrix


def main() -> None:
    checkpoint = CHECKPOINT_DIR / "mhq_young_domains.pkl"
    domains = (
        pd.read_pickle(checkpoint)
        if checkpoint.is_file()
        else load_young_adult_domains()
    )
    complete = domains[DOMAIN_ORDER].dropna()
    complete.to_pickle(checkpoint)

    transformer = QuantileTransformer(
        output_distribution="normal", random_state=42, subsample=int(1e9)
    )
    transformed = transformer.fit_transform(complete.to_numpy(float))
    model = GraphicalLassoCV().fit(transformed)
    pcor = partial_correlations(model.precision_)
    np.save(DERIVED_DATA_DIR / "mhq_pcor.npy", pcor)
    pd.DataFrame(pcor, index=DOMAIN_ORDER, columns=DOMAIN_ORDER).to_csv(
        DERIVED_DATA_DIR / "mhq_network_pcor.csv"
    )
    print(f"Complete-case young-adult sample: {len(complete):,}", flush=True)

    rng = np.random.default_rng(42)
    bootstrap_count = 300
    n = len(complete)
    bootstrap_strength = np.zeros((bootstrap_count, len(DOMAIN_ORDER)))
    for index in range(bootstrap_count):
        rows = rng.integers(0, n, n)
        try:
            fitted = GraphicalLassoCV(alphas=4, n_jobs=-1).fit(transformed[rows])
            bootstrap_strength[index] = np.abs(
                partial_correlations(fitted.precision_)
            ).sum(axis=1)
        except Exception:
            bootstrap_strength[index] = np.nan
        if (index + 1) % 25 == 0:
            print(f"{index + 1}/{bootstrap_count}", flush=True)

    ci = np.nanpercentile(bootstrap_strength, [2.5, 97.5], axis=0)
    np.save(DERIVED_DATA_DIR / "mhq_boot_strength.npy", bootstrap_strength)
    ci_table = pd.DataFrame(
        {
            "strength": np.abs(pcor).sum(axis=1),
            "ci_low": ci[0],
            "ci_high": ci[1],
            "valid_bootstraps": np.isfinite(bootstrap_strength).all(axis=1).sum(),
        },
        index=DOMAIN_ORDER,
    )
    ci_table.to_csv(DERIVED_DATA_DIR / "mhq_boot_strength_ci.csv")
    print(ci_table.round(6).to_string())


if __name__ == "__main__":
    main()
