"""Prepare harmonized GMP/MHQ domain scores for downstream analyses."""
from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from path_config import CHECKPOINT_DIR
from analyses.mhq_common import DOMAIN_MAP, load_young_adult_domains


def main() -> None:
    domains = load_young_adult_domains()
    output = CHECKPOINT_DIR / "mhq_young_domains.pkl"
    domains.to_pickle(output)
    print(f"Young-adult records: {len(domains):,}")
    print(
        "Complete-case six-domain records:",
        int(domains[list(DOMAIN_MAP)].notna().all(axis=1).sum()),
    )
    print(f"Saved checkpoint: {output}")


if __name__ == "__main__":
    main()
