"""Build the MCS source/sink summary from machine-readable CLPN output."""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from path_config import DERIVED_DATA_DIR, resolve_input


def main() -> None:
    directionality = pd.read_csv(
        resolve_input("mcs_clpn_directionality.csv"), index_col=0
    )
    strongest_source = directionality["net"].idxmax()
    strongest_sink = directionality["net"].idxmin()

    def classify(construct: str, value: float) -> str:
        if construct == strongest_source:
            return "strongest source"
        if construct == strongest_sink:
            return "strongest sink"
        return "source" if value > 0 else "sink" if value < 0 else "neutral"

    result = directionality[["net"]].rename(
        columns={"net": "mcs_net_directionality"}
    )
    result["role"] = [
        classify(construct, value)
        for construct, value in result["mcs_net_directionality"].items()
    ]
    result = result.sort_values("mcs_net_directionality", ascending=False)
    result.index.name = "construct"
    output = DERIVED_DATA_DIR / "mcs_reframing.csv"
    result.reset_index().to_csv(output, index=False, float_format="%.4f")
    print(f"Saved {output}")


if __name__ == "__main__":
    main()
