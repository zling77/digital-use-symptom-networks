"""Shared GMP/MHQ loading and recoding used by all external analyses."""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from path_config import GMP_DATA_FILE


DOMAIN_MAP = {
    "PSU": ["social_media_freq"],
    "DASS": ["fear_anxiety", "sad_hopeless", "mood_swings", "anger"],
    "SDQ": ["restless_hyperactive", "aggression", "self_control_impulsivity"],
    "ISI": ["sleep_freq", "sleep_quality"],
    "DIET": ["UPF_freq", "fruit_veg_freq", "sugary_food_freq", "appetite_regulation"],
    "ACT": ["exercise_freq"],
}
DOMAIN_ORDER = ["PSU", "DASS", "SDQ", "ISI", "DIET", "ACT"]
AGE_18_24 = {"18", "19", "20", "21", "22", "23", "24", "18-24", "21-24"}

# One canonical ordinal coding is used by preprocessing and network estimation.
FREQUENCY_MAP = {
    "Never": 0, "Rarely/Never": 0, "Rarely/never": 0,
    "Hardly ever": 1, "Rarely": 1, "Once a month": 1,
    "A few times a month": 2, "Several times a month": 2,
    "Less than once a week": 2, "A few hours a month": 2,
    "Sometimes": 2, "Some of the time": 2,
    "Often": 3, "Once a week": 3, "Less than 1 hour a day": 3,
    "Several days a week": 4, "Several times a week": 4,
    "A few hours a week": 4, "Most of the time": 4,
    "Once a day": 5,
    "Everyday": 6, "Every day": 6, "All of the time": 6,
    "Several times a day": 7, "Many hours every day": 7,
}


def _encode_item(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    mapped = series.astype("string").str.strip().map(FREQUENCY_MAP)
    return numeric.fillna(mapped).astype(float)


def load_young_adult_domains(*, chunksize: int = 300_000) -> pd.DataFrame:
    """Load ages 18-24 and return standardized six-domain scores plus country."""
    if not GMP_DATA_FILE.is_file():
        raise FileNotFoundError(
            f"GMP input not found: {GMP_DATA_FILE}. Set PSUNET_GMP_DATA_FILE "
            "to the licensed CSV snapshot."
        )

    all_items = [item for domain in DOMAIN_ORDER for item in DOMAIN_MAP[domain]]
    usecols = ["age", "country", *all_items]
    chunks = []
    for chunk in pd.read_csv(
        GMP_DATA_FILE, usecols=usecols, chunksize=chunksize, low_memory=False
    ):
        ages = chunk["age"].astype("string").str.strip()
        selected = chunk.loc[ages.isin(AGE_18_24)].copy()
        if not selected.empty:
            chunks.append(selected)
    if not chunks:
        raise ValueError("No records aged 18-24 were found in the GMP input file.")

    raw = pd.concat(chunks, ignore_index=True)
    encoded = raw.copy()
    for item in all_items:
        encoded[item] = _encode_item(raw[item])

    scores = {}
    for domain in DOMAIN_ORDER:
        sub = encoded[DOMAIN_MAP[domain]]
        standardized = sub.apply(lambda s: (s - s.mean()) / s.std())
        scores[domain] = standardized.mean(axis=1)

    domains = pd.DataFrame(scores)
    domains["country"] = raw["country"].values
    return domains
