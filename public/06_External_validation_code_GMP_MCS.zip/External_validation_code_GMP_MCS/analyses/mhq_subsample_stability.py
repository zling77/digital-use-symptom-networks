import sys as _portable_sys
from pathlib import Path as _PortablePath
_portable_root = next(
    p for p in [_PortablePath(__file__).resolve().parent, *_PortablePath(__file__).resolve().parents]
    if (p / "path_config.py").exists()
)
if str(_portable_root) not in _portable_sys.path:
    _portable_sys.path.insert(0, str(_portable_root))
from path_config import (
    DERIVED_DATA_DIR, resolve_input
)

"""
MHQ 30x half-subsample stability of the DASS emotional hub (supplementary check)

This is a secondary split-half robustness check (30 random half-samples), NOT the
300x nonparametric strength bootstrap CI reported in the main text — that is in
`mhq_network_bootstrap.py` (which writes mhq_boot_strength.npy).

Produces : mhq_subsample_stability.csv
Key inputs: mhq_young_domains.pkl (from run_mhq_external.py)

As-run analysis code from the revision cycle (environment: psunet, seed 42).
reviewer data tables shipped in ../../Data/ or the reproducible checkpoints; repoint
them to your local copies to re-run. Numbers match the manuscript and Response letter.
"""

import pickle
import numpy as np
import pandas as pd
from sklearn.covariance import graphical_lasso

mhq_dom = pickle.load(open(str(resolve_input("mhq_young_domains.pkl")), 'rb'))

domsM = ["PSU", "DASS", "SDQ", "ISI", "DIET", "ACT"]
Xm = mhq_dom[domsM].values
Xm = Xm[~np.isnan(Xm).any(1)]
rng = np.random.default_rng(42)
dass_rank1 = 0
strengths_boot = []
for b in range(30):
    idx = rng.choice(len(Xm), len(Xm) // 2, replace=False)
    Sb = np.corrcoef(Xm[idx].T)
    try:
        cov, prec = graphical_lasso(Sb, alpha=0.01, max_iter=100)
    except:
        continue
    d_ = np.sqrt(np.diag(prec))
    pc = -prec / np.outer(d_, d_)
    np.fill_diagonal(pc, 0)
    st = {domsM[i]: np.abs(pc[i]).sum() for i in range(6)}
    strengths_boot.append(st)
    if max(st, key=st.get) == "DASS":
        dass_rank1 += 1
print(f"DASS is rank-1 hub in {dass_rank1}/{len(strengths_boot)} half-subsamples")
sb = pd.DataFrame(strengths_boot)
print("\nmean strength across subsamples:")
print(sb.mean().sort_values(ascending=False).round(3).to_string())
output = DERIVED_DATA_DIR / "mhq_subsample_stability.csv"
sb.describe().T[["mean", "min", "max"]].round(3).to_csv(output)
print(f"\nsaved {output}")
