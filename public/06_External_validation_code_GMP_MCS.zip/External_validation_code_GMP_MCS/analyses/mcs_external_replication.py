import sys as _portable_sys
from pathlib import Path as _PortablePath
_portable_root = next(
    p for p in [_PortablePath(__file__).resolve().parent, *_PortablePath(__file__).resolve().parents]
    if (p / "path_config.py").exists()
)
if str(_portable_root) not in _portable_sys.path:
    _portable_sys.path.insert(0, str(_portable_root))
from path_config import (
    DERIVED_DATA_DIR, MCS_DATA_DIR
)

"""
Millennium Cohort Study longitudinal CLPN (Wave 6 age ~14 -> Wave 7 age ~17)

Produces : mcs_clpn_directionality.csv (net directionality + 500x bootstrap 95% CI),
           mcs_clpn_coefficients.csv (full 6x6 cross-lagged beta matrix),
           mcs_clpn_pvalues.csv (matched HC3 p-values)
Key inputs: MCS/UKDA-8156-tab (Wave 6), MCS/UKDA-8682-tab (Wave 7) — tab-delimited
            self-completion + derived files from the UK Data Service.
Internalizing node = self-reported SMFQ (W6) -> Kessler K6 (W7); the other five
nodes are parent-reported SDQ subscales and child-reported screen/gaming use.

As-run analysis code from the revision cycle (environment: psunet, seed 42).
reviewer data tables shipped in ../../Data/ or the reproducible checkpoints; repoint
them to your local copies to re-run. Numbers match the manuscript and Response letter.
"""

import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy.stats import zscore

base = str(MCS_DATA_DIR)

def load(path, cols):
    return pd.read_csv(path, sep="\t", usecols=lambda c: c in cols,
                       na_values=[' ', '', '.'], low_memory=False)

# W6 derived: SDQ subscales
w6d = load(f"{base}/UKDA-8156-tab/tab/mcs6_cm_derived.tab",
           ["MCSID", "FCNUM00", "FEMOTION", "FCONDUCT", "FHYPER", "FPEER", "FCCSEX00", "FCCAGE00"])
# W6 interview: screen use + sleep + activity
w6i = load(f"{base}/UKDA-8156-tab/tab/mcs6_cm_interview.tab",
           ["MCSID", "FCNUM00", "FCSOME00", "FCCOMH00", "FCTVHO00", "FCPHEX00", "FCSLLN00", "FCSLTR00"])
# W7 derived: SDQ subscales
w7d = load(f"{base}/UKDA-8682-tab/tab/mcs7_cm_derived.tab",
           ["MCSID", "GCNUM00", "GEMOTION", "GCONDUCT", "GHYPER", "GPEER", "GDCKESSL"])
# W7 interview: screen use + sleep
w7i = load(f"{base}/UKDA-8682-tab/tab/mcs7_cm_interview.tab",
           ["MCSID", "GCNUM00", "GCSOME00", "GCCOMH00", "GCSQLT00"])

# merge within wave
w6 = w6d.merge(w6i, on=["MCSID", "FCNUM00"], how="inner")
w7 = w7d.merge(w7i, on=["MCSID", "GCNUM00"], how="inner")
w6 = w6.rename(columns={"FCNUM00": "CNUM"})
w7 = w7.rename(columns={"GCNUM00": "CNUM"})
m = w6.merge(w7, on=["MCSID", "CNUM"], how="inner", suffixes=("", "_w7"))

# set negatives to NaN
num = m.select_dtypes(include=[np.number]).columns
m[num] = m[num].where(m[num] >= 0, np.nan)

# Load W6 SMFQ items
smfq_items = [f"FCMDS{c}00" for c in "ABCDEFGHIJKLM"]
w6smfq = load(f"{base}/UKDA-8156-tab/tab/mcs6_cm_interview.tab",
              ["MCSID", "FCNUM00"] + smfq_items)
nc = w6smfq.select_dtypes(include=[np.number]).columns
w6smfq[nc] = w6smfq[nc].where(w6smfq[nc] >= 0, np.nan)
w6smfq["SMFQ"] = w6smfq[smfq_items].sum(axis=1, min_count=13)
w6smfq = w6smfq.rename(columns={"FCNUM00": "CNUM"})[["MCSID", "CNUM", "SMFQ"]]

w7k6 = w7d[["MCSID", "GCNUM00", "GDCKESSL"]].copy()
nc2 = w7k6.select_dtypes(include=[np.number]).columns
w7k6[nc2] = w7k6[nc2].where(w7k6[nc2] >= 0, np.nan)
w7k6 = w7k6.rename(columns={"GCNUM00": "CNUM"})[["MCSID", "CNUM", "GDCKESSL"]]

m2 = m.merge(w6smfq, on=["MCSID", "CNUM"], how="left").merge(w7k6, on=["MCSID", "CNUM"], how="left")

# CLPN with self-reported internalizing
node_map2 = {
    "Internalizing": ("SMFQ", "GDCKESSL"),
    "Conduct": ("FCONDUCT", "GCONDUCT"),
    "Hyperactivity": ("FHYPER", "GHYPER"),
    "Peer": ("FPEER", "GPEER"),
    "SocialMedia": ("FCSOME00", "GCSOME00"),
    "Gaming": ("FCCOMH00", "GCCOMH00"),
}
nodes2 = list(node_map2)
w1c = [a for a, b in node_map2.values()]
w3c = [b for a, b in node_map2.values()]

d2 = m2[w1c + w3c].dropna()
W1 = pd.DataFrame(zscore(d2[w1c].values), columns=nodes2)
W3 = pd.DataFrame(zscore(d2[w3c].values), columns=nodes2)

Xc = sm.add_constant(W1)
B = pd.DataFrame(0.0, index=nodes2, columns=nodes2)
P = pd.DataFrame(1.0, index=nodes2, columns=nodes2)
for out in nodes2:
    mod = sm.OLS(W3[out], Xc).fit(cov_type="HC3")
    for pr in nodes2:
        B.loc[pr, out] = mod.params[pr]
        P.loc[pr, out] = mod.pvalues[pr]

def net_dir(B, nodes):
    Bo = B.copy().astype(float)
    for n in nodes:
        Bo.loc[n, n] = 0.0
    M = Bo.abs()
    return (M.sum(axis=1) - M.sum(axis=0))

nd = net_dir(B, nodes2)

# bootstrap CIs
rng = np.random.default_rng(42)
Xv = W1.values
Yv = W3.values
n = len(W1)
Bt = []
for _ in range(500):
    idx = rng.integers(0, n, n)
    Xb = sm.add_constant(pd.DataFrame(Xv[idx], columns=nodes2))
    Yb = pd.DataFrame(Yv[idx], columns=nodes2)
    Bb = pd.DataFrame(0.0, index=nodes2, columns=nodes2)
    for out in nodes2:
        Bb[out] = sm.OLS(Yb[out], Xb).fit().params[nodes2].values
    Bt.append(net_dir(Bb, nodes2).values)
ci = np.percentile(np.array(Bt), [2.5, 97.5], axis=0)

mcs_nd = pd.DataFrame({
    "net": nd.round(4),
    "ci_lo": ci[0].round(4),
    "ci_hi": ci[1].round(4)
}, index=nodes2)
mcs_nd["sig"] = [(l > 0 or h < 0) for l, h in zip(ci[0], ci[1])]
mcs_nd.to_csv(DERIVED_DATA_DIR / "mcs_clpn_directionality.csv")

# Full cross-lagged coefficient matrix (rows = Wave-6 predictors, cols = Wave-7 outcomes)
# and the matched HC3 p-value matrix.
B.round(4).to_csv(DERIVED_DATA_DIR / "mcs_clpn_coefficients.csv")
P.round(4).to_csv(DERIVED_DATA_DIR / "mcs_clpn_pvalues.csv")
print("MCS matched N =", len(d2),
      "| saved mcs_clpn_directionality.csv, mcs_clpn_coefficients.csv, mcs_clpn_pvalues.csv")
